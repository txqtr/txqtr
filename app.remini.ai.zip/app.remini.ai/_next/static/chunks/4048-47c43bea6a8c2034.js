"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4048], {
        73916: function(e, n) {
            n.Z = {
                src: "/_next/static/media/logo-mobile.d4f6db8e.svg",
                height: 27,
                width: 85
            }
        },
        62152: function(e, n) {
            n.Z = {
                src: "/_next/static/media/logo.1a57336d.svg",
                height: 26,
                width: 118
            }
        },
        4124: function(e, n, t) {
            t.d(n, {
                u: function() {
                    return i
                }
            });
            var i = function(e, n, t) {
                return Math.max(n, Math.min(e, t))
            }
        },
        78198: function(e, n, t) {
            t.d(n, {
                Z: function() {
                    return v
                }
            });
            var i = t(26042),
                a = t(69396),
                s = t(99534),
                r = t(85893),
                c = t(4960),
                o = t(12064),
                l = t(5152),
                d = t.n(l),
                u = t(67294),
                h = t(10238),
                m = t(85727),
                f = t(4124),
                x = t(12304),
                p = d()((function() {
                    return Promise.all([t.e(2166), t.e(840), t.e(1646), t.e(95)]).then(t.bind(t, 40095))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [40095]
                        }
                    },
                    ssr: !1
                }),
                g = d()((function() {
                    return Promise.all([t.e(840), t.e(4567)]).then(t.bind(t, 14567))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [14567]
                        }
                    },
                    ssr: !1
                });

            function v(e) {
                var n = e.beforeSrc,
                    t = e.afterSrc,
                    l = e.backgroundColor,
                    d = e.badgesAlignment,
                    v = e.minSliderProgress,
                    b = void 0 === v ? 0 : v,
                    y = e.maxSliderProgress,
                    j = void 0 === y ? 1 : y,
                    Z = e.initialSliderProgress,
                    w = void 0 === Z ? .5 : Z,
                    N = e.initialFit,
                    k = e.disablePan,
                    S = e.disablePinch,
                    F = e.onPan,
                    P = e.onZoom,
                    C = e.onSlide,
                    E = e.sliderBehavior,
                    M = e.hjSuppress,
                    L = e.showTooltip,
                    T = void 0 !== L && L,
                    R = e.isLoading,
                    U = void 0 !== R && R,
                    B = e.className,
                    W = e.onLoadStart,
                    _ = e.onLoadComplete,
                    A = e.onLoadFail,
                    Y = (0, s.Z)(e, ["beforeSrc", "afterSrc", "backgroundColor", "badgesAlignment", "minSliderProgress", "maxSliderProgress", "initialSliderProgress", "initialFit", "disablePan", "disablePinch", "onPan", "onZoom", "onSlide", "sliderBehavior", "hjSuppress", "showTooltip", "isLoading", "className", "onLoadStart", "onLoadComplete", "onLoadFail"]),
                    I = (0, u.useRef)(null),
                    q = (0, u.useState)(new x.O),
                    V = q[0],
                    z = q[1],
                    D = (0, u.useCallback)((function() {
                        var e = I.current,
                            n = new x.O(e.clientWidth, null === e || void 0 === e ? void 0 : e.clientHeight);
                        return z(n), n
                    }), []);
                (0, m.Z)(null, "resize", D);
                var J = (0, u.useState)(-1),
                    O = J[0],
                    G = J[1],
                    X = (0, u.useState)(0),
                    H = X[0],
                    Q = X[1],
                    K = (0, u.useState)(0),
                    $ = K[0],
                    ee = K[1],
                    ne = (0, c.c)(0);
                (0, u.useEffect)((function() {
                    O !== w && ((0, o.j)(ne, w, {
                        delay: 1,
                        type: "spring",
                        bounce: .2,
                        duration: 1.5
                    }), G(w));
                    return ne.onChange((function(e) {
                        ee(e / w), Q(e)
                    }))
                }), [O, ne, w]);
                var te = (0, u.useCallback)((function(e) {
                        var n = e.touches[0].pageX;
                        (n <= 60 || n >= window.innerWidth - 60) && e.preventDefault()
                    }), []),
                    ie = (0, u.useMemo)((function() {
                        return {
                            passive: !1
                        }
                    }), []);
                (0, m.Z)(I, "touchstart", te, ie), (0, u.useEffect)((function() {
                    D()
                }), [D]);
                var ae = (0, u.useCallback)((function(e) {
                    var n = (0, f.u)(e, 16, V.width - 16);
                    Q((0, f.u)(n / V.width, b, j)), "function" === typeof C && C()
                }), [V, b, j, C]);
                return (0, r.jsxs)("div", (0, a.Z)((0, i.Z)({
                    className: "relative overflow-hidden w-[100%] h-[100%] ".concat(B)
                }, Y), {
                    style: {
                        backgroundColor: "#".concat(l.toString(16)),
                        touchAction: "none"
                    },
                    ref: I,
                    children: [U && (0, r.jsx)("div", {
                        className: "absolute z-[100] w-[100%] h-[100%] flex justify-center items-center frosted",
                        children: U && (0, r.jsx)(h.gy, {
                            color: "white",
                            height: "80",
                            width: "80",
                            "aria-label": "loading"
                        })
                    }), (0, r.jsx)(p, {
                        beforeSrc: n,
                        afterSrc: t,
                        className: "absolute inset-0",
                        canvasSize: V,
                        initialFit: N,
                        disablePan: k,
                        disablePinch: S,
                        backgroundColor: l,
                        trim: H * V.width,
                        onPan: F,
                        onZoom: P,
                        "data-hj-suppress": M,
                        onLoadStart: W,
                        onLoadComplete: _,
                        onLoadFail: A
                    }), (0, r.jsx)(g, {
                        offset: H * V.width,
                        badgesAlignment: d,
                        borderWidth: 2,
                        onChange: ae,
                        style: {
                            opacity: $
                        },
                        sliderBehavior: E,
                        showTooltip: T
                    })]
                }))
            }
        },
        50152: function(e, n, t) {
            t.d(n, {
                Z: function() {
                    return i
                },
                s: function() {
                    return a
                }
            });
            var i = .1,
                a = 2.5
        },
        81337: function(e, n, t) {
            var i = (0, t(2804).xu)({
                key: "comparer:fit",
                default: "none"
            });
            n.Z = i
        },
        75733: function(e, n, t) {
            t.d(n, {
                LN: function() {
                    return a.Z
                },
                PE: function() {
                    return s.Z
                },
                Uy: function() {
                    return i.Z
                },
                Zj: function() {
                    return r.Z
                },
                sZ: function() {
                    return r.s
                }
            });
            var i = t(78198),
                a = t(81337),
                s = t(91024),
                r = t(50152)
        },
        91024: function(e, n, t) {
            var i = t(2804),
                a = t(4124),
                s = t(50152),
                r = (0, i.xu)({
                    key: "comparer:internalScale",
                    default: 1
                }),
                c = (0, i.CG)({
                    key: "comparer:scale",
                    get: function(e) {
                        return function(n) {
                            return (0, n.get)(r(e))
                        }
                    },
                    set: function(e) {
                        return function(n, t) {
                            return (0, n.set)(r(e), (0, a.u)(t, s.Z, s.s))
                        }
                    }
                });
            n.Z = c
        },
        12304: function(e, n, t) {
            t.d(n, {
                O: function() {
                    return h
                }
            });
            var i = t(51438),
                a = t(52951),
                s = t(45785),
                r = t(82662),
                c = t(28668),
                o = t(19911),
                l = t(71418),
                d = (t(63573), t(75623)),
                u = t(4124),
                h = function(e) {
                    (0, c.Z)(t, e);
                    var n = (0, l.Z)(t);

                    function t(e, a) {
                        var s;
                        return (0, i.Z)(this, t), s = "undefined" === typeof a ? n.call(this, e, e) : n.call(this, e, a), (0, o.Z)(s)
                    }
                    var d = t.prototype;
                    return d.add = function(e) {
                        var n = (0, s.Z)((0, r.Z)(t.prototype), "add", this).call(this, e);
                        return new t(n.x, n.y)
                    }, d.subtract = function(e) {
                        var n = (0, s.Z)((0, r.Z)(t.prototype), "subtract", this).call(this, e);
                        return new t(n.x, n.y)
                    }, d.multiplyScalar = function(e) {
                        var n = (0, s.Z)((0, r.Z)(t.prototype), "multiplyScalar", this).call(this, e);
                        return new t(n.x, n.y)
                    }, d.copyFrom = function(e) {
                        var n = e.x,
                            t = e.y,
                            i = e.width,
                            a = e.height;
                        return this.x = "number" === typeof n ? n : i, this.y = "number" === typeof t ? t : a, this
                    }, d.divide = function(e) {
                        return new t(this.x / e.x, this.y / e.y)
                    }, d.max = function() {
                        var e = this.x,
                            n = this.y;
                        return Math.max(e, n)
                    }, d.min = function() {
                        var e = this.x,
                            n = this.y;
                        return Math.min(e, n)
                    }, d.abs = function() {
                        var e = this.x,
                            n = this.y;
                        return new t(Math.abs(e), Math.abs(n))
                    }, d.clamp = function(e, n) {
                        var i = "number" === typeof e ? new t(e) : e,
                            a = "number" === typeof n ? new t(n) : n,
                            s = this.x,
                            r = this.y,
                            c = i.x,
                            o = i.y,
                            l = a.x,
                            d = a.y;
                        return new t((0, u.u)(s, c, l), (0, u.u)(r, o, d))
                    }, (0, a.Z)(t, [{
                        key: "width",
                        get: function() {
                            return this.x
                        }
                    }, {
                        key: "height",
                        get: function() {
                            return this.y
                        }
                    }]), t
                }(d.E9);
            h.ZERO = new h(0)
        },
        29144: function(e, n, t) {
            t.d(n, {
                Z: function() {
                    return w
                }
            });
            var i = t(47568),
                a = t(26042),
                s = t(69396),
                r = t(99534),
                c = t(70655),
                o = t(85893),
                l = t(92665),
                d = t(45291),
                u = {
                    src: "/_next/static/media/check--accent-alt.8931b107.svg",
                    height: 54,
                    width: 55
                },
                h = {
                    src: "/_next/static/media/drop.b03a0fcf.svg",
                    height: 54,
                    width: 55
                },
                m = t(23061),
                f = t(2502),
                x = t(87292),
                p = t(10290),
                g = t(11503),
                v = t(35277),
                b = t(11163),
                y = t(67294),
                j = t(2804),
                Z = t(8072);

            function w(e) {
                var n = e.forId,
                    t = e.className,
                    w = void 0 === t ? "" : t,
                    N = e.mediaType,
                    k = e.isBulkUpload,
                    S = (0, r.Z)(e, ["forId", "className", "mediaType", "isBulkUpload"]),
                    F = (0, j.sJ)((0, g.Z)(n)),
                    P = (0, j.rb)((0, g.Z)(n)),
                    C = (0, l.Q4)().track,
                    E = (0, b.useRouter)(),
                    M = (0, f.ql)(),
                    L = M.t,
                    T = M.data,
                    R = (0, y.useState)(""),
                    U = R[0],
                    B = R[1],
                    W = (0, d.jW)().cancelVideoTask,
                    _ = (0, j.sJ)(p.D),
                    A = (null === N || void 0 === N ? void 0 : N.includes(x.UA.Video)) && E.query.mediaType === x.UA.Video;
                return (0, y.useEffect)((function() {
                    F.status === x.hY.Uploading && B(F.fileProgress)
                }), [F]), (0, o.jsx)("div", (0, s.Z)((0, a.Z)({
                    className: "flex w-full h-full items-center justify-center section-foreground ".concat(w, " relative")
                }, S), {
                    children: function() {
                        switch (F.status) {
                            case "draft":
                                return (0, o.jsxs)("div", {
                                    className: "space-y-6 text-center leading-none",
                                    children: [(0, o.jsx)("img", (0, s.Z)((0, a.Z)({}, h), {
                                        className: "inline-block",
                                        alt: ""
                                    })), (0, o.jsx)("h3", {
                                        className: "text-black SB25",
                                        children: L(T.processing.dropFile)
                                    })]
                                });
                            case x.hY.Invalid:
                                return (0, o.jsx)(v.h, {
                                    highlight: !0,
                                    title: "Invalid upload",
                                    children: (0, o.jsxs)("div", {
                                        className: "space-y-3",
                                        children: [(0, o.jsx)("p", {
                                            children: function() {
                                                switch (F.reason) {
                                                    case x.x8.TooFewFiles:
                                                        return (0, o.jsx)(o.Fragment, {
                                                            children: L(T.processing.tooFewFiles)
                                                        });
                                                    case x.x8.TooManyFiles:
                                                        return (0, o.jsx)(o.Fragment, {
                                                            children: L(T.processing.tooManyFiles)
                                                        });
                                                    case x.x8.WrongFileFormat:
                                                        return (0, o.jsx)(o.Fragment, {
                                                            children: L(T.processing.wrongFileFormat)
                                                        });
                                                    default:
                                                        return (0, o.jsx)(o.Fragment, {
                                                            children: L(T.processing.unknownError)
                                                        })
                                                }
                                            }()
                                        }), (0, o.jsx)("button", {
                                            type: "button",
                                            className: "btn btn--large btn--primary mx-auto",
                                            onClick: P,
                                            children: L(T.common.gotIt)
                                        })]
                                    })
                                });
                            case x.hY.Uploading:
                                return (0, o.jsxs)("div", {
                                    className: "space-y-8",
                                    children: [!A && (0, o.jsx)("p", {
                                        className: "text-center",
                                        children: U
                                    }), (0, o.jsx)("div", {
                                        className: "h-1 rounded bg-black w-40 mx-auto",
                                        role: "progressbar",
                                        "aria-valuenow": F.progress,
                                        "aria-valuemin": 0,
                                        "aria-valuemax": 100,
                                        children: (0, o.jsx)("div", {
                                            className: "h-full rounded bg-primary-accent transition-all",
                                            style: {
                                                width: "".concat(F.progress, "%")
                                            }
                                        })
                                    }), (0, o.jsxs)("div", {
                                        className: "space-y-3 text-center max-w-xs",
                                        children: [(0, o.jsx)("h3", {
                                            className: "text-black SB25",
                                            children: L(T.processing.uploadingFiles)
                                        }), (0, o.jsx)("p", {
                                            className: "M15 text-overlay-black-60",
                                            children: L(T.processing.uploadingFileSubtitle)
                                        })]
                                    })]
                                });
                            case x.hY.Processing:
                                return (0, o.jsxs)("div", {
                                    className: "space-y-8 relative",
                                    children: [(0, o.jsxs)("div", {
                                        className: "space-y-3 text-center max-w-xs relative",
                                        children: [(0, o.jsx)("h3", {
                                            className: "text-black SB25",
                                            children: L(T.processing.enhancingFiles)
                                        }), A ? (0, o.jsx)("p", {
                                            className: "M15 text-overlay-black-60",
                                            children: L(T.processing.enhancingFileSubtitle)
                                        }) : k ? (0, o.jsx)("p", {
                                            className: "M15 text-overlay-black-60",
                                            children: L(T.processing.enhancingBulkUploadSubtitle)
                                        }) : (0, o.jsx)("p", {
                                            className: "M15 text-overlay-black-60",
                                            children: L(T.processing.uploadingFileSubtitle)
                                        })]
                                    }), A && (0, o.jsxs)("button", {
                                        onClick: (0, i.Z)((function() {
                                            return (0, c.__generator)(this, (function(e) {
                                                switch (e.label) {
                                                    case 0:
                                                        return [4, W(F.id)];
                                                    case 1:
                                                        return e.sent(), C(x.hY.Processing, x.hY.Cancelled, {
                                                            actionValue: "cancel",
                                                            mediaType: x.UA.Video
                                                        }), Z.a.cancelProcess(), [2]
                                                }
                                            }))
                                        })),
                                        className: "btn btn--large btn-secondary px-7 pe-8 rounded-full m-auto absolute top-60 left-2/4 -translate-x-2/4 whitespace-nowrap",
                                        children: [(0, o.jsx)("img", (0, s.Z)((0, a.Z)({
                                            className: "inline-block w-8 h-8 me-2"
                                        }, m.Z), {
                                            alt: ""
                                        })), L(T.processing.cancelEnhancement)]
                                    })]
                                });
                            case x.hY.Failed:
                                return (0, o.jsx)("div", {
                                    className: "space-y-6 text-center leading-none",
                                    children: (0, o.jsx)(v.h, {
                                        highlight: !0,
                                        title: "Enhancement failed",
                                        children: (0, o.jsxs)("div", {
                                            className: "space-y-3",
                                            children: [(0, o.jsx)("p", {
                                                children: L(T.processing.unknownError)
                                            }), (0, o.jsx)("button", {
                                                type: "button",
                                                className: "btn btn--large btn--primary mx-auto",
                                                onClick: function() {
                                                    P(), _ && E.replace({
                                                        query: (0, s.Z)((0, a.Z)({}, E.query), {
                                                            mediaType: _
                                                        })
                                                    }, void 0, {
                                                        shallow: !0
                                                    })
                                                },
                                                children: L(T.common.retry)
                                            })]
                                        })
                                    })
                                });
                            case x.hY.Completed:
                                return (0, o.jsxs)("div", {
                                    className: "space-y-6 text-center leading-none",
                                    children: [(0, o.jsx)("img", (0, s.Z)((0, a.Z)({}, u), {
                                        className: "inline-block",
                                        alt: ""
                                    })), (0, o.jsx)("h3", {
                                        className: "text-black SB25",
                                        children: L(A ? T.processing.videoEnhancedSuccess : T.processing.imageEnhancedSuccess)
                                    })]
                                });
                            default:
                                return null
                        }
                    }()
                }))
            }
        },
        42980: function(e, n, t) {
            var i = t(26042),
                a = t(69396),
                s = t(85893),
                r = t(2804),
                c = t(37954),
                o = t(62152),
                l = t(73916),
                d = (t(67294), t(11503)),
                u = t(87292),
                h = t(31090);

            function m(e) {
                var n = e.className,
                    t = void 0 === n ? "" : n,
                    m = e.children,
                    f = e.canClickToHomePage,
                    x = void 0 === f || f,
                    p = (0, r.Zl)((0, d.Z)("home")),
                    g = (0, r.rb)(h.FU);
                return (0, s.jsxs)("header", {
                    className: "container-full flex py-2 justify-between items-center ".concat(t),
                    children: [(0, s.jsx)("div", {
                        className: "flex flex-1 sm:me-4",
                        children: x ? (0, s.jsx)(c.Z, {
                            path: "/",
                            children: (0, s.jsxs)("a", {
                                onClick: function() {
                                    g(), p({
                                        status: u.hY.Pristine
                                    })
                                },
                                className: "leading-none py-4",
                                children: [(0, s.jsx)("img", (0, a.Z)((0, i.Z)({}, o.Z), {
                                    className: "hidden md:block",
                                    alt: "Remini Web"
                                })), (0, s.jsx)("img", (0, a.Z)((0, i.Z)({}, l.Z), {
                                    className: "md:hidden",
                                    alt: "Remini Web"
                                }))]
                            })
                        }) : (0, s.jsxs)("div", {
                            className: "leading-none py-4",
                            children: [(0, s.jsx)("img", (0, a.Z)((0, i.Z)({}, o.Z), {
                                className: "hidden md:block",
                                alt: "Remini Web"
                            })), (0, s.jsx)("img", (0, a.Z)((0, i.Z)({}, l.Z), {
                                className: "md:hidden",
                                alt: "Remini Web"
                            }))]
                        })
                    }), (0, s.jsx)("div", {
                        className: "flex items-center space-s-4 md:space-s-8",
                        children: m
                    })]
                })
            }
            m.Divider = function(e) {
                var n = e.className,
                    t = void 0 === n ? "" : n;
                return (0, s.jsx)("hr", {
                    className: "w-0 h-5 contrast-lower sm:border-r border-current ".concat(t)
                })
            }, n.Z = m
        },
        95592: function(e, n, t) {
            t.d(n, {
                X: function() {
                    return m
                }
            });
            var i = t(85893),
                a = t(20081),
                s = t(9008),
                r = t.n(s),
                c = t(2804),
                o = t(10238),
                l = t(72522),
                d = t(2502),
                u = t(50777),
                h = t(11163);

            function m(e) {
                var n = e.title,
                    t = e.children,
                    s = e.shouldAvoidIndexing,
                    m = void 0 !== s && s,
                    f = e.isLoading,
                    x = void 0 !== f && f,
                    p = (0, c.sJ)(l.Ut),
                    g = (0, c.sJ)(u.Z),
                    v = (0, h.useRouter)().asPath.split("?")[0],
                    b = (0, d.ql)().isReady;
                return (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsxs)(r(), {
                        children: [(0, i.jsxs)("title", {
                            children: ["Remini Web | ", n]
                        }), (0, i.jsx)("link", {
                            rel: "icon",
                            href: "/favicon.ico"
                        }), (0, i.jsx)("meta", {
                            httpEquiv: "X-UA-Compatible",
                            content: "IE=edge"
                        }), m && (0, i.jsx)("meta", {
                            name: "robots",
                            content: "noindex,nofollow"
                        }), (0, i.jsx)("meta", {
                            name: "viewport",
                            content: "width=device-width, initial-scale=1"
                        }), (0, i.jsx)("link", {
                            rel: "canonical",
                            href: v
                        }), ";"]
                    }), (0, i.jsx)(a.E.div, {
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: g.areReady ? 1 : 0
                        },
                        exit: {
                            opacity: 0
                        },
                        className: "w-full h-full",
                        "aria-busy": p,
                        "aria-live": "polite",
                        children: t
                    }), (!g.areReady || !b || x) && (0, i.jsx)("div", {
                        className: "fixed inset-0 flex justify-center items-center z-50 bg-black-background",
                        children: (0, i.jsx)(a.E.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            transition: {
                                duration: .5,
                                ease: "circIn",
                                delay: .5
                            },
                            children: (0, i.jsx)(o.gy, {
                                color: "white",
                                height: "80",
                                width: "80",
                                "aria-label": "loading"
                            })
                        })
                    })]
                })
            }
        },
        10290: function(e, n, t) {
            t.d(n, {
                D: function() {
                    return i
                }
            });
            var i = (0, t(2804).cn)({
                key: "media:previousMediaType",
                default: void 0
            })
        }
    }
]);
//# sourceMappingURL=4048-47c43bea6a8c2034.js.map