"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [95], {
        40095: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return h
                }
            });
            var a = n(26042),
                o = n(99534),
                i = n(828),
                r = n(85893),
                u = n(67294),
                c = n(51646),
                l = n(50840),
                s = n.n(l),
                d = n(2804),
                f = n(17416),
                v = n(12304);

            function m(e, t) {
                var n = t.center,
                    a = t.scale,
                    o = t.trim,
                    i = t.anchor,
                    r = void 0 === i ? new v.O(-1) : i,
                    l = (0, u.useState)(),
                    s = l[0],
                    d = l[1];
                return (0, u.useEffect)((function() {
                    if (e && e.valid) {
                        var t = new c.jyi(e.clone());
                        return d(t),
                            function() {
                                return t.destroy(!0)
                            }
                    }
                }), [e, null === e || void 0 === e ? void 0 : e.valid]), (0, u.useEffect)((function() {
                    if (s && !s.destroyed && e.valid) {
                        var t = r.add(new v.O(1)).multiplyScalar(.5);
                        s.anchor.copyFrom(t);
                        var i = (new v.O).copyFrom(e);
                        s.scale.set(a, a);
                        var u = i.multiplyScalar(a),
                            l = n.add(u.multiply(r).multiplyScalar(.5));
                        if (s.position.copyFrom(l), o) {
                            var d = n.subtract(u.multiplyScalar(.5)),
                                f = o.subtract(d).multiplyScalar(1 / a).clamp(v.O.ZERO, i),
                                m = new c.AeJ(r.x < 0 ? 0 : f.x, r.y < 0 ? 0 : f.y, r.x > 0 ? i.width - f.x : f.x, r.y > 0 ? i.height - f.y : f.y);
                            s.texture.frame = m, s.texture.updateUvs()
                        }
                    }
                }), [r, n, a, s, e, o]), (0, u.useMemo)((function() {
                    return s && !s.destroyed ? s : null
                }), [s, null === s || void 0 === s ? void 0 : s.destroyed])
            }

            function p(e) {
                var t = (0, u.useState)({
                        status: "pending"
                    }),
                    n = t[0],
                    a = t[1],
                    o = (0, u.useState)(null),
                    i = o[0],
                    r = o[1];
                return (0, u.useEffect)((function() {
                    var t, n = !1;
                    return a({
                            status: "pending"
                        }), c.xEZ.fromURL(e, {}).then((function(e) {
                            n ? e.destroy(!0) : (e.baseTexture.mipmap = c.WBB.ON, c.Xdb.RESOLUTION = window.devicePixelRatio, r(e), a({
                                status: "completed"
                            }), t = e)
                        })).catch((function() {
                            a({
                                status: "failed",
                                error: new Error("The texture failed loading.")
                            })
                        })).finally((function() {
                            n = !1
                        })),
                        function() {
                            t ? t.destroy(!0) : n = !0
                        }
                }), [e]), {
                    texture: i,
                    status: n
                }
            }
            var y = n(81337),
                w = n(91024);

            function h(e) {
                var t = e.className,
                    n = void 0 === t ? "" : t,
                    l = e.beforeSrc,
                    h = e.afterSrc,
                    x = e.canvasSize,
                    b = e.initialFit,
                    S = e.disablePan,
                    E = e.disablePinch,
                    O = e.backgroundColor,
                    C = e.trim,
                    g = e.onPan,
                    k = e.onZoom,
                    L = e.onLoadComplete,
                    F = e.onLoadStart,
                    M = e.onLoadFail,
                    Z = (0, o.Z)(e, ["className", "beforeSrc", "afterSrc", "canvasSize", "initialFit", "disablePan", "disablePinch", "backgroundColor", "trim", "onPan", "onZoom", "onLoadComplete", "onLoadStart", "onLoadFail"]),
                    N = (0, u.useRef)(null),
                    P = (0, u.useState)(),
                    R = P[0],
                    _ = P[1],
                    T = (0, u.useState)(null),
                    U = T[0],
                    z = T[1],
                    D = (0, u.useState)(new v.O(.5)),
                    I = D[0],
                    j = D[1],
                    A = (0, f.S)(),
                    B = (0, u.useMemo)((function() {
                        return x.multiply(I)
                    }), [I, x]),
                    V = (0, i.Z)((0, d.FV)((0, w.Z)("".concat(l, ":").concat(h))), 2),
                    X = V[0],
                    Y = V[1],
                    J = p(A ? h : l),
                    W = J.texture,
                    q = J.status,
                    G = p(A ? l : h),
                    H = G.texture,
                    K = G.status;
                (0, u.useEffect)((function() {
                    F && F()
                }), [F, l, h]), (0, u.useEffect)((function() {
                    L && "completed" === q.status && "completed" === K.status ? L() : !M || "failed" !== q.status && "failed" !== K.status || M(q.error || K.error)
                }), [L, M, q, K]);
                var Q = (0, i.Z)((0, d.FV)((0, y.Z)("".concat(l, ":").concat(h))), 2),
                    $ = Q[0],
                    ee = Q[1];
                (0, u.useEffect)((function() {
                    ee(b)
                }), [ee, b]), (0, u.useEffect)((function() {
                    if (H && H.valid) {
                        var e = (new v.O).copyFrom(H),
                            t = x.divide(e),
                            n = 1;
                        switch ($) {
                            case "cover":
                                n = t.max();
                                break;
                            case "contain":
                                n = t.min();
                                break;
                            case "none":
                                return
                        }
                        j(new v.O(.5)), Y(n)
                    }
                }), [$, x, H, W, Y]);
                var te = X;
                (null === H || void 0 === H ? void 0 : H.valid) && (null === W || void 0 === W ? void 0 : W.valid) && (te *= H.width / W.width);
                var ne = m(W, {
                        center: B,
                        scale: te,
                        anchor: (0, u.useMemo)((function() {
                            return new v.O(-1)
                        }), [])
                    }),
                    ae = (0, u.useMemo)((function() {
                        return new v.O(1)
                    }), []),
                    oe = (0, u.useMemo)((function() {
                        return new v.O(C, 0)
                    }), [C]),
                    ie = m(H, {
                        center: B,
                        scale: X,
                        anchor: ae,
                        trim: oe
                    });
                (0, u.useEffect)((function() {
                    if (R) return ne && ie ? (R.stage.addChild(ne), R.stage.addChild(ie), function() {
                        R.stage.removeChild(ne), R.stage.removeChild(ie)
                    }) : void 0
                }), [R, ne, ie]);
                var re = (0, u.useCallback)((function(e) {
                        if (null === H || void 0 === H ? void 0 : H.valid) {
                            var t = (new v.O).copyFrom(H).multiplyScalar(e).divide(x).multiplyScalar(.5),
                                n = new v.O(.5).add(new v.O(.5).subtract(t));
                            return [new v.O(Math.min(t.x, n.x), Math.min(t.y, n.y)), new v.O(Math.max(t.x, n.x), Math.max(t.y, n.y))]
                        }
                        return [.5, .5]
                    }), [H, x]),
                    ue = (0, u.useCallback)((function(e) {
                        e.preventDefault(), ee("none"), Y((function(t) {
                            return t + .01 * -e.deltaY
                        })), "function" === typeof k && k()
                    }), [ee, Y, k]),
                    ce = (0, u.useState)(0),
                    le = ce[0],
                    se = ce[1],
                    de = (0, u.useCallback)((function() {
                        se(-1)
                    }), []),
                    fe = (0, u.useCallback)((function(e) {
                        ee("none"), se(e.scale), -1 !== le && Y((function(t) {
                            return t + e.scale - le
                        })), "function" === typeof k && k()
                    }), [ee, Y, k, le]);
                (0, u.useEffect)((function() {
                    j((function(e) {
                        return e.clamp(re(X)[0], re(X)[1])
                    }))
                }), [X, re]);
                var ve = (0, u.useState)(new v.O),
                    me = ve[0],
                    pe = ve[1],
                    ye = (0, u.useCallback)((function(e) {
                        var t = new v.O(e.deltaX, e.deltaY),
                            n = t.subtract(me).divide(x);
                        pe(t), ee("none"), j((function(e) {
                            return e.add(n).clamp(re(X)[0], re(X)[1])
                        })), "function" === typeof g && g()
                    }), [ee, me, g, X, x, re]),
                    we = function() {
                        pe(new v.O)
                    },
                    he = (0, u.useCallback)((function(e) {
                        e.preventDefault()
                    }), []);
                return (0, u.useEffect)((function() {
                    if (R && U && !U.destroyed) return R.view.addEventListener("contextmenu", he), S || (U.on("panmove", ye), U.on("panend", we)), E || (R.view.addEventListener("wheel", ue), U.on("pinchstart", de), U.on("pinchmove", fe)),
                        function() {
                            R.view.removeEventListener("contextmenu", he), S || (U.off("panmove", ye), U.off("panend", we)), E || (R.view.removeEventListener("wheel", ue), U.on("pinchstart", de), U.off("pinchmove", fe))
                        }
                }), [R, U, S, E, ye, de, fe, ue, he]), (0, u.useEffect)((function() {
                    if (R) {
                        var e = x.width,
                            t = x.height;
                        R.view.style.width = "".concat(e, "px"), R.view.style.height = "".concat(t, "px"), R.renderer.resize(e, t), R.render()
                    }
                }), [R, x]), (0, u.useEffect)((function() {
                    var e, t = new c.MxU({
                        backgroundColor: O
                    });
                    null === (e = N.current) || void 0 === e || e.appendChild(t.view), _(t);
                    var n = new(s())(t.view);
                    return n.get("pinch").set({
                            enable: !0
                        }), n.get("pan").set({
                            direction: s().DIRECTION_ALL
                        }), z(n),
                        function() {
                            t.destroy(!0, !0), n.destroy(), n._destroyed = !0
                        }
                }), [O]), (0, r.jsx)("div", (0, a.Z)({
                    ref: N,
                    className: "".concat((null === H || void 0 === H ? void 0 : H.valid) ? "opacity-100" : "opacity-0", " transition-opacity duration-1000 ").concat(n)
                }, Z))
            }
        }
    }
]);
//# sourceMappingURL=95.3ec3ac8e5d485607.js.map