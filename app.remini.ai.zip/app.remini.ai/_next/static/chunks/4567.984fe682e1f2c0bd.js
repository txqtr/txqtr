"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4567], {
        14567: function(e, t, o) {
            o.r(t), o.d(t, {
                default: function() {
                    return p
                }
            });
            var n = o(26042),
                i = o(69396),
                a = o(99534),
                r = o(85893),
                s = o(67294),
                c = o(50840),
                l = o.n(c),
                u = o(89784),
                d = o(2502),
                f = {
                    src: "/_next/static/media/chevron--horizontal.f2c9aedc.svg",
                    height: 32,
                    width: 32
                },
                m = o(91099);

            function p(e) {
                var t = e.badgesAlignment,
                    o = e.borderWidth,
                    c = void 0 === o ? 1 : o,
                    p = e.offset,
                    v = e.onChange,
                    h = e.style,
                    b = void 0 === h ? {} : h,
                    x = e.sliderBehavior,
                    w = e.showTooltip,
                    N = void 0 !== w && w,
                    g = e.className,
                    y = void 0 === g ? "" : g,
                    C = (0, a.Z)(e, ["badgesAlignment", "borderWidth", "offset", "onChange", "style", "sliderBehavior", "showTooltip", "className"]),
                    k = (0, s.useRef)(),
                    E = (0, s.useState)(0),
                    j = E[0],
                    Z = E[1],
                    S = (0, s.useState)(),
                    z = S[0],
                    L = S[1],
                    _ = (0, s.useState)(N),
                    D = _[0],
                    M = _[1],
                    R = (0, d.ql)(),
                    T = R.t,
                    W = R.data;
                (0, s.useEffect)((function() {
                    var e = new(l())(k.current);
                    return e.get("pan").set({
                            direction: l().DIRECTION_ALL
                        }), L(e),
                        function() {
                            return e.destroy()
                        }
                }), []);
                var A = function() {
                        var e = k.current.offsetLeft;
                        Z(e)
                    },
                    B = (0, s.useCallback)((function(e) {
                        v(j + e.deltaX), M(!1)
                    }), [v, j]),
                    F = (0, s.useCallback)((function(e) {
                        v(j + e.pageX)
                    }), [v, j]),
                    I = (0, s.useCallback)((function(e) {
                        F(e)
                    }), [F]);
                return (0, s.useEffect)((function() {
                    if ("hover" === x) {
                        var e = k.current.parentNode;
                        return e.addEventListener("ontouchstart" in document.documentElement ? "touchmove" : "mousemove", I),
                            function() {
                                e.removeEventListener("ontouchstart" in document.documentElement ? "touchmove" : "mousemove", I)
                            }
                    }
                }), [F, I, x]), (0, s.useEffect)((function() {
                    if ("hover" !== x) {
                        if (!z) return;
                        return z.on("panstart", A), z.on("panmove", B), z.on("panend", A),
                            function() {
                                z.off("panstart", A), z.off("panmove", B), z.off("panend", A)
                            }
                    }
                }), [z, B, x]), (0, r.jsxs)("div", (0, i.Z)((0, n.Z)({
                    className: "".concat(y, " absolute inset-y-0 w-0 border-overlay-white-70 cursor-resize-horizontal"),
                    style: (0, n.Z)({
                        left: "".concat(p - c, "px"),
                        borderLeftWidth: c,
                        borderRightWidth: c
                    }, b),
                    ref: k
                }, C), {
                    children: [(0, r.jsxs)("div", {
                        className: "absolute center-x w-8 h-8 p-12",
                        style: {
                            bottom: "top" === t ? "56px" : "110px"
                        },
                        tabIndex: 0,
                        role: "slider",
                        "aria-valuemin": 0,
                        "aria-valuemax": 100,
                        "aria-valuenow": 50,
                        "aria-orientation": "horizontal",
                        children: [(0, r.jsx)(m.u, {
                            disableForcePosition: !0,
                            visible: !!D,
                            tooltipContentClassName: "font-semibold",
                            content: W.result.moveSlider,
                            position: "top",
                            context: u.d.Slider
                        }), (0, r.jsx)("img", (0, i.Z)((0, n.Z)({}, f), {
                            className: "absolute center pointer-events-none",
                            alt: ""
                        }))]
                    }), (0, r.jsx)("p", {
                        className: "".concat("top" !== t ? "hidden" : "", " md:block absolute end-6 px-4 py-2 bg-overlay-black-60 text-white rounded-3xl pointer-events-none"),
                        style: {
                            bottom: "auto",
                            top: "top" === t ? "16px" : "100px"
                        },
                        children: T(W.common.before)
                    }), (0, r.jsx)("p", {
                        className: "".concat("top" !== t ? "hidden" : "", " md:block absolute start-6 px-4 py-2 bg-overlay-black-60 text-white rounded-3xl pointer-events-none"),
                        style: {
                            bottom: "auto",
                            top: "top" === t ? "16px" : "100px"
                        },
                        children: T(W.common.after)
                    })]
                }))
            }
        },
        89784: function(e, t, o) {
            o.d(t, {
                Z: function() {
                    return m
                },
                d: function() {
                    return n
                }
            });
            var n, i = o(26042),
                a = o(69396),
                r = o(85893),
                s = o(67294),
                c = o(14332),
                l = o(20081),
                u = o(85727),
                d = o(84844),
                f = {
                    bottom: {
                        tooltip: "top-full start-0 pt-2 mt-2",
                        arrow: "-top-1"
                    },
                    top: {
                        tooltip: "bottom-full start-0 pb-2 mb-2",
                        arrow: "-bottom-1"
                    }
                };

            function m(e) {
                var t = e.visible,
                    o = void 0 !== t && t,
                    m = e.position,
                    p = void 0 === m ? "bottom" : m,
                    v = e.content,
                    h = void 0 === v ? "" : v,
                    b = e.duration,
                    x = e.className,
                    w = void 0 === x ? "" : x,
                    N = e.tooltipOuterClassName,
                    g = void 0 === N ? "" : N,
                    y = e.tooltipClassName,
                    C = void 0 === y ? "" : y,
                    k = e.tooltipContentClassName,
                    E = void 0 === k ? "" : k,
                    j = e.disableForcePosition,
                    Z = e.afterDisappear,
                    S = e.children,
                    z = e.context,
                    L = void 0 === z ? n.Download : z,
                    _ = (0, s.useState)(!1),
                    D = _[0],
                    M = _[1],
                    R = (0, s.useState)(!1),
                    T = R[0],
                    W = R[1],
                    A = (0, s.useState)(!1),
                    B = A[0],
                    F = A[1],
                    I = (0, s.useRef)(null),
                    O = (0, s.useCallback)((function() {
                        if (I.current)
                            if (j) M(!1);
                            else {
                                var e = I.current.getBoundingClientRect(),
                                    t = e.top + window.scrollX,
                                    o = e.height,
                                    n = window.innerHeight - t - o;
                                M(n < o + 100 ? "top" : t < o + 100 && "bottom")
                            }
                    }), [j]);
                (0, s.useEffect)((function() {
                    O()
                }), [O]), (0, s.useEffect)((function() {
                    var e;
                    return b && (e = setTimeout((function() {
                            W(!0), "function" === typeof Z && Z()
                        }), b)),
                        function() {
                            return clearTimeout(e)
                        }
                }), [b, Z]), (0, u.Z)(null, "resize", O);
                var X = (0, s.useMemo)((function() {
                        return (0, d.vO)() === d.VF.Desktop
                    }), []),
                    P = D || p;
                return (0, r.jsxs)("div", (0, a.Z)((0, i.Z)({
                    className: "relative flex flex-col items-center ".concat(w)
                }, X && {
                    onMouseEnter: function() {
                        return F(!T)
                    },
                    onMouseLeave: function() {
                        return F(!1)
                    }
                }), {
                    children: [S, (0, r.jsx)(c.M, {
                        children: !!o && (!T || B) && (0, r.jsx)(l.E.div, {
                            ref: I,
                            className: "".concat(L === n.Slider ? "relative bottom-16 w-40" : "absolute w-full", "  z-50 flex flex-col items-center ").concat(f[P].tooltip, " ").concat(g),
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .2
                            },
                            children: (0, r.jsxs)("div", {
                                className: "relative text-center flex flex-col items-center bg-white M13 text-black rounded-full py-2 px-6 ".concat(C),
                                children: [(0, r.jsx)("div", {
                                    className: "absolute w-4 h-4 min-w-4 min-h-4 z-0 bg-white rounded-sm rotate-45 ".concat(f[P].arrow)
                                }), (0, r.jsx)("div", {
                                    className: "z-10 ".concat(E),
                                    children: h
                                })]
                            })
                        })
                    })]
                }))
            }! function(e) {
                e.Download = "download", e.Slider = "slider"
            }(n || (n = {}))
        },
        91099: function(e, t, o) {
            o.d(t, {
                u: function() {
                    return n.Z
                }
            });
            var n = o(89784)
        }
    }
]);
//# sourceMappingURL=4567.984fe682e1f2c0bd.js.map