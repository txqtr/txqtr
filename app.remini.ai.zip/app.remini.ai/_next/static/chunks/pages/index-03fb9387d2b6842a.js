(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5405], {
        48312: function(e, t, n) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/", function() {
                return n(68902)
            }])
        },
        17175: function(e, t) {
            "use strict";
            t.Z = {
                src: "/_next/static/media/down_small.1bf62862.svg",
                height: 17,
                width: 16
            }
        },
        173: function(e, t, n) {
            "use strict";
            n.d(t, {
                F: function() {
                    return c
                }
            });
            var r = n(26042),
                o = n(69396),
                a = n(99534),
                i = n(85893),
                s = n(87292);
            n(67294);

            function c(e) {
                var t = e.children,
                    n = e.forId,
                    c = e.className,
                    l = void 0 === c ? "" : c,
                    d = (0, a.Z)(e, ["children", "forId", "className"]);
                return (0, i.jsx)("label", (0, o.Z)((0, r.Z)({
                    role: "button",
                    tabIndex: 0,
                    onKeyDown: function(e) {
                        if ("Enter" === e.key || " " === e.key) {
                            e.preventDefault();
                            var t = document.getElementById("".concat(s.VK, "-").concat(n));
                            null === t || void 0 === t || t.click()
                        }
                    },
                    className: "cursor-pointer ".concat(l),
                    htmlFor: "".concat(s.VK, "-").concat(n)
                }, d), {
                    children: t
                }))
            }
        },
        99465: function(e, t, n) {
            "use strict";
            n.d(t, {
                S: function() {
                    return k
                }
            });
            var r = n(47568),
                o = n(828),
                a = n(70655),
                i = n(85893),
                s = n(88263),
                c = n(6807),
                l = n(45291),
                d = n(2502),
                u = n(87292),
                m = n(13807),
                f = n(11503),
                p = n(92876),
                h = n(14332),
                x = n(20081),
                v = n(11163),
                b = n(67294),
                g = n(2804),
                y = n(29144),
                j = n(23141);

            function k(e) {
                var t, n = e.id,
                    k = e.enableDragAndDrop,
                    w = void 0 === k || k,
                    N = e.onUpload,
                    C = e.onScroll,
                    S = e.children,
                    Z = (0, d.ql)(),
                    E = Z.t,
                    T = Z.data,
                    _ = (0, s.Z)(N),
                    M = (0, j.Z)(n).upload,
                    F = (0, o.Z)((0, g.FV)((0, f.Z)(n)), 2),
                    L = F[0],
                    I = F[1],
                    P = (0, g.rb)((0, f.Z)(n)),
                    R = (0, b.useState)(),
                    A = R[0],
                    D = R[1],
                    B = (0, v.useRouter)(),
                    V = (0, b.useRef)(0),
                    U = (0, l.DX)().isBusinessUser,
                    O = (0, b.useState)(!1),
                    G = O[0],
                    q = O[1],
                    z = (0, c.Z)(G),
                    J = (0, m.aF)().data,
                    K = U(J);
                (0, b.useEffect)((function() {
                    if (G) {
                        var e = window.setTimeout((function() {
                            z() && P()
                        }), 50);
                        return function() {
                            return window.clearTimeout(e)
                        }
                    }
                }), [G, z, P]);
                var W = L.status === u.hY.Uploading || L.status === u.hY.Processing,
                    X = L.status !== u.hY.Pristine,
                    H = (0, b.useRef)(),
                    Q = (0, b.useState)(!1),
                    Y = Q[0],
                    $ = Q[1];
                (0, b.useEffect)((function() {
                    X && ($(H.current.scrollTop), H.current.scrollTop = 0)
                }), [X]), (0, b.useEffect)((function() {
                    X || (H.current.scrollTop = Y)
                }), [X, Y]);
                var ee = (0, b.useCallback)((function() {
                    var e;
                    C && C((null === (e = H.current) || void 0 === e ? void 0 : e.scrollTop) > 25)
                }), [C]);
                (0, b.useEffect)((function() {
                    var e, t = null === (e = H.current) || void 0 === e ? void 0 : e.addEventListener("scroll", ee);
                    return function() {
                        return null === t || void 0 === t ? void 0 : t.removeEventListener("scroll", ee)
                    }
                }), [ee]);
                var te = function() {
                    var e = (0, r.Z)((function(e, t) {
                        return (0, a.__generator)(this, (function(n) {
                            return e ? (D(e[0]), V.current = e.length, delete B.query.taskId, B.push(B), W || M(e, t, E, T).then((function(e) {
                                return "undefined" !== typeof e && _(e)
                            })).catch((function(e) {
                                console.error(e), p.Tb(e)
                            })), [2]) : [2]
                        }))
                    }));
                    return function(t, n) {
                        return e.apply(this, arguments)
                    }
                }();
                return (0, i.jsxs)("div", {
                    ref: H,
                    className: "h-full relative ".concat(X ? "overflow-hidden" : "overflow-auto lg:tall:overflow-hidden"),
                    onDragOver: function(e) {
                        w && (e.preventDefault(), e.dataTransfer.dropEffect = "copy", W || (q(!1), "draft" !== L.status && I({
                            status: "draft"
                        })))
                    },
                    onDrop: function(e) {
                        w && (e.preventDefault(), W || q(!0), te(e.dataTransfer.files, "drag"))
                    },
                    onDragLeave: function() {
                        w && (W || q(!0))
                    },
                    onDragEnd: function() {
                        w && (W || P())
                    },
                    children: [(0, i.jsx)("input", {
                        multiple: K,
                        type: "file",
                        accept: (null === J || void 0 === J || null === (t = J.monetization) || void 0 === t ? void 0 : t.hasIncompleteSubscription) ? "image/*,.heic,.tga" : "image/*,.heic,.tga,video/*",
                        id: "".concat(u.VK, "-").concat(n),
                        className: "invisible block w-0 h-0 overflow-hidden",
                        onClick: function(e) {
                            e.target.value = ""
                        },
                        onChange: function(e) {
                            return te(e.target.files, "browse")
                        }
                    }), (0, i.jsx)("div", {
                        className: "h-full relative z-0 ".concat(X ? "pointer-events-none" : ""),
                        children: S
                    }, "content"), (0, i.jsx)(h.M, {
                        children: X && (0, i.jsx)(x.E.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            className: "absolute inset-0 z-60",
                            children: (0, i.jsx)(y.Z, {
                                mediaType: (null === A || void 0 === A ? void 0 : A.type) || u.UA.Video,
                                isBulkUpload: V.current > 1,
                                forId: n
                            })
                        }, "progress")
                    })]
                })
            }
        },
        85562: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var r = n(85893),
                o = (n(67294), n(2502));

            function a(e) {
                var t = e.className,
                    n = void 0 === t ? "" : t,
                    a = (0, o.ql)(),
                    i = a.t,
                    s = a.data;
                return (0, r.jsxs)("footer", {
                    className: "container py-8 max-w-md text-overlay-white-40 ".concat(n),
                    children: [(0, r.jsx)("button", {
                        type: "button",
                        className: "R11 rounded-3xl px-2 py-1.5 space-s-2 border-1.5 items-end justify-end transition-colors mb-2 border-overlay-white-15 hover:bg-overlay-white-5",
                        onClick: function() {
                            var e, t;
                            null === (e = window.OneTrust) || void 0 === e || null === (t = e.ToggleInfoDisplay) || void 0 === t || t.call(e)
                        },
                        children: i(s.footer.cookiePrefs)
                    }), (0, r.jsx)("p", {
                        className: "R10 mb-2",
                        children: "Copyright \xa9 AI Creativity S.r.l. | Via Nino Bonnet 10, 20154 Milan, Italy | VAT, tax code, and number of registration with the Milan Monza Brianza Lodi Company Register 13250480962 | REA number MI 2711925 | Contributed capital \u20ac10.000,00 | Sole shareholder company subject to the management and coordination of Bending Spoons S.p.A."
                    })]
                })
            }
        },
        53956: function(e, t, n) {
            "use strict";
            n.d(t, {
                W: function() {
                    return p
                }
            });
            var r = n(828),
                o = n(85893),
                a = n(14332),
                i = n(20081),
                s = n(2804),
                c = n(99158),
                l = (n(67294), n(26042)),
                d = n(69396),
                u = {
                    src: "/_next/static/media/hamburger.599142e5.svg",
                    height: 14,
                    width: 20
                },
                m = (0, s.cn)({
                    key: "layout/navigation/isOpen",
                    default: !1
                });

            function f(e) {
                var t = e.children,
                    n = e.className,
                    l = void 0 === n ? "" : n,
                    d = (0, r.Z)((0, s.FV)(m), 2),
                    u = d[0],
                    f = d[1];
                return (0, o.jsx)(a.M, {
                    children: u && (0, o.jsxs)("div", {
                        className: "h-full w-full flex justify-end ".concat(l),
                        children: [(0, o.jsx)(i.E.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            className: "absolute inset-0 bg-overlay-black-70",
                            onClick: function() {
                                return f(!1)
                            }
                        }), (0, o.jsxs)(i.E.nav, {
                            className: "section-middleground w-full max-w-sm p-6 space-y-6 ms-6",
                            initial: {
                                x: "100%"
                            },
                            animate: {
                                x: 0
                            },
                            exit: {
                                x: "100%"
                            },
                            transition: {
                                type: "tween"
                            },
                            children: [(0, o.jsx)("button", {
                                type: "button",
                                onClick: function() {
                                    return f(!1)
                                },
                                children: (0, o.jsx)(c.Tw, {})
                            }), t]
                        })]
                    })
                })
            }
            f.Button = function(e) {
                var t = e.className,
                    n = void 0 === t ? "" : t,
                    a = (0, r.Z)((0, s.FV)(m), 2),
                    i = a[0],
                    c = a[1];
                return (0, o.jsx)("button", {
                    "data-cy": "hamburger-btn",
                    className: "".concat(n),
                    "aria-pressed": i,
                    onClick: function() {
                        return c(!i)
                    },
                    type: "button",
                    children: (0, o.jsx)("img", (0, d.Z)((0, l.Z)({}, u), {
                        alt: "Open menu",
                        style: {
                            minWidth: 20
                        }
                    }))
                })
            };
            var p = f
        },
        68902: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return te
                }
            });
            var r = n(26042),
                o = n(69396),
                a = n(85893),
                i = n(75733),
                s = {
                    src: "/_next/static/media/home-sketch.9bb84f05.svg",
                    height: 18,
                    width: 112
                },
                c = {
                    src: "/_next/static/media/photo.f00bce54.svg",
                    height: 26,
                    width: 27
                },
                l = {
                    src: "/_next/static/media/upload-white.e68b14d4.svg",
                    height: 30,
                    width: 30
                },
                d = {
                    src: "/_next/static/media/video.9d680ac6.svg",
                    height: 26,
                    width: 27
                },
                u = n(20081),
                m = n(67294),
                f = n(2502),
                p = n(37954);

            function h(e) {
                var t = e.className,
                    n = void 0 === t ? "" : t,
                    r = function() {
                        var e = (0, f.ql)(),
                            t = e.t,
                            n = e.data,
                            r = (0, m.useCallback)((function(e) {
                                return e.stopPropagation()
                            }), []),
                            o = (0, m.useCallback)((function(e) {
                                return e.stopPropagation()
                            }), []);
                        return {
                            acceptTermsText: t(n.common.byContinuingAcceptTosAndPrivacy, {
                                tos: function(e) {
                                    return (0, a.jsx)("a", {
                                        className: "underline",
                                        href: "https://bendingspoons.com/tos.html?app=1470373330",
                                        target: "_blank",
                                        rel: "noreferrer nofollow",
                                        onClick: r,
                                        children: e
                                    })
                                },
                                privacy: function(e) {
                                    return (0, a.jsx)(p.Z, {
                                        path: "/privacy-and-cookie-policy",
                                        children: (0, a.jsx)("a", {
                                            className: "underline",
                                            target: "_blank",
                                            onClick: o,
                                            children: e
                                        })
                                    })
                                }
                            })
                        }
                    }().acceptTermsText;
                return (0, a.jsx)("p", {
                    className: "R12 contrast-low ".concat(n),
                    children: r
                })
            }
            var x = n(173),
                v = n(99465),
                b = n(96095),
                g = n(92665);

            function y() {
                var e = function() {
                        var e = (0, f.ql)(),
                            t = e.t,
                            n = e.data,
                            r = (0, g.Q4)().track,
                            o = (0, m.useCallback)((function() {
                                var e;
                                r("video_promotion", "tapped", {
                                    source: "badge"
                                }), null === (e = document.getElementById("uploader-file-input-home")) || void 0 === e || e.click()
                            }), [r]);
                        return {
                            onClick: o,
                            badgeLabel: n.common.new,
                            badgeId: b.q.F.New,
                            tryVideoEnhanceText: t(n.common.tryVideoEnhance)
                        }
                    }(),
                    t = e.onClick,
                    n = e.badgeLabel,
                    r = e.tryVideoEnhanceText,
                    o = e.badgeId;
                return (0, a.jsxs)("div", {
                    onClick: t,
                    className: "flex cursor-pointer items-center mb-5 p-2 pe-4 bg-overlay-black-20 rounded-full w-content",
                    children: [(0, a.jsx)(b.C, {
                        id: o,
                        label: n,
                        hidden: !1,
                        absolutePositioned: !1
                    }), (0, a.jsx)("p", {
                        className: "text-white uppercase font-bold text-[10px] tracking-widest ms-2",
                        children: r
                    })]
                })
            }
            var j = n(3863),
                k = n(17175),
                w = n(13807),
                N = n(85562),
                C = n(42980),
                S = n(95592),
                Z = n(53956),
                E = n(50777),
                T = n(2804),
                _ = 0;

            function M(e) {
                var t = function() {
                        var e = (0, T.sJ)(E.Z);
                        return {
                            variants: {
                                hidden: {
                                    opacity: 0,
                                    y: 50
                                },
                                visible: {
                                    opacity: 1,
                                    y: 0,
                                    transition: {
                                        duration: .3,
                                        delay: .1 * _++
                                    }
                                }
                            },
                            animate: e.areReady ? "visible" : "hidden"
                        }
                    }(),
                    n = t.variants,
                    o = t.animate;
                return (0, a.jsx)(u.E.div, (0, r.Z)({
                    variants: n,
                    initial: "hidden",
                    animate: o
                }, e))
            }
            var F = n(77104),
                L = n(11163),
                I = n(80904),
                P = n(8203),
                R = n(47568),
                A = n(828),
                D = n(70655),
                B = n(94412),
                V = n(45291),
                U = n(99656),
                O = n(82532),
                G = n(35277);

            function q(e) {
                var t = e.id,
                    n = e.hasError,
                    r = e.errorMessage,
                    o = e.onClose,
                    i = (0, T.Zl)(I.u2),
                    s = (0, w.aF)().data;
                return (0, a.jsxs)(B.AB, {
                    onClose: o,
                    className: "p-8 px-6 md:p-12 section-foreground rounded-3xl",
                    children: [!n && !(null === s || void 0 === s ? void 0 : s.giftCode.isActive) && (0, a.jsxs)("div", {
                        className: "space-y-4 text-center",
                        children: [(0, a.jsx)("h3", {
                            className: "SB20 text-center",
                            children: "Gift Code Added \u2705"
                        }), (0, a.jsx)("p", {
                            children: "The gift code has been added to your account!"
                        }), (0, a.jsx)("button", {
                            type: "button",
                            className: "btn btn--large btn--primary mt-4 mx-auto",
                            children: "Ok, Got It"
                        })]
                    }), n && (0, a.jsx)(G.h, {
                        title: r,
                        children: (0, a.jsx)("div", {
                            className: "space-y-4",
                            children: (0, a.jsx)("button", {
                                type: "button",
                                className: "btn btn--large btn--primary mt-4 mx-auto",
                                onClick: function() {
                                    return i(t)
                                },
                                children: "Ok, Got It"
                            })
                        })
                    })]
                })
            }
            var z = n(9759);

            function J(e, t, n) {
                var r = "failed" === e && n ? {
                    redeemCode: t,
                    error: "".concat(n)
                } : {
                    redeemCode: t
                };
                (0, z.L9)(["giftcode", e], r)
            }
            var K = function(e) {
                    J("submitted", e)
                },
                W = function(e) {
                    J("accepted", e)
                },
                X = function(e, t) {
                    J("failed", e, t)
                };

            function H(e) {
                var t = e.id,
                    n = e.isGuestToken,
                    r = e.redeemCodeValue,
                    o = (0, T.Zl)(I.su),
                    i = (0, T.Zl)(I.u2),
                    s = (0, V.JC)().postRedeem,
                    c = (0, w.aF)(),
                    l = c.data,
                    d = c.mutate,
                    u = (0, g.Q4)().track,
                    f = (0, A.Z)((0, U.r)(), 2)[1];
                (0, m.useEffect)((function() {
                    u("gift_code", "submitted", {
                        redeemCode: r
                    }), K(r)
                }), [r, u]);
                var p = function() {
                    var e = (0, R.Z)((function(e, t) {
                        return (0, D.__generator)(this, (function(n) {
                            try {
                                u("settings", "logout_tapped", {
                                    actionValue: "".concat(e.target.textContent, " (CTA)")
                                }), f(), i(t), d()
                            } catch (r) {
                                console.log(r)
                            }
                            return [2]
                        }))
                    }));
                    return function(t, n) {
                        return e.apply(this, arguments)
                    }
                }();
                return (0, a.jsxs)(B.AB, {
                    isForeground: !0,
                    className: "p-8 px-6 md:p-12 section-foreground rounded-3xl",
                    children: [n && (0, a.jsxs)("div", {
                        className: "space-y-4 text-center",
                        children: [(0, a.jsx)("h3", {
                            className: "SB20 text-center",
                            children: "Get your Gift Code! \ud83c\udf81"
                        }), (0, a.jsx)("p", {
                            children: "Login to get your gift code associated to your account"
                        }), (0, a.jsx)("button", {
                            type: "button",
                            className: "btn btn--large btn--primary mt-4 mx-auto",
                            onClick: function() {
                                o({
                                    id: "user:onboarding",
                                    Modal: O.Z,
                                    previousAction: w.Vw.Login
                                }), i(t)
                            },
                            children: "Login"
                        })]
                    }), !n && (0, a.jsxs)("div", {
                        className: "space-y-4 text-center",
                        children: [(0, a.jsx)("h3", {
                            className: "SB20 text-center",
                            children: "Add your Gift Code! \ud83c\udf81"
                        }), (0, a.jsxs)("p", {
                            children: ["Confirm to apply the gift code to", " ", (0, a.jsx)("span", {
                                className: "SB16",
                                children: null === l || void 0 === l ? void 0 : l.email
                            }), " ", (0, a.jsx)("br", {}), "or login to another account."]
                        }), (0, a.jsxs)("div", {
                            className: "flex",
                            children: [(0, a.jsx)("button", {
                                type: "button",
                                className: "btn btn--large btn--secondary mt-4 mx-auto",
                                onClick: function(e) {
                                    return p(e, t)
                                },
                                children: "Switch accounts"
                            }), (0, a.jsx)("button", {
                                type: "button",
                                className: "btn btn--large btn--primary mt-4 mx-auto",
                                onClick: function() {
                                    return s(r).then((function() {
                                        i(t), u("gift_code", "accepted", {
                                            redeemCode: r
                                        }), W(r), o({
                                            id: "user:redeem",
                                            Modal: q,
                                            hasError: !1,
                                            onClose: function() {
                                                return d()
                                            }
                                        })
                                    })).catch((function(e) {
                                        u("gift_code", "errored", {
                                            redeemCode: r,
                                            errorMessage: e.message
                                        }), X(r, e), o({
                                            id: "user:redeemError",
                                            Modal: q,
                                            hasError: !0,
                                            errorMessage: e.message,
                                            onClose: function() {
                                                return d()
                                            }
                                        }), i(t)
                                    }))
                                },
                                children: "Confirm"
                            })]
                        })]
                    })]
                })
            }

            function Q(e, t) {
                (0, m.useEffect)((function() {
                    var n = window.matchMedia(e);
                    t(n.matches);
                    var r = function(e) {
                        t(e.matches)
                    };
                    if ("function" === typeof n.addEventListener) return n.addEventListener("change", r),
                        function() {
                            n.removeEventListener("change", r)
                        }
                }), [e, t])
            }
            var Y;
            ! function(e) {
                e[e.SMALL = 0] = "SMALL", e[e.MEDIUM = 1] = "MEDIUM", e[e.LARGE = 2] = "LARGE"
            }(Y || (Y = {}));
            var $ = function() {
                    var e = (0, m.useState)({
                            beforeSrc: "",
                            afterSrc: "",
                            initialSliderProgress: 0,
                            maxSliderProgress: 0
                        }),
                        t = e[0],
                        n = e[1],
                        r = (0, m.useCallback)((function(e) {
                            return function(t) {
                                t && n(function(e, t) {
                                    var n, r = {
                                        mobile: {
                                            before: "/images/home/".concat((n = t) + 1, "/mobile/before.webp"),
                                            after: "/images/home/".concat(n + 1, "/mobile/after.webp")
                                        },
                                        desktop: {
                                            before: "/images/home/".concat(n + 1, "/before.webp"),
                                            after: "/images/home/".concat(n + 1, "/after.webp")
                                        }
                                    };
                                    return e === Y.SMALL ? {
                                        beforeSrc: r.mobile.before,
                                        afterSrc: r.mobile.after,
                                        initialSliderProgress: .5,
                                        maxSliderProgress: 1
                                    } : e === Y.MEDIUM ? {
                                        beforeSrc: r.desktop.before,
                                        afterSrc: r.desktop.after,
                                        initialSliderProgress: .325,
                                        maxSliderProgress: .4
                                    } : {
                                        beforeSrc: r.desktop.before,
                                        afterSrc: r.desktop.after,
                                        initialSliderProgress: .325,
                                        maxSliderProgress: .5
                                    }
                                }(e, 1))
                            }
                        }), [1]),
                        o = (0, m.useMemo)((function() {
                            return {
                                small: r(Y.SMALL),
                                medium: r(Y.MEDIUM),
                                large: r(Y.LARGE)
                            }
                        }), [r]);
                    return Q("(max-width: 1024px)", o.small), Q("(min-width: 1024px) and (max-width: 1300px)", o.medium), Q("(min-width: 1300px)", o.large), t
                },
                ee = function() {
                    var e = (0, T.sJ)(E.Z),
                        t = (0, L.useRouter)(),
                        n = (0, g.Q4)().track,
                        i = (0, f.ql)(),
                        s = i.t,
                        c = i.data,
                        l = $();
                    ! function() {
                        var e = (0, w.aF)().mutate,
                            t = (0, T.sJ)(P.f).isGuestToken,
                            n = (0, T.Zl)(I.su),
                            r = (0, L.useRouter)(),
                            o = (0, m.useState)(),
                            a = o[0],
                            i = o[1];
                        (0, m.useEffect)((function() {
                            var e = r.query.redeemCode;
                            e && i(e)
                        }), [r.query]), (0, m.useEffect)((function() {
                            a && n(t ? {
                                id: "user:logintoredeem",
                                Modal: H,
                                isGuestToken: !0,
                                onClose: function() {
                                    return e()
                                }
                            } : {
                                id: "user:logintoredeem",
                                Modal: H,
                                isGuestToken: !1,
                                redeemCodeValue: a,
                                onClose: function() {
                                    return e()
                                }
                            })
                        }), [n, a, e, t])
                    }(), (0, F.g)("home"),
                    function() {
                        var e = (0, T.Zl)(I.su),
                            t = (0, m.useRef)(null),
                            n = (0, V.ph)(),
                            r = n.isRedirectedFromMobile,
                            o = n.clearIsRedirectedFromMobile,
                            a = (0, m.useCallback)((function(n) {
                                e({
                                    id: "user:onboarding",
                                    Modal: j.L,
                                    previousAction: n,
                                    onClose: function() {
                                        var e;
                                        return null === (e = t.current) || void 0 === e ? void 0 : e.focus()
                                    }
                                })
                            }), [e]);
                        (0, m.useEffect)((function() {
                            r() && (a(w.Vw.Login), o())
                        }), [o, r, a])
                    }();
                    var d = (0, m.useState)(!0),
                        u = d[0],
                        h = d[1],
                        x = (0, m.useCallback)((function() {
                            u && (n("homepage", "slider_interaction"), h(!1))
                        }), [n, u]);
                    _ = 0;
                    var v = (0, m.useCallback)((function(e) {
                            return e && t.replace({
                                pathname: "".concat(t.pathname, "result"),
                                query: (0, o.Z)((0, r.Z)({}, t.query), {
                                    taskId: e
                                })
                            }, void 0, {
                                shallow: !0
                            })
                        }), [t]),
                        b = (0, m.useState)(!1),
                        y = b[0],
                        k = b[1],
                        N = (0, m.useState)(!1),
                        C = N[0],
                        S = N[1],
                        Z = (0, m.useCallback)((function(e) {
                            k(e), e && !C && S(!0)
                        }), [C]),
                        M = (0, m.useCallback)((function(e) {
                            return e.stopPropagation()
                        }), []);
                    return {
                        filePickerId: "home",
                        comparerConfig: l,
                        onComparerSlide: x,
                        onUpload: v,
                        onScroll: Z,
                        animateHeader: y,
                        hideFooter: C,
                        settings: e,
                        titleText: s(c.home.title),
                        subtitleText: s(c.home.subtitle),
                        chooseFileText1: s(c.home.chooseFiles),
                        chooseFileText2: s(c.home.chooseFile2),
                        photosText: s(c.common.photos),
                        videosText: s(c.common.videos),
                        scrollToFooterText: s(c.footer.scrollToFooter),
                        bipaText: s(c.common.bipaDisclaimer, {
                            privacy: function(e) {
                                return (0, a.jsx)(p.Z, {
                                    path: "/privacy-and-cookie-policy",
                                    children: (0, a.jsx)("a", {
                                        className: "underline",
                                        target: "_blank",
                                        onClick: M,
                                        children: e
                                    })
                                })
                            }
                        })
                    }
                };
            var te = function() {
                var e, t = ee(),
                    n = t.filePickerId,
                    m = t.comparerConfig,
                    p = t.onComparerSlide,
                    b = t.onUpload,
                    g = t.titleText,
                    E = t.subtitleText,
                    T = t.chooseFileText1,
                    _ = t.chooseFileText2,
                    F = t.photosText,
                    L = t.videosText,
                    I = t.scrollToFooterText,
                    P = t.animateHeader,
                    R = t.hideFooter,
                    A = t.onScroll,
                    D = t.settings,
                    B = t.bipaText,
                    V = (0, f.ql)(),
                    U = V.t,
                    O = V.data,
                    G = (0, w.aF)().data;
                return (0, a.jsx)(S.X, {
                    title: "Photo Enhancer",
                    children: (0, a.jsxs)(v.S, {
                        id: n,
                        onUpload: b,
                        onScroll: A,
                        children: [(0, a.jsxs)(C.Z, {
                            className: "fixed z-20 lg:z-40 top-0 start-0 transition-colors duration-200 ".concat(P ? "lg:bg-overlay-black-20 lg:backdrop-blur-[28px]" : ""),
                            children: [" ", (0, a.jsx)(j.N, {
                                className: "hidden md:flex"
                            }), (0, a.jsx)(Z.W.Button, {
                                className: "md:hidden"
                            })]
                        }), (0, a.jsx)(Z.W, {
                            className: "fixed z-30 inset-0 md:hidden",
                            children: (0, a.jsx)(j.N, {})
                        }), (0, a.jsxs)("div", {
                            className: "relative h-96 sm:h-half-screen lg:h-full lg:fixed inset-0 z-0",
                            children: [m.beforeSrc && m.afterSrc && (0, a.jsx)(i.Uy, (0, o.Z)((0, r.Z)({
                                className: "w-full h-full",
                                backgroundColor: 0,
                                initialFit: "cover",
                                disablePan: !0,
                                disablePinch: !0
                            }, m), {
                                onSlide: p,
                                sliderBehavior: "hover"
                            })), (0, a.jsx)("div", {
                                className: "lg:hidden absolute h-20 bottom-0 w-full bg-gradient-to-t from-black-background"
                            })]
                        }), (0, a.jsx)("main", {
                            className: "relative z-10 container mt-6 md:mt-12 ".concat(D.values.bipaDisclaimerEnabled ? "lg:short:mt-20" : "lg:short:mt-12", " lg:mt-2 lg:min-h-[95%] flex pointer-events-none"),
                            children: (0, a.jsxs)("div", {
                                className: "m-auto lg:mr-0 pointer-events-auto text-center lg:text-left",
                                children: [(0, a.jsxs)("div", {
                                    className: "max-w-lg lg:max-w-md space-y-4",
                                    children: [(0, a.jsxs)(M, {
                                        children: [!(null === G || void 0 === G || null === (e = G.monetization) || void 0 === e ? void 0 : e.hasIncompleteSubscription) && (0, a.jsx)(y, {}), (0, a.jsxs)("h1", {
                                            className: "lg:text-start relative text-[48px] font-medium leading-[56px] tracking-[-2px]",
                                            children: [g, " ", (0, a.jsxs)("span", {
                                                className: "relative",
                                                children: [U(O.home.click), (0, a.jsx)("img", (0, o.Z)((0, r.Z)({
                                                    className: "absolute right-0",
                                                    draggable: !1
                                                }, s), {
                                                    alt: "sketch"
                                                }))]
                                            })]
                                        })]
                                    }), (0, a.jsx)(M, {
                                        children: (0, a.jsx)("p", {
                                            className: "lg:text-start R16+LH text-opacity-60",
                                            children: E
                                        })
                                    })]
                                }), (0, a.jsx)(M, {
                                    className: "mt-12 max-w-md mx-auto",
                                    children: (0, a.jsxs)(x.F, {
                                        forId: n,
                                        className: "block lg:w-[420px] w-[100%] px-8 pt-10 pb-8 text-center rounded-[32px] border-3 border-dashed border-overlay-white-30 bg-gradient-to-br from-[rgba(0,0,0,0.09)] to-[rgba(0,0,0,0.3)] hover:bg-overlay-white-5 transition-colors",
                                        children: [(0, a.jsxs)("div", {
                                            className: "btn btn--large btn--primary w-max mx-auto py-1 px-6 ps-8 flex justify-center items-center rounded-full",
                                            children: [T, (0, a.jsx)("img", (0, o.Z)((0, r.Z)({}, l), {
                                                className: "box-content inline-block w-8 h-8 ms-2",
                                                alt: "Upload"
                                            }))]
                                        }), (0, a.jsx)("p", {
                                            className: "block M16 mt-4 contrast-high",
                                            children: _
                                        }), (0, a.jsxs)("div", {
                                            className: "mt-5 flex justify-center",
                                            children: [(0, a.jsxs)("span", {
                                                className: "bg-overlay-white-10 rounded-[12px] py-[5px] ltr:pr-[14px] rtl:pl-[14px] ltr:pl-[10px] rtl:pr-[10px] flex items-center text-center uppercase font-bold tracking-wide text-[10px] mx-2",
                                                children: [(0, a.jsx)("img", (0, o.Z)((0, r.Z)({}, c), {
                                                    className: "box-content inline-block pe-1",
                                                    alt: "Upload"
                                                })), F]
                                            }), (0, a.jsxs)("span", {
                                                className: "bg-overlay-white-10 rounded-[12px] py-[5px] pr-[14px] pl-[10px] flex items-center text-center uppercase font-bold tracking-wide text-[10px] mx-2",
                                                children: [(0, a.jsx)("img", (0, o.Z)((0, r.Z)({}, d), {
                                                    className: "box-content inline-block pe-1",
                                                    alt: "Upload"
                                                })), L]
                                            })]
                                        }), (0, a.jsx)(h, {
                                            className: "mt-4"
                                        }), D.values.bipaDisclaimerEnabled && (0, a.jsx)("p", {
                                            className: "R12 contrast-low mt-3",
                                            children: B
                                        })]
                                    })
                                })]
                            })
                        }), (0, a.jsx)(N.Z, {
                            className: "relative z-10 ".concat(D.values.bipaDisclaimerEnabled ? "lg:-mt-2" : "lg:-mt-8", " lg:tall:-mt-28 lg:float-right text-center lg:text-right")
                        }), (0, a.jsxs)(u.E.div, {
                            initial: {
                                opacity: 1
                            },
                            animate: {
                                opacity: R ? 0 : 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                type: "easeOut",
                                duration: .2
                            },
                            className: "hidden lg:short:flex lg:short:fixed bottom-0 w-full h-[40px] items-center justify-center bg-overlay-black-20 backdrop-filter backdrop-blur-[24px]",
                            "aria-live": "polite",
                            children: [(0, a.jsx)("p", {
                                className: "R10 uppercase text-gray-300 font-bold tracking-wider",
                                children: I
                            }), (0, a.jsx)("img", (0, o.Z)((0, r.Z)({}, k.Z), {
                                alt: "",
                                className: "w-4 h-4 ms-0.5"
                            }))]
                        }), " "]
                    })
                })
            }
        },
        52951: function(e, t, n) {
            "use strict";

            function r(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }

            function o(e, t, n) {
                return t && r(e.prototype, t), n && r(e, n), e
            }
            n.d(t, {
                Z: function() {
                    return o
                }
            })
        },
        45785: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var r = n(82662);

            function o(e, t, n) {
                return o = "undefined" !== typeof Reflect && Reflect.get ? Reflect.get : function(e, t, n) {
                    var o = function(e, t) {
                        for (; !Object.prototype.hasOwnProperty.call(e, t) && null !== (e = (0, r.Z)(e)););
                        return e
                    }(e, t);
                    if (o) {
                        var a = Object.getOwnPropertyDescriptor(o, t);
                        return a.get ? a.get.call(n || e) : a.value
                    }
                }, o(e, t, n)
            }

            function a(e, t, n) {
                return o(e, t, n)
            }
        },
        4960: function(e, t, n) {
            "use strict";
            n.d(t, {
                c: function() {
                    return c
                }
            });
            var r = n(70655),
                o = n(67294),
                a = n(33234),
                i = n(16014),
                s = n(96681);

            function c(e) {
                var t = (0, s.h)((function() {
                    return (0, a.B)(e)
                }));
                if ((0, o.useContext)(i._).isStatic) {
                    var n = (0, r.__read)((0, o.useState)(e), 2)[1];
                    (0, o.useEffect)((function() {
                        return t.onChange(n)
                    }), [])
                }
                return t
            }
        }
    },
    function(e) {
        e.O(0, [4048, 9774, 2888, 179], (function() {
            return t = 48312, e(e.s = t);
            var t
        }));
        var t = e.O();
        _N_E = t
    }
]);
//# sourceMappingURL=index-03fb9387d2b6842a.js.map