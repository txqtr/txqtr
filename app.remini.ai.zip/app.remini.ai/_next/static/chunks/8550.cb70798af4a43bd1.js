"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8550], {
        68550: function(n, e, r) {
            r.r(e);
            var t = r(26042),
                u = r(85893),
                a = r(67294),
                c = r(8773),
                i = {
                    b: function(n) {
                        return (0, u.jsx)("b", {
                            children: n
                        })
                    },
                    i: function(n) {
                        return (0, u.jsx)("i", {
                            children: n
                        })
                    },
                    u: function(n) {
                        return (0, u.jsx)("u", {
                            children: n
                        })
                    }
                };

            function o(n) {
                var e = n.string,
                    r = n.object,
                    o = n.className,
                    s = (0, a.useMemo)((function() {
                        return (0, t.Z)({}, r, i)
                    }), [r]),
                    f = (0, a.useCallback)((function(n) {
                        var e = n.nodeName.toLowerCase(),
                            r = s[e],
                            t = "function" === typeof r && r,
                            i = (0, c.Z)();
                        if ("#text" === e || !t) {
                            var o, l = ((null === (o = n.nodeValue) || void 0 === o ? void 0 : o.split(/\{\{([^{}]+)\}\}/g)) || []).map((function(n, e) {
                                var r = s[n];
                                return (0, u.jsx)(a.Fragment, {
                                    children: e % 2 === 0 ? n : "function" === typeof r ? r(n) : r
                                }, e)
                            }));
                            return (0, u.jsx)(a.Fragment, {
                                children: l
                            }, i)
                        }
                        var d = Array.from(n.childNodes).map((function(n) {
                            return f(n)
                        }));
                        return (0, u.jsx)(a.Fragment, {
                            children: t(d)
                        }, i)
                    }), [s]);
                return (0, a.useMemo)((function() {
                    var n = document.createElement("span");
                    n.innerHTML = e;
                    var r = Array.from(n.childNodes).map((function(n) {
                        return f(n)
                    }));
                    return (0, u.jsx)("span", {
                        className: o,
                        children: r
                    })
                }), [o, f, e])
            }
            e.default = (0, a.memo)(o)
        }
    }
]);
//# sourceMappingURL=8550.cb70798af4a43bd1.js.map