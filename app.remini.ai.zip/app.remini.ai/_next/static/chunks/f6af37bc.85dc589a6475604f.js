"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2166], {
        76560: function(e, t, r) {
            r.d(t, {
                $r: function() {
                    return Oe
                },
                Bv: function() {
                    return At
                },
                Ie: function() {
                    return yt
                },
                JZ: function() {
                    return Tt
                },
                Rv: function() {
                    return _t
                },
                Rw: function() {
                    return s.R
                },
                TI: function() {
                    return U
                },
                UX: function() {
                    return Le
                },
                VL: function() {
                    return y
                },
                Y9: function() {
                    return mt
                },
                ZM: function() {
                    return Be
                },
                ZX: function() {
                    return z
                },
                a$: function() {
                    return gt
                },
                bO: function() {
                    return ee
                },
                e6: function() {
                    return pt
                },
                ex: function() {
                    return Me
                },
                kP: function() {
                    return vt
                },
                lW: function() {
                    return k
                },
                nw: function() {
                    return s.n
                },
                oo: function() {
                    return $
                },
                qm: function() {
                    return m
                },
                ud: function() {
                    return K
                },
                wn: function() {
                    return Pe
                },
                xE: function() {
                    return P
                }
            });
            var i = r(8542),
                n = r(41048),
                o = r(59618),
                s = r(92044),
                a = r(37099),
                u = r(25150),
                h = r(75623);
            i.Xd.PREFER_ENV = o.tq.any ? n.Vi.WEBGL : n.Vi.WEBGL2, i.Xd.STRICT_TEXTURE_CACHE = !1;
            var l = [];

            function d(e, t) {
                if (!e) return null;
                var r = "";
                if ("string" === typeof e) {
                    var i = /\.(\w{3,4})(?:$|\?|#)/i.exec(e);
                    i && (r = i[1].toLowerCase())
                }
                for (var n = l.length - 1; n >= 0; --n) {
                    var o = l[n];
                    if (o.test && o.test(e, r)) return new o(e, t)
                }
                throw new Error("Unrecognized source type to auto-detect Resource")
            }
            var f = function(e, t) {
                return f = Object.setPrototypeOf || {
                    __proto__: []
                }
                instanceof Array && function(e, t) {
                    e.__proto__ = t
                } || function(e, t) {
                    for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r])
                }, f(e, t)
            };

            function c(e, t) {
                function r() {
                    this.constructor = e
                }
                f(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r)
            }
            var p = function() {
                return p = Object.assign || function(e) {
                    for (var t, r = arguments, i = 1, n = arguments.length; i < n; i++)
                        for (var o in t = r[i]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }, p.apply(this, arguments)
            };
            var v = function() {
                    function e(e, t) {
                        void 0 === e && (e = 0), void 0 === t && (t = 0), this._width = e, this._height = t, this.destroyed = !1, this.internal = !1, this.onResize = new a.R("setRealSize"), this.onUpdate = new a.R("update"), this.onError = new a.R("onError")
                    }
                    return e.prototype.bind = function(e) {
                        this.onResize.add(e), this.onUpdate.add(e), this.onError.add(e), (this._width || this._height) && this.onResize.emit(this._width, this._height)
                    }, e.prototype.unbind = function(e) {
                        this.onResize.remove(e), this.onUpdate.remove(e), this.onError.remove(e)
                    }, e.prototype.resize = function(e, t) {
                        e === this._width && t === this._height || (this._width = e, this._height = t, this.onResize.emit(e, t))
                    }, Object.defineProperty(e.prototype, "valid", {
                        get: function() {
                            return !!this._width && !!this._height
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.update = function() {
                        this.destroyed || this.onUpdate.emit()
                    }, e.prototype.load = function() {
                        return Promise.resolve(this)
                    }, Object.defineProperty(e.prototype, "width", {
                        get: function() {
                            return this._width
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "height", {
                        get: function() {
                            return this._height
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.style = function(e, t, r) {
                        return !1
                    }, e.prototype.dispose = function() {}, e.prototype.destroy = function() {
                        this.destroyed || (this.destroyed = !0, this.dispose(), this.onError.removeAll(), this.onError = null, this.onResize.removeAll(), this.onResize = null, this.onUpdate.removeAll(), this.onUpdate = null)
                    }, e.test = function(e, t) {
                        return !1
                    }, e
                }(),
                m = function(e) {
                    function t(t, r) {
                        var i = this,
                            n = r || {},
                            o = n.width,
                            s = n.height;
                        if (!o || !s) throw new Error("BufferResource width or height invalid");
                        return (i = e.call(this, o, s) || this).data = t, i
                    }
                    return c(t, e), t.prototype.upload = function(e, t, r) {
                        var i = e.gl;
                        i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL, t.alphaMode === n.iw.UNPACK);
                        var o = t.realWidth,
                            s = t.realHeight;
                        return r.width === o && r.height === s ? i.texSubImage2D(t.target, 0, 0, 0, o, s, t.format, r.type, this.data) : (r.width = o, r.height = s, i.texImage2D(t.target, 0, r.internalFormat, o, s, 0, t.format, r.type, this.data)), !0
                    }, t.prototype.dispose = function() {
                        this.data = null
                    }, t.test = function(e) {
                        return e instanceof Float32Array || e instanceof Uint8Array || e instanceof Uint32Array
                    }, t
                }(v),
                g = {
                    scaleMode: n.aH.NEAREST,
                    format: n.I2.RGBA,
                    alphaMode: n.iw.NPM
                },
                y = function(e) {
                    function t(t, r) {
                        void 0 === t && (t = null), void 0 === r && (r = null);
                        var s = e.call(this) || this,
                            a = (r = r || {}).alphaMode,
                            u = r.mipmap,
                            h = r.anisotropicLevel,
                            l = r.scaleMode,
                            f = r.width,
                            c = r.height,
                            p = r.wrapMode,
                            m = r.format,
                            g = r.type,
                            y = r.target,
                            _ = r.resolution,
                            b = r.resourceOptions;
                        return !t || t instanceof v || ((t = d(t, b)).internal = !0), s.resolution = _ || i.Xd.RESOLUTION, s.width = Math.round((f || 0) * s.resolution) / s.resolution, s.height = Math.round((c || 0) * s.resolution) / s.resolution, s._mipmap = void 0 !== u ? u : i.Xd.MIPMAP_TEXTURES, s.anisotropicLevel = void 0 !== h ? h : i.Xd.ANISOTROPIC_LEVEL, s._wrapMode = p || i.Xd.WRAP_MODE, s._scaleMode = void 0 !== l ? l : i.Xd.SCALE_MODE, s.format = m || n.I2.RGBA, s.type = g || n.vK.UNSIGNED_BYTE, s.target = y || n.sp.TEXTURE_2D, s.alphaMode = void 0 !== a ? a : n.iw.UNPACK, s.uid = (0, o.hQ)(), s.touched = 0, s.isPowerOfTwo = !1, s._refreshPOT(), s._glTextures = {}, s.dirtyId = 0, s.dirtyStyleId = 0, s.cacheId = null, s.valid = f > 0 && c > 0, s.textureCacheIds = [], s.destroyed = !1, s.resource = null, s._batchEnabled = 0, s._batchLocation = 0, s.parentTextureArray = null, s.setResource(t), s
                    }
                    return c(t, e), Object.defineProperty(t.prototype, "realWidth", {
                        get: function() {
                            return Math.round(this.width * this.resolution)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "realHeight", {
                        get: function() {
                            return Math.round(this.height * this.resolution)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "mipmap", {
                        get: function() {
                            return this._mipmap
                        },
                        set: function(e) {
                            this._mipmap !== e && (this._mipmap = e, this.dirtyStyleId++)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "scaleMode", {
                        get: function() {
                            return this._scaleMode
                        },
                        set: function(e) {
                            this._scaleMode !== e && (this._scaleMode = e, this.dirtyStyleId++)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "wrapMode", {
                        get: function() {
                            return this._wrapMode
                        },
                        set: function(e) {
                            this._wrapMode !== e && (this._wrapMode = e, this.dirtyStyleId++)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t.prototype.setStyle = function(e, t) {
                        var r;
                        return void 0 !== e && e !== this.scaleMode && (this.scaleMode = e, r = !0), void 0 !== t && t !== this.mipmap && (this.mipmap = t, r = !0), r && this.dirtyStyleId++, this
                    }, t.prototype.setSize = function(e, t, r) {
                        return r = r || this.resolution, this.setRealSize(e * r, t * r, r)
                    }, t.prototype.setRealSize = function(e, t, r) {
                        return this.resolution = r || this.resolution, this.width = Math.round(e) / this.resolution, this.height = Math.round(t) / this.resolution, this._refreshPOT(), this.update(), this
                    }, t.prototype._refreshPOT = function() {
                        this.isPowerOfTwo = (0, o.wv)(this.realWidth) && (0, o.wv)(this.realHeight)
                    }, t.prototype.setResolution = function(e) {
                        var t = this.resolution;
                        return t === e || (this.resolution = e, this.valid && (this.width = Math.round(this.width * t) / e, this.height = Math.round(this.height * t) / e, this.emit("update", this)), this._refreshPOT()), this
                    }, t.prototype.setResource = function(e) {
                        if (this.resource === e) return this;
                        if (this.resource) throw new Error("Resource can be set only once");
                        return e.bind(this), this.resource = e, this
                    }, t.prototype.update = function() {
                        this.valid ? (this.dirtyId++, this.dirtyStyleId++, this.emit("update", this)) : this.width > 0 && this.height > 0 && (this.valid = !0, this.emit("loaded", this), this.emit("update", this))
                    }, t.prototype.onError = function(e) {
                        this.emit("error", this, e)
                    }, t.prototype.destroy = function() {
                        this.resource && (this.resource.unbind(this), this.resource.internal && this.resource.destroy(), this.resource = null), this.cacheId && (delete o.V8[this.cacheId], delete o.kN[this.cacheId], this.cacheId = null), this.dispose(), t.removeFromCache(this), this.textureCacheIds = null, this.destroyed = !0
                    }, t.prototype.dispose = function() {
                        this.emit("dispose", this)
                    }, t.prototype.castToBaseTexture = function() {
                        return this
                    }, t.from = function(e, r, n) {
                        void 0 === n && (n = i.Xd.STRICT_TEXTURE_CACHE);
                        var s = "string" === typeof e,
                            a = null;
                        if (s) a = e;
                        else {
                            if (!e._pixiId) {
                                var u = r && r.pixiIdPrefix || "pixiid";
                                e._pixiId = u + "_" + (0, o.hQ)()
                            }
                            a = e._pixiId
                        }
                        var h = o.V8[a];
                        if (s && n && !h) throw new Error('The cacheId "' + a + '" does not exist in BaseTextureCache.');
                        return h || ((h = new t(e, r)).cacheId = a, t.addToCache(h, a)), h
                    }, t.fromBuffer = function(e, r, i, o) {
                        e = e || new Float32Array(r * i * 4);
                        var s = new m(e, {
                                width: r,
                                height: i
                            }),
                            a = e instanceof Float32Array ? n.vK.FLOAT : n.vK.UNSIGNED_BYTE;
                        return new t(s, Object.assign({}, g, o || {
                            width: r,
                            height: i,
                            type: a
                        }))
                    }, t.addToCache = function(e, t) {
                        t && (-1 === e.textureCacheIds.indexOf(t) && e.textureCacheIds.push(t), o.V8[t] && console.warn("BaseTexture added to the cache with an id [" + t + "] that already had an entry"), o.V8[t] = e)
                    }, t.removeFromCache = function(e) {
                        if ("string" === typeof e) {
                            var t = o.V8[e];
                            if (t) {
                                var r = t.textureCacheIds.indexOf(e);
                                return r > -1 && t.textureCacheIds.splice(r, 1), delete o.V8[e], t
                            }
                        } else if (e && e.textureCacheIds) {
                            for (var i = 0; i < e.textureCacheIds.length; ++i) delete o.V8[e.textureCacheIds[i]];
                            return e.textureCacheIds.length = 0, e
                        }
                        return null
                    }, t._globalBatch = 0, t
                }(o.vp),
                _ = function(e) {
                    function t(t, r) {
                        var i = this,
                            n = r || {},
                            o = n.width,
                            s = n.height;
                        (i = e.call(this, o, s) || this).items = [], i.itemDirtyIds = [];
                        for (var a = 0; a < t; a++) {
                            var u = new y;
                            i.items.push(u), i.itemDirtyIds.push(-2)
                        }
                        return i.length = t, i._load = null, i.baseTexture = null, i
                    }
                    return c(t, e), t.prototype.initFromArray = function(e, t) {
                        for (var r = 0; r < this.length; r++) e[r] && (e[r].castToBaseTexture ? this.addBaseTextureAt(e[r].castToBaseTexture(), r) : e[r] instanceof v ? this.addResourceAt(e[r], r) : this.addResourceAt(d(e[r], t), r))
                    }, t.prototype.dispose = function() {
                        for (var e = 0, t = this.length; e < t; e++) this.items[e].destroy();
                        this.items = null, this.itemDirtyIds = null, this._load = null
                    }, t.prototype.addResourceAt = function(e, t) {
                        if (!this.items[t]) throw new Error("Index " + t + " is out of bounds");
                        return e.valid && !this.valid && this.resize(e.width, e.height), this.items[t].setResource(e), this
                    }, t.prototype.bind = function(t) {
                        if (null !== this.baseTexture) throw new Error("Only one base texture per TextureArray is allowed");
                        e.prototype.bind.call(this, t);
                        for (var r = 0; r < this.length; r++) this.items[r].parentTextureArray = t, this.items[r].on("update", t.update, t)
                    }, t.prototype.unbind = function(t) {
                        e.prototype.unbind.call(this, t);
                        for (var r = 0; r < this.length; r++) this.items[r].parentTextureArray = null, this.items[r].off("update", t.update, t)
                    }, t.prototype.load = function() {
                        var e = this;
                        if (this._load) return this._load;
                        var t = this.items.map((function(e) {
                            return e.resource
                        })).filter((function(e) {
                            return e
                        })).map((function(e) {
                            return e.load()
                        }));
                        return this._load = Promise.all(t).then((function() {
                            var t = e.items[0],
                                r = t.realWidth,
                                i = t.realHeight;
                            return e.resize(r, i), Promise.resolve(e)
                        })), this._load
                    }, t
                }(v),
                b = function(e) {
                    function t(t, r) {
                        var i, n, o = this,
                            s = r || {},
                            a = s.width,
                            u = s.height;
                        return Array.isArray(t) ? (i = t, n = t.length) : n = t, o = e.call(this, n, {
                            width: a,
                            height: u
                        }) || this, i && o.initFromArray(i, r), o
                    }
                    return c(t, e), t.prototype.addBaseTextureAt = function(e, t) {
                        if (!e.resource) throw new Error("ArrayResource does not support RenderTexture");
                        return this.addResourceAt(e.resource, t), this
                    }, t.prototype.bind = function(t) {
                        e.prototype.bind.call(this, t), t.target = n.sp.TEXTURE_2D_ARRAY
                    }, t.prototype.upload = function(e, t, r) {
                        var i = this,
                            n = i.length,
                            o = i.itemDirtyIds,
                            s = i.items,
                            a = e.gl;
                        r.dirtyId < 0 && a.texImage3D(a.TEXTURE_2D_ARRAY, 0, r.internalFormat, this._width, this._height, n, 0, t.format, r.type, null);
                        for (var u = 0; u < n; u++) {
                            var h = s[u];
                            o[u] < h.dirtyId && (o[u] = h.dirtyId, h.valid && a.texSubImage3D(a.TEXTURE_2D_ARRAY, 0, 0, 0, u, h.resource.width, h.resource.height, 1, t.format, r.type, h.resource.source))
                        }
                        return !0
                    }, t
                }(_),
                x = function(e) {
                    function t(t) {
                        var r = this,
                            i = t,
                            n = i.naturalWidth || i.videoWidth || i.width,
                            o = i.naturalHeight || i.videoHeight || i.height;
                        return (r = e.call(this, n, o) || this).source = t, r.noSubImage = !1, r
                    }
                    return c(t, e), t.crossOrigin = function(e, t, r) {
                        void 0 === r && 0 !== t.indexOf("data:") ? e.crossOrigin = (0, o.Qq)(t) : !1 !== r && (e.crossOrigin = "string" === typeof r ? r : "anonymous")
                    }, t.prototype.upload = function(e, t, r, i) {
                        var o = e.gl,
                            s = t.realWidth,
                            a = t.realHeight;
                        if ((i = i || this.source) instanceof HTMLImageElement) {
                            if (!i.complete || 0 === i.naturalWidth) return !1
                        } else if (i instanceof HTMLVideoElement && i.readyState <= 1) return !1;
                        return o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL, t.alphaMode === n.iw.UNPACK), this.noSubImage || t.target !== o.TEXTURE_2D || r.width !== s || r.height !== a ? (r.width = s, r.height = a, o.texImage2D(t.target, 0, r.internalFormat, t.format, r.type, i)) : o.texSubImage2D(o.TEXTURE_2D, 0, 0, 0, t.format, r.type, i), !0
                    }, t.prototype.update = function() {
                        if (!this.destroyed) {
                            var t = this.source,
                                r = t.naturalWidth || t.videoWidth || t.width,
                                i = t.naturalHeight || t.videoHeight || t.height;
                            this.resize(r, i), e.prototype.update.call(this)
                        }
                    }, t.prototype.dispose = function() {
                        this.source = null
                    }, t
                }(v),
                T = function(e) {
                    function t(t) {
                        return e.call(this, t) || this
                    }
                    return c(t, e), t.test = function(e) {
                        var t = globalThis.OffscreenCanvas;
                        return !!(t && e instanceof t) || globalThis.HTMLCanvasElement && e instanceof HTMLCanvasElement
                    }, t
                }(x),
                E = function(e) {
                    function t(r, i) {
                        var o = this,
                            s = i || {},
                            a = s.width,
                            u = s.height,
                            h = s.autoLoad,
                            l = s.linkBaseTexture;
                        if (r && r.length !== t.SIDES) throw new Error("Invalid length. Got " + r.length + ", expected 6");
                        o = e.call(this, 6, {
                            width: a,
                            height: u
                        }) || this;
                        for (var d = 0; d < t.SIDES; d++) o.items[d].target = n.sp.TEXTURE_CUBE_MAP_POSITIVE_X + d;
                        return o.linkBaseTexture = !1 !== l, r && o.initFromArray(r, i), !1 !== h && o.load(), o
                    }
                    return c(t, e), t.prototype.bind = function(t) {
                        e.prototype.bind.call(this, t), t.target = n.sp.TEXTURE_CUBE_MAP
                    }, t.prototype.addBaseTextureAt = function(e, t, r) {
                        if (!this.items[t]) throw new Error("Index " + t + " is out of bounds");
                        if (!this.linkBaseTexture || e.parentTextureArray || Object.keys(e._glTextures).length > 0) {
                            if (!e.resource) throw new Error("CubeResource does not support copying of renderTexture.");
                            this.addResourceAt(e.resource, t)
                        } else e.target = n.sp.TEXTURE_CUBE_MAP_POSITIVE_X + t, e.parentTextureArray = this.baseTexture, this.items[t] = e;
                        return e.valid && !this.valid && this.resize(e.realWidth, e.realHeight), this.items[t] = e, this
                    }, t.prototype.upload = function(e, r, i) {
                        for (var n = this.itemDirtyIds, o = 0; o < t.SIDES; o++) {
                            var s = this.items[o];
                            (n[o] < s.dirtyId || i.dirtyId < r.dirtyId) && (s.valid && s.resource ? (s.resource.upload(e, s, i), n[o] = s.dirtyId) : n[o] < -1 && (e.gl.texImage2D(s.target, 0, i.internalFormat, r.realWidth, r.realHeight, 0, r.format, i.type, null), n[o] = -1))
                        }
                        return !0
                    }, t.test = function(e) {
                        return Array.isArray(e) && e.length === t.SIDES
                    }, t.SIDES = 6, t
                }(_),
                R = function(e) {
                    function t(t, r) {
                        var n = this;
                        if (r = r || {}, !(t instanceof HTMLImageElement)) {
                            var o = new Image;
                            x.crossOrigin(o, t, r.crossorigin), o.src = t, t = o
                        }
                        return n = e.call(this, t) || this, !t.complete && n._width && n._height && (n._width = 0, n._height = 0), n.url = t.src, n._process = null, n.preserveBitmap = !1, n.createBitmap = (void 0 !== r.createBitmap ? r.createBitmap : i.Xd.CREATE_IMAGE_BITMAP) && !!globalThis.createImageBitmap, n.alphaMode = "number" === typeof r.alphaMode ? r.alphaMode : null, n.bitmap = null, n._load = null, !1 !== r.autoLoad && n.load(), n
                    }
                    return c(t, e), t.prototype.load = function(e) {
                        var t = this;
                        return this._load || (void 0 !== e && (this.createBitmap = e), this._load = new Promise((function(e, r) {
                            var i = t.source;
                            t.url = i.src;
                            var n = function() {
                                t.destroyed || (i.onload = null, i.onerror = null, t.resize(i.width, i.height), t._load = null, t.createBitmap ? e(t.process()) : e(t))
                            };
                            i.complete && i.src ? n() : (i.onload = n, i.onerror = function(e) {
                                r(e), t.onError.emit(e)
                            })
                        }))), this._load
                    }, t.prototype.process = function() {
                        var e = this,
                            t = this.source;
                        if (null !== this._process) return this._process;
                        if (null !== this.bitmap || !globalThis.createImageBitmap) return Promise.resolve(this);
                        var r = globalThis.createImageBitmap,
                            i = !t.crossOrigin || "anonymous" === t.crossOrigin;
                        return this._process = fetch(t.src, {
                            mode: i ? "cors" : "no-cors"
                        }).then((function(e) {
                            return e.blob()
                        })).then((function(i) {
                            return r(i, 0, 0, t.width, t.height, {
                                premultiplyAlpha: null === e.alphaMode || e.alphaMode === n.iw.UNPACK ? "premultiply" : "none"
                            })
                        })).then((function(t) {
                            return e.destroyed ? Promise.reject() : (e.bitmap = t, e.update(), e._process = null, Promise.resolve(e))
                        })), this._process
                    }, t.prototype.upload = function(t, r, i) {
                        if ("number" === typeof this.alphaMode && (r.alphaMode = this.alphaMode), !this.createBitmap) return e.prototype.upload.call(this, t, r, i);
                        if (!this.bitmap && (this.process(), !this.bitmap)) return !1;
                        if (e.prototype.upload.call(this, t, r, i, this.bitmap), !this.preserveBitmap) {
                            var n = !0,
                                o = r._glTextures;
                            for (var s in o) {
                                var a = o[s];
                                if (a !== i && a.dirtyId !== r.dirtyId) {
                                    n = !1;
                                    break
                                }
                            }
                            n && (this.bitmap.close && this.bitmap.close(), this.bitmap = null)
                        }
                        return !0
                    }, t.prototype.dispose = function() {
                        this.source.onload = null, this.source.onerror = null, e.prototype.dispose.call(this), this.bitmap && (this.bitmap.close(), this.bitmap = null), this._process = null, this._load = null
                    }, t.test = function(e) {
                        return "string" === typeof e || e instanceof HTMLImageElement
                    }, t
                }(x),
                I = function(e) {
                    function t(t, r) {
                        var n = this;
                        return r = r || {}, (n = e.call(this, i.Xd.ADAPTER.createCanvas()) || this)._width = 0, n._height = 0, n.svg = t, n.scale = r.scale || 1, n._overrideWidth = r.width, n._overrideHeight = r.height, n._resolve = null, n._crossorigin = r.crossorigin, n._load = null, !1 !== r.autoLoad && n.load(), n
                    }
                    return c(t, e), t.prototype.load = function() {
                        var e = this;
                        return this._load || (this._load = new Promise((function(r) {
                            if (e._resolve = function() {
                                    e.resize(e.source.width, e.source.height), r(e)
                                }, t.SVG_XML.test(e.svg.trim())) {
                                if (!btoa) throw new Error("Your browser doesn't support base64 conversions.");
                                e.svg = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(e.svg)))
                            }
                            e._loadSvg()
                        }))), this._load
                    }, t.prototype._loadSvg = function() {
                        var e = this,
                            t = new Image;
                        x.crossOrigin(t, this.svg, this._crossorigin), t.src = this.svg, t.onerror = function(r) {
                            e._resolve && (t.onerror = null, e.onError.emit(r))
                        }, t.onload = function() {
                            if (e._resolve) {
                                var r = t.width,
                                    i = t.height;
                                if (!r || !i) throw new Error("The SVG image must have width and height defined (in pixels), canvas API needs them.");
                                var n = r * e.scale,
                                    s = i * e.scale;
                                (e._overrideWidth || e._overrideHeight) && (n = e._overrideWidth || e._overrideHeight / i * r, s = e._overrideHeight || e._overrideWidth / r * i), n = Math.round(n), s = Math.round(s);
                                var a = e.source;
                                a.width = n, a.height = s, a._pixiId = "canvas_" + (0, o.hQ)(), a.getContext("2d").drawImage(t, 0, 0, r, i, 0, 0, n, s), e._resolve(), e._resolve = null
                            }
                        }
                    }, t.getSize = function(e) {
                        var r = t.SVG_SIZE.exec(e),
                            i = {};
                        return r && (i[r[1]] = Math.round(parseFloat(r[3])), i[r[5]] = Math.round(parseFloat(r[7]))), i
                    }, t.prototype.dispose = function() {
                        e.prototype.dispose.call(this), this._resolve = null, this._crossorigin = null
                    }, t.test = function(e, r) {
                        return "svg" === r || "string" === typeof e && e.startsWith("data:image/svg+xml") || "string" === typeof e && t.SVG_XML.test(e)
                    }, t.SVG_XML = /^(<\?xml[^?]+\?>)?\s*(<!--[^(-->)]*-->)?\s*\<svg/m, t.SVG_SIZE = /<svg[^>]*(?:\s(width|height)=('|")(\d*(?:\.\d+)?)(?:px)?('|"))[^>]*(?:\s(width|height)=('|")(\d*(?:\.\d+)?)(?:px)?('|"))[^>]*>/i, t
                }(x),
                A = function(e) {
                    function t(r, i) {
                        var n = this;
                        if (i = i || {}, !(r instanceof HTMLVideoElement)) {
                            var o = document.createElement("video");
                            o.setAttribute("preload", "auto"), o.setAttribute("webkit-playsinline", ""), o.setAttribute("playsinline", ""), "string" === typeof r && (r = [r]);
                            var s = r[0].src || r[0];
                            x.crossOrigin(o, s, i.crossorigin);
                            for (var a = 0; a < r.length; ++a) {
                                var u = document.createElement("source"),
                                    h = r[a],
                                    l = h.src,
                                    d = h.mime,
                                    f = (l = l || r[a]).split("?").shift().toLowerCase(),
                                    c = f.slice(f.lastIndexOf(".") + 1);
                                d = d || t.MIME_TYPES[c] || "video/" + c, u.src = l, u.type = d, o.appendChild(u)
                            }
                            r = o
                        }
                        return (n = e.call(this, r) || this).noSubImage = !0, n._autoUpdate = !0, n._isConnectedToTicker = !1, n._updateFPS = i.updateFPS || 0, n._msToNextUpdate = 0, n.autoPlay = !1 !== i.autoPlay, n._load = null, n._resolve = null, n._onCanPlay = n._onCanPlay.bind(n), n._onError = n._onError.bind(n), !1 !== i.autoLoad && n.load(), n
                    }
                    return c(t, e), t.prototype.update = function(t) {
                        if (!this.destroyed) {
                            var r = u.vB.shared.elapsedMS * this.source.playbackRate;
                            this._msToNextUpdate = Math.floor(this._msToNextUpdate - r), (!this._updateFPS || this._msToNextUpdate <= 0) && (e.prototype.update.call(this), this._msToNextUpdate = this._updateFPS ? Math.floor(1e3 / this._updateFPS) : 0)
                        }
                    }, t.prototype.load = function() {
                        var e = this;
                        if (this._load) return this._load;
                        var t = this.source;
                        return (t.readyState === t.HAVE_ENOUGH_DATA || t.readyState === t.HAVE_FUTURE_DATA) && t.width && t.height && (t.complete = !0), t.addEventListener("play", this._onPlayStart.bind(this)), t.addEventListener("pause", this._onPlayStop.bind(this)), this._isSourceReady() ? this._onCanPlay() : (t.addEventListener("canplay", this._onCanPlay), t.addEventListener("canplaythrough", this._onCanPlay), t.addEventListener("error", this._onError, !0)), this._load = new Promise((function(r) {
                            e.valid ? r(e) : (e._resolve = r, t.load())
                        })), this._load
                    }, t.prototype._onError = function(e) {
                        this.source.removeEventListener("error", this._onError, !0), this.onError.emit(e)
                    }, t.prototype._isSourcePlaying = function() {
                        var e = this.source;
                        return !e.paused && !e.ended && this._isSourceReady()
                    }, t.prototype._isSourceReady = function() {
                        return this.source.readyState > 2
                    }, t.prototype._onPlayStart = function() {
                        this.valid || this._onCanPlay(), this.autoUpdate && !this._isConnectedToTicker && (u.vB.shared.add(this.update, this), this._isConnectedToTicker = !0)
                    }, t.prototype._onPlayStop = function() {
                        this._isConnectedToTicker && (u.vB.shared.remove(this.update, this), this._isConnectedToTicker = !1)
                    }, t.prototype._onCanPlay = function() {
                        var e = this.source;
                        e.removeEventListener("canplay", this._onCanPlay), e.removeEventListener("canplaythrough", this._onCanPlay);
                        var t = this.valid;
                        this.resize(e.videoWidth, e.videoHeight), !t && this._resolve && (this._resolve(this), this._resolve = null), this._isSourcePlaying() ? this._onPlayStart() : this.autoPlay && e.play()
                    }, t.prototype.dispose = function() {
                        this._isConnectedToTicker && (u.vB.shared.remove(this.update, this), this._isConnectedToTicker = !1);
                        var t = this.source;
                        t && (t.removeEventListener("error", this._onError, !0), t.pause(), t.src = "", t.load()), e.prototype.dispose.call(this)
                    }, Object.defineProperty(t.prototype, "autoUpdate", {
                        get: function() {
                            return this._autoUpdate
                        },
                        set: function(e) {
                            e !== this._autoUpdate && (this._autoUpdate = e, !this._autoUpdate && this._isConnectedToTicker ? (u.vB.shared.remove(this.update, this), this._isConnectedToTicker = !1) : this._autoUpdate && !this._isConnectedToTicker && this._isSourcePlaying() && (u.vB.shared.add(this.update, this), this._isConnectedToTicker = !0))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "updateFPS", {
                        get: function() {
                            return this._updateFPS
                        },
                        set: function(e) {
                            e !== this._updateFPS && (this._updateFPS = e)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t.test = function(e, r) {
                        return globalThis.HTMLVideoElement && e instanceof HTMLVideoElement || t.TYPES.indexOf(r) > -1
                    }, t.TYPES = ["mp4", "m4v", "webm", "ogg", "ogv", "h264", "avi", "mov"], t.MIME_TYPES = {
                        ogv: "video/ogg",
                        mov: "video/quicktime",
                        m4v: "video/mp4"
                    }, t
                }(x),
                w = function(e) {
                    function t(t) {
                        return e.call(this, t) || this
                    }
                    return c(t, e), t.test = function(e) {
                        return !!globalThis.createImageBitmap && "undefined" !== typeof ImageBitmap && e instanceof ImageBitmap
                    }, t
                }(x);
            l.push(R, w, T, A, I, m, E, b);
            var S = {
                    __proto__: null,
                    Resource: v,
                    BaseImageResource: x,
                    INSTALLED: l,
                    autoDetectResource: d,
                    AbstractMultiResource: _,
                    ArrayResource: b,
                    BufferResource: m,
                    CanvasResource: T,
                    CubeResource: E,
                    ImageResource: R,
                    SVGResource: I,
                    VideoResource: A,
                    ImageBitmapResource: w
                },
                C = function(e) {
                    function t() {
                        return null !== e && e.apply(this, arguments) || this
                    }
                    return c(t, e), t.prototype.upload = function(e, t, r) {
                        var i = e.gl;
                        i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL, t.alphaMode === n.iw.UNPACK);
                        var o = t.realWidth,
                            s = t.realHeight;
                        return r.width === o && r.height === s ? i.texSubImage2D(t.target, 0, 0, 0, o, s, t.format, r.type, this.data) : (r.width = o, r.height = s, i.texImage2D(t.target, 0, r.internalFormat, o, s, 0, t.format, r.type, this.data)), !0
                    }, t
                }(m),
                F = function() {
                    function e(e, t) {
                        this.width = Math.round(e || 100), this.height = Math.round(t || 100), this.stencil = !1, this.depth = !1, this.dirtyId = 0, this.dirtyFormat = 0, this.dirtySize = 0, this.depthTexture = null, this.colorTextures = [], this.glFramebuffers = {}, this.disposeRunner = new a.R("disposeFramebuffer"), this.multisample = n.G5.NONE
                    }
                    return Object.defineProperty(e.prototype, "colorTexture", {
                        get: function() {
                            return this.colorTextures[0]
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.addColorTexture = function(e, t) {
                        return void 0 === e && (e = 0), this.colorTextures[e] = t || new y(null, {
                            scaleMode: n.aH.NEAREST,
                            resolution: 1,
                            mipmap: n.WB.OFF,
                            width: this.width,
                            height: this.height
                        }), this.dirtyId++, this.dirtyFormat++, this
                    }, e.prototype.addDepthTexture = function(e) {
                        return this.depthTexture = e || new y(new C(null, {
                            width: this.width,
                            height: this.height
                        }), {
                            scaleMode: n.aH.NEAREST,
                            resolution: 1,
                            width: this.width,
                            height: this.height,
                            mipmap: n.WB.OFF,
                            format: n.I2.DEPTH_COMPONENT,
                            type: n.vK.UNSIGNED_SHORT
                        }), this.dirtyId++, this.dirtyFormat++, this
                    }, e.prototype.enableDepth = function() {
                        return this.depth = !0, this.dirtyId++, this.dirtyFormat++, this
                    }, e.prototype.enableStencil = function() {
                        return this.stencil = !0, this.dirtyId++, this.dirtyFormat++, this
                    }, e.prototype.resize = function(e, t) {
                        if (e = Math.round(e), t = Math.round(t), e !== this.width || t !== this.height) {
                            this.width = e, this.height = t, this.dirtyId++, this.dirtySize++;
                            for (var r = 0; r < this.colorTextures.length; r++) {
                                var i = this.colorTextures[r],
                                    n = i.resolution;
                                i.setSize(e / n, t / n)
                            }
                            if (this.depthTexture) {
                                n = this.depthTexture.resolution;
                                this.depthTexture.setSize(e / n, t / n)
                            }
                        }
                    }, e.prototype.dispose = function() {
                        this.disposeRunner.emit(this, !1)
                    }, e.prototype.destroyDepthTexture = function() {
                        this.depthTexture && (this.depthTexture.destroy(), this.depthTexture = null, ++this.dirtyId, ++this.dirtyFormat)
                    }, e
                }(),
                N = function(e) {
                    function t(t) {
                        void 0 === t && (t = {});
                        var r = this;
                        if ("number" === typeof t) {
                            var i = arguments[0],
                                o = arguments[1],
                                s = arguments[2],
                                a = arguments[3];
                            t = {
                                width: i,
                                height: o,
                                scaleMode: s,
                                resolution: a
                            }
                        }
                        return t.width = t.width || 100, t.height = t.height || 100, t.multisample = void 0 !== t.multisample ? t.multisample : n.G5.NONE, (r = e.call(this, null, t) || this).mipmap = n.WB.OFF, r.valid = !0, r.clearColor = [0, 0, 0, 0], r.framebuffer = new F(r.realWidth, r.realHeight).addColorTexture(0, r), r.framebuffer.multisample = t.multisample, r.maskStack = [], r.filterStack = [{}], r
                    }
                    return c(t, e), t.prototype.resize = function(e, t) {
                        this.framebuffer.resize(e * this.resolution, t * this.resolution), this.setRealSize(this.framebuffer.width, this.framebuffer.height)
                    }, t.prototype.dispose = function() {
                        this.framebuffer.dispose(), e.prototype.dispose.call(this)
                    }, t.prototype.destroy = function() {
                        e.prototype.destroy.call(this), this.framebuffer.destroyDepthTexture(), this.framebuffer = null
                    }, t
                }(y),
                O = function() {
                    function e() {
                        this.x0 = 0, this.y0 = 0, this.x1 = 1, this.y1 = 0, this.x2 = 1, this.y2 = 1, this.x3 = 0, this.y3 = 1, this.uvsFloat32 = new Float32Array(8)
                    }
                    return e.prototype.set = function(e, t, r) {
                        var i = t.width,
                            n = t.height;
                        if (r) {
                            var o = e.width / 2 / i,
                                s = e.height / 2 / n,
                                a = e.x / i + o,
                                u = e.y / n + s;
                            r = h.Lv.add(r, h.Lv.NW), this.x0 = a + o * h.Lv.uX(r), this.y0 = u + s * h.Lv.uY(r), r = h.Lv.add(r, 2), this.x1 = a + o * h.Lv.uX(r), this.y1 = u + s * h.Lv.uY(r), r = h.Lv.add(r, 2), this.x2 = a + o * h.Lv.uX(r), this.y2 = u + s * h.Lv.uY(r), r = h.Lv.add(r, 2), this.x3 = a + o * h.Lv.uX(r), this.y3 = u + s * h.Lv.uY(r)
                        } else this.x0 = e.x / i, this.y0 = e.y / n, this.x1 = (e.x + e.width) / i, this.y1 = e.y / n, this.x2 = (e.x + e.width) / i, this.y2 = (e.y + e.height) / n, this.x3 = e.x / i, this.y3 = (e.y + e.height) / n;
                        this.uvsFloat32[0] = this.x0, this.uvsFloat32[1] = this.y0, this.uvsFloat32[2] = this.x1, this.uvsFloat32[3] = this.y1, this.uvsFloat32[4] = this.x2, this.uvsFloat32[5] = this.y2, this.uvsFloat32[6] = this.x3, this.uvsFloat32[7] = this.y3
                    }, e.prototype.toString = function() {
                        return "[@pixi/core:TextureUvs x0=" + this.x0 + " y0=" + this.y0 + " x1=" + this.x1 + " y1=" + this.y1 + " x2=" + this.x2 + " y2=" + this.y2 + " x3=" + this.x3 + " y3=" + this.y3 + "]"
                    }, e
                }(),
                M = new O;

            function B(e) {
                e.destroy = function() {}, e.on = function() {}, e.once = function() {}, e.emit = function() {}
            }
            var P = function(e) {
                    function t(r, i, n, o, s, a) {
                        var u = e.call(this) || this;
                        if (u.noFrame = !1, i || (u.noFrame = !0, i = new h.Ae(0, 0, 1, 1)), r instanceof t && (r = r.baseTexture), u.baseTexture = r, u._frame = i, u.trim = o, u.valid = !1, u._uvs = M, u.uvMatrix = null, u.orig = n || i, u._rotate = Number(s || 0), !0 === s) u._rotate = 2;
                        else if (u._rotate % 2 !== 0) throw new Error("attempt to use diamond-shaped UVs. If you are sure, set rotation manually");
                        return u.defaultAnchor = a ? new h.E9(a.x, a.y) : new h.E9(0, 0), u._updateID = 0, u.textureCacheIds = [], r.valid ? u.noFrame ? r.valid && u.onBaseTextureUpdated(r) : u.frame = i : r.once("loaded", u.onBaseTextureUpdated, u), u.noFrame && r.on("update", u.onBaseTextureUpdated, u), u
                    }
                    return c(t, e), t.prototype.update = function() {
                        this.baseTexture.resource && this.baseTexture.resource.update()
                    }, t.prototype.onBaseTextureUpdated = function(e) {
                        if (this.noFrame) {
                            if (!this.baseTexture.valid) return;
                            this._frame.width = e.width, this._frame.height = e.height, this.valid = !0, this.updateUvs()
                        } else this.frame = this._frame;
                        this.emit("update", this)
                    }, t.prototype.destroy = function(e) {
                        if (this.baseTexture) {
                            if (e) {
                                var r = this.baseTexture.resource;
                                r && r.url && o.kN[r.url] && t.removeFromCache(r.url), this.baseTexture.destroy()
                            }
                            this.baseTexture.off("loaded", this.onBaseTextureUpdated, this), this.baseTexture.off("update", this.onBaseTextureUpdated, this), this.baseTexture = null
                        }
                        this._frame = null, this._uvs = null, this.trim = null, this.orig = null, this.valid = !1, t.removeFromCache(this), this.textureCacheIds = null
                    }, t.prototype.clone = function() {
                        var e = this._frame.clone(),
                            r = this._frame === this.orig ? e : this.orig.clone(),
                            i = new t(this.baseTexture, !this.noFrame && e, r, this.trim && this.trim.clone(), this.rotate, this.defaultAnchor);
                        return this.noFrame && (i._frame = e), i
                    }, t.prototype.updateUvs = function() {
                        this._uvs === M && (this._uvs = new O), this._uvs.set(this._frame, this.baseTexture, this.rotate), this._updateID++
                    }, t.from = function(e, r, n) {
                        void 0 === r && (r = {}), void 0 === n && (n = i.Xd.STRICT_TEXTURE_CACHE);
                        var s = "string" === typeof e,
                            a = null;
                        if (s) a = e;
                        else if (e instanceof y) {
                            if (!e.cacheId) {
                                var u = r && r.pixiIdPrefix || "pixiid";
                                e.cacheId = u + "-" + (0, o.hQ)(), y.addToCache(e, e.cacheId)
                            }
                            a = e.cacheId
                        } else {
                            if (!e._pixiId) {
                                u = r && r.pixiIdPrefix || "pixiid";
                                e._pixiId = u + "_" + (0, o.hQ)()
                            }
                            a = e._pixiId
                        }
                        var h = o.kN[a];
                        if (s && n && !h) throw new Error('The cacheId "' + a + '" does not exist in TextureCache.');
                        return h || e instanceof y ? !h && e instanceof y && (h = new t(e), t.addToCache(h, a)) : (r.resolution || (r.resolution = (0, o.fL)(e)), (h = new t(new y(e, r))).baseTexture.cacheId = a, y.addToCache(h.baseTexture, a), t.addToCache(h, a)), h
                    }, t.fromURL = function(e, r) {
                        var i = Object.assign({
                                autoLoad: !1
                            }, null === r || void 0 === r ? void 0 : r.resourceOptions),
                            n = t.from(e, Object.assign({
                                resourceOptions: i
                            }, r), !1),
                            o = n.baseTexture.resource;
                        return n.baseTexture.valid ? Promise.resolve(n) : o.load().then((function() {
                            return Promise.resolve(n)
                        }))
                    }, t.fromBuffer = function(e, r, i, n) {
                        return new t(y.fromBuffer(e, r, i, n))
                    }, t.fromLoader = function(e, r, n, s) {
                        var a = new y(e, Object.assign({
                                scaleMode: i.Xd.SCALE_MODE,
                                resolution: (0, o.fL)(r)
                            }, s)),
                            u = a.resource;
                        u instanceof R && (u.url = r);
                        var h = new t(a);
                        return n || (n = r), y.addToCache(h.baseTexture, n), t.addToCache(h, n), n !== r && (y.addToCache(h.baseTexture, r), t.addToCache(h, r)), h.baseTexture.valid ? Promise.resolve(h) : new Promise((function(e) {
                            h.baseTexture.once("loaded", (function() {
                                return e(h)
                            }))
                        }))
                    }, t.addToCache = function(e, t) {
                        t && (-1 === e.textureCacheIds.indexOf(t) && e.textureCacheIds.push(t), o.kN[t] && console.warn("Texture added to the cache with an id [" + t + "] that already had an entry"), o.kN[t] = e)
                    }, t.removeFromCache = function(e) {
                        if ("string" === typeof e) {
                            var t = o.kN[e];
                            if (t) {
                                var r = t.textureCacheIds.indexOf(e);
                                return r > -1 && t.textureCacheIds.splice(r, 1), delete o.kN[e], t
                            }
                        } else if (e && e.textureCacheIds) {
                            for (var i = 0; i < e.textureCacheIds.length; ++i) o.kN[e.textureCacheIds[i]] === e && delete o.kN[e.textureCacheIds[i]];
                            return e.textureCacheIds.length = 0, e
                        }
                        return null
                    }, Object.defineProperty(t.prototype, "resolution", {
                        get: function() {
                            return this.baseTexture.resolution
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "frame", {
                        get: function() {
                            return this._frame
                        },
                        set: function(e) {
                            this._frame = e, this.noFrame = !1;
                            var t = e.x,
                                r = e.y,
                                i = e.width,
                                n = e.height,
                                o = t + i > this.baseTexture.width,
                                s = r + n > this.baseTexture.height;
                            if (o || s) {
                                var a = o && s ? "and" : "or",
                                    u = "X: " + t + " + " + i + " = " + (t + i) + " > " + this.baseTexture.width,
                                    h = "Y: " + r + " + " + n + " = " + (r + n) + " > " + this.baseTexture.height;
                                throw new Error("Texture Error: frame does not fit inside the base Texture dimensions: " + u + " " + a + " " + h)
                            }
                            this.valid = i && n && this.baseTexture.valid, this.trim || this.rotate || (this.orig = e), this.valid && this.updateUvs()
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "rotate", {
                        get: function() {
                            return this._rotate
                        },
                        set: function(e) {
                            this._rotate = e, this.valid && this.updateUvs()
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "width", {
                        get: function() {
                            return this.orig.width
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "height", {
                        get: function() {
                            return this.orig.height
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t.prototype.castToBaseTexture = function() {
                        return this.baseTexture
                    }, Object.defineProperty(t, "EMPTY", {
                        get: function() {
                            return t._EMPTY || (t._EMPTY = new t(new y), B(t._EMPTY), B(t._EMPTY.baseTexture)), t._EMPTY
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t, "WHITE", {
                        get: function() {
                            if (!t._WHITE) {
                                var e = i.Xd.ADAPTER.createCanvas(16, 16),
                                    r = e.getContext("2d");
                                e.width = 16, e.height = 16, r.fillStyle = "white", r.fillRect(0, 0, 16, 16), t._WHITE = new t(y.from(e)), B(t._WHITE), B(t._WHITE.baseTexture)
                            }
                            return t._WHITE
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t
                }(o.vp),
                U = function(e) {
                    function t(t, r) {
                        var i = e.call(this, t, r) || this;
                        return i.valid = !0, i.filterFrame = null, i.filterPoolKey = null, i.updateUvs(), i
                    }
                    return c(t, e), Object.defineProperty(t.prototype, "framebuffer", {
                        get: function() {
                            return this.baseTexture.framebuffer
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "multisample", {
                        get: function() {
                            return this.framebuffer.multisample
                        },
                        set: function(e) {
                            this.framebuffer.multisample = e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t.prototype.resize = function(e, t, r) {
                        void 0 === r && (r = !0);
                        var i = this.baseTexture.resolution,
                            n = Math.round(e * i) / i,
                            o = Math.round(t * i) / i;
                        this.valid = n > 0 && o > 0, this._frame.width = this.orig.width = n, this._frame.height = this.orig.height = o, r && this.baseTexture.resize(n, o), this.updateUvs()
                    }, t.prototype.setResolution = function(e) {
                        var t = this.baseTexture;
                        t.resolution !== e && (t.setResolution(e), this.resize(t.width, t.height, !1))
                    }, t.create = function(e) {
                        for (var r = arguments, i = [], n = 1; n < arguments.length; n++) i[n - 1] = r[n];
                        return "number" === typeof e && ((0, o.a1)("6.0.0", "Arguments (width, height, scaleMode, resolution) have been deprecated."), e = {
                            width: e,
                            height: i[0],
                            scaleMode: i[1],
                            resolution: i[2]
                        }), new t(new N(e))
                    }, t
                }(P),
                L = function() {
                    function e(e) {
                        this.texturePool = {}, this.textureOptions = e || {}, this.enableFullScreen = !1, this._pixelsWidth = 0, this._pixelsHeight = 0
                    }
                    return e.prototype.createTexture = function(e, t, r) {
                        void 0 === r && (r = n.G5.NONE);
                        var i = new N(Object.assign({
                            width: e,
                            height: t,
                            resolution: 1,
                            multisample: r
                        }, this.textureOptions));
                        return new U(i)
                    }, e.prototype.getOptimalTexture = function(e, t, r, i) {
                        var s;
                        void 0 === r && (r = 1), void 0 === i && (i = n.G5.NONE), e = Math.ceil(e * r - 1e-6), t = Math.ceil(t * r - 1e-6), this.enableFullScreen && e === this._pixelsWidth && t === this._pixelsHeight ? s = i > 1 ? -i : -1 : (s = ((65535 & (e = (0, o.a9)(e))) << 16 | 65535 & (t = (0, o.a9)(t))) >>> 0, i > 1 && (s += 4294967296 * i)), this.texturePool[s] || (this.texturePool[s] = []);
                        var a = this.texturePool[s].pop();
                        return a || (a = this.createTexture(e, t, i)), a.filterPoolKey = s, a.setResolution(r), a
                    }, e.prototype.getFilterTexture = function(e, t, r) {
                        var i = this.getOptimalTexture(e.width, e.height, t || e.resolution, r || n.G5.NONE);
                        return i.filterFrame = e.filterFrame, i
                    }, e.prototype.returnTexture = function(e) {
                        var t = e.filterPoolKey;
                        e.filterFrame = null, this.texturePool[t].push(e)
                    }, e.prototype.returnFilterTexture = function(e) {
                        this.returnTexture(e)
                    }, e.prototype.clear = function(e) {
                        if (e = !1 !== e)
                            for (var t in this.texturePool) {
                                var r = this.texturePool[t];
                                if (r)
                                    for (var i = 0; i < r.length; i++) r[i].destroy(!0)
                            }
                        this.texturePool = {}
                    }, e.prototype.setScreenSize = function(e) {
                        if (e.width !== this._pixelsWidth || e.height !== this._pixelsHeight) {
                            for (var t in this.enableFullScreen = e.width > 0 && e.height > 0, this.texturePool)
                                if (Number(t) < 0) {
                                    var r = this.texturePool[t];
                                    if (r)
                                        for (var i = 0; i < r.length; i++) r[i].destroy(!0);
                                    this.texturePool[t] = []
                                }
                            this._pixelsWidth = e.width, this._pixelsHeight = e.height
                        }
                    }, e.SCREEN_KEY = -1, e
                }(),
                D = function() {
                    function e(e, t, r, i, o, s, a) {
                        void 0 === t && (t = 0), void 0 === r && (r = !1), void 0 === i && (i = n.vK.FLOAT), this.buffer = e, this.size = t, this.normalized = r, this.type = i, this.stride = o, this.start = s, this.instance = a
                    }
                    return e.prototype.destroy = function() {
                        this.buffer = null
                    }, e.from = function(t, r, i, n, o) {
                        return new e(t, r, i, n, o)
                    }, e
                }(),
                G = 0,
                k = function() {
                    function e(e, t, r) {
                        void 0 === t && (t = !0), void 0 === r && (r = !1), this.data = e || new Float32Array(1), this._glBuffers = {}, this._updateID = 0, this.index = r, this.static = t, this.id = G++, this.disposeRunner = new a.R("disposeBuffer")
                    }
                    return e.prototype.update = function(e) {
                        e instanceof Array && (e = new Float32Array(e)), this.data = e || this.data, this._updateID++
                    }, e.prototype.dispose = function() {
                        this.disposeRunner.emit(this, !1)
                    }, e.prototype.destroy = function() {
                        this.dispose(), this.data = null
                    }, Object.defineProperty(e.prototype, "index", {
                        get: function() {
                            return this.type === n.mr.ELEMENT_ARRAY_BUFFER
                        },
                        set: function(e) {
                            this.type = e ? n.mr.ELEMENT_ARRAY_BUFFER : n.mr.ARRAY_BUFFER
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.from = function(t) {
                        return t instanceof Array && (t = new Float32Array(t)), new e(t)
                    }, e
                }(),
                V = {
                    Float32Array: Float32Array,
                    Uint32Array: Uint32Array,
                    Int32Array: Int32Array,
                    Uint8Array: Uint8Array
                };
            var X = {
                    5126: 4,
                    5123: 2,
                    5121: 1
                },
                H = 0,
                j = {
                    Float32Array: Float32Array,
                    Uint32Array: Uint32Array,
                    Int32Array: Int32Array,
                    Uint8Array: Uint8Array,
                    Uint16Array: Uint16Array
                },
                z = function() {
                    function e(e, t) {
                        void 0 === e && (e = []), void 0 === t && (t = {}), this.buffers = e, this.indexBuffer = null, this.attributes = t, this.glVertexArrayObjects = {}, this.id = H++, this.instanced = !1, this.instanceCount = 1, this.disposeRunner = new a.R("disposeGeometry"), this.refCount = 0
                    }
                    return e.prototype.addAttribute = function(e, t, r, i, n, o, s, a) {
                        if (void 0 === r && (r = 0), void 0 === i && (i = !1), void 0 === a && (a = !1), !t) throw new Error("You must pass a buffer when creating an attribute");
                        t instanceof k || (t instanceof Array && (t = new Float32Array(t)), t = new k(t));
                        var u = e.split("|");
                        if (u.length > 1) {
                            for (var h = 0; h < u.length; h++) this.addAttribute(u[h], t, r, i, n);
                            return this
                        }
                        var l = this.buffers.indexOf(t);
                        return -1 === l && (this.buffers.push(t), l = this.buffers.length - 1), this.attributes[e] = new D(l, r, i, n, o, s, a), this.instanced = this.instanced || a, this
                    }, e.prototype.getAttribute = function(e) {
                        return this.attributes[e]
                    }, e.prototype.getBuffer = function(e) {
                        return this.buffers[this.getAttribute(e).buffer]
                    }, e.prototype.addIndex = function(e) {
                        return e instanceof k || (e instanceof Array && (e = new Uint16Array(e)), e = new k(e)), e.type = n.mr.ELEMENT_ARRAY_BUFFER, this.indexBuffer = e, -1 === this.buffers.indexOf(e) && this.buffers.push(e), this
                    }, e.prototype.getIndex = function() {
                        return this.indexBuffer
                    }, e.prototype.interleave = function() {
                        if (1 === this.buffers.length || 2 === this.buffers.length && this.indexBuffer) return this;
                        var e, t = [],
                            r = [],
                            i = new k;
                        for (e in this.attributes) {
                            var n = this.attributes[e],
                                s = this.buffers[n.buffer];
                            t.push(s.data), r.push(n.size * X[n.type] / 4), n.buffer = 0
                        }
                        for (i.data = function(e, t) {
                                for (var r = 0, i = 0, n = {}, s = 0; s < e.length; s++) i += t[s], r += e[s].length;
                                var a = new ArrayBuffer(4 * r),
                                    u = null,
                                    h = 0;
                                for (s = 0; s < e.length; s++) {
                                    var l = t[s],
                                        d = e[s],
                                        f = (0, o.u7)(d);
                                    n[f] || (n[f] = new V[f](a)), u = n[f];
                                    for (var c = 0; c < d.length; c++) u[(c / l | 0) * i + h + c % l] = d[c];
                                    h += l
                                }
                                return new Float32Array(a)
                            }(t, r), e = 0; e < this.buffers.length; e++) this.buffers[e] !== this.indexBuffer && this.buffers[e].destroy();
                        return this.buffers = [i], this.indexBuffer && this.buffers.push(this.indexBuffer), this
                    }, e.prototype.getSize = function() {
                        for (var e in this.attributes) {
                            var t = this.attributes[e];
                            return this.buffers[t.buffer].data.length / (t.stride / 4 || t.size)
                        }
                        return 0
                    }, e.prototype.dispose = function() {
                        this.disposeRunner.emit(this, !1)
                    }, e.prototype.destroy = function() {
                        this.dispose(), this.buffers = null, this.indexBuffer = null, this.attributes = null
                    }, e.prototype.clone = function() {
                        for (var t = new e, r = 0; r < this.buffers.length; r++) t.buffers[r] = new k(this.buffers[r].data.slice(0));
                        for (var r in this.attributes) {
                            var i = this.attributes[r];
                            t.attributes[r] = new D(i.buffer, i.size, i.normalized, i.type, i.stride, i.start, i.instance)
                        }
                        return this.indexBuffer && (t.indexBuffer = t.buffers[this.buffers.indexOf(this.indexBuffer)], t.indexBuffer.type = n.mr.ELEMENT_ARRAY_BUFFER), t
                    }, e.merge = function(t) {
                        for (var r, i = new e, s = [], a = [], u = [], h = 0; h < t.length; h++) {
                            r = t[h];
                            for (var l = 0; l < r.buffers.length; l++) a[l] = a[l] || 0, a[l] += r.buffers[l].data.length, u[l] = 0
                        }
                        for (h = 0; h < r.buffers.length; h++) s[h] = new(j[(0, o.u7)(r.buffers[h].data)])(a[h]), i.buffers[h] = new k(s[h]);
                        for (h = 0; h < t.length; h++) {
                            r = t[h];
                            for (l = 0; l < r.buffers.length; l++) s[l].set(r.buffers[l].data, u[l]), u[l] += r.buffers[l].data.length
                        }
                        if (i.attributes = r.attributes, r.indexBuffer) {
                            i.indexBuffer = i.buffers[r.buffers.indexOf(r.indexBuffer)], i.indexBuffer.type = n.mr.ELEMENT_ARRAY_BUFFER;
                            var d = 0,
                                f = 0,
                                c = 0,
                                p = 0;
                            for (h = 0; h < r.buffers.length; h++)
                                if (r.buffers[h] !== r.indexBuffer) {
                                    p = h;
                                    break
                                }
                            for (var h in r.attributes) {
                                var v = r.attributes[h];
                                (0 | v.buffer) === p && (f += v.size * X[v.type] / 4)
                            }
                            for (h = 0; h < t.length; h++) {
                                var m = t[h].indexBuffer.data;
                                for (l = 0; l < m.length; l++) i.indexBuffer.data[l + c] += d;
                                d += t[h].buffers[p].data.length / f, c += m.length
                            }
                        }
                        return i
                    }, e
                }(),
                W = function(e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t.addAttribute("aVertexPosition", new Float32Array([0, 0, 1, 0, 1, 1, 0, 1])).addIndex([0, 1, 3, 2]), t
                    }
                    return c(t, e), t
                }(z),
                K = function(e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t.vertices = new Float32Array([-1, -1, 1, -1, 1, 1, -1, 1]), t.uvs = new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]), t.vertexBuffer = new k(t.vertices), t.uvBuffer = new k(t.uvs), t.addAttribute("aVertexPosition", t.vertexBuffer).addAttribute("aTextureCoord", t.uvBuffer).addIndex([0, 1, 2, 0, 2, 3]), t
                    }
                    return c(t, e), t.prototype.map = function(e, t) {
                        var r = 0,
                            i = 0;
                        return this.uvs[0] = r, this.uvs[1] = i, this.uvs[2] = r + t.width / e.width, this.uvs[3] = i, this.uvs[4] = r + t.width / e.width, this.uvs[5] = i + t.height / e.height, this.uvs[6] = r, this.uvs[7] = i + t.height / e.height, r = t.x, i = t.y, this.vertices[0] = r, this.vertices[1] = i, this.vertices[2] = r + t.width, this.vertices[3] = i, this.vertices[4] = r + t.width, this.vertices[5] = i + t.height, this.vertices[6] = r, this.vertices[7] = i + t.height, this.invalidate(), this
                    }, t.prototype.invalidate = function() {
                        return this.vertexBuffer._updateID++, this.uvBuffer._updateID++, this
                    }, t
                }(z),
                Y = 0,
                $ = function() {
                    function e(e, t, r) {
                        this.group = !0, this.syncUniforms = {}, this.dirtyId = 0, this.id = Y++, this.static = !!t, this.ubo = !!r, e instanceof k ? (this.buffer = e, this.buffer.type = n.mr.UNIFORM_BUFFER, this.autoManage = !1, this.ubo = !0) : (this.uniforms = e, this.ubo && (this.buffer = new k(new Float32Array(1)), this.buffer.type = n.mr.UNIFORM_BUFFER, this.autoManage = !0))
                    }
                    return e.prototype.update = function() {
                        this.dirtyId++, !this.autoManage && this.buffer && this.buffer.update()
                    }, e.prototype.add = function(t, r, i) {
                        if (this.ubo) throw new Error("[UniformGroup] uniform groups in ubo mode cannot be modified, or have uniform groups nested in them");
                        this.uniforms[t] = new e(r, i)
                    }, e.from = function(t, r, i) {
                        return new e(t, r, i)
                    }, e.uboFrom = function(t, r) {
                        return new e(t, null === r || void 0 === r || r, !0)
                    }, e
                }(),
                q = function() {
                    function e() {
                        this.renderTexture = null, this.target = null, this.legacy = !1, this.resolution = 1, this.multisample = n.G5.NONE, this.sourceFrame = new h.Ae, this.destinationFrame = new h.Ae, this.bindingSourceFrame = new h.Ae, this.bindingDestinationFrame = new h.Ae, this.filters = [], this.transform = null
                    }
                    return e.prototype.clear = function() {
                        this.target = null, this.filters = null, this.renderTexture = null
                    }, e
                }(),
                Z = [new h.E9, new h.E9, new h.E9, new h.E9],
                Q = new h.y3,
                J = function() {
                    function e(e) {
                        this.renderer = e, this.defaultFilterStack = [{}], this.texturePool = new L, this.texturePool.setScreenSize(e.view), this.statePool = [], this.quad = new W, this.quadUv = new K, this.tempRect = new h.Ae, this.activeState = {}, this.globalUniforms = new $({
                            outputFrame: new h.Ae,
                            inputSize: new Float32Array(4),
                            inputPixel: new Float32Array(4),
                            inputClamp: new Float32Array(4),
                            resolution: 1,
                            filterArea: new Float32Array(4),
                            filterClamp: new Float32Array(4)
                        }, !0), this.forceClear = !1, this.useMaxPadding = !1
                    }
                    return e.prototype.push = function(e, t) {
                        for (var r, i, n = this.renderer, o = this.defaultFilterStack, s = this.statePool.pop() || new q, a = this.renderer.renderTexture, u = t[0].resolution, h = t[0].multisample, l = t[0].padding, d = t[0].autoFit, f = null === (r = t[0].legacy) || void 0 === r || r, c = 1; c < t.length; c++) {
                            var p = t[c];
                            u = Math.min(u, p.resolution), h = Math.min(h, p.multisample), l = this.useMaxPadding ? Math.max(l, p.padding) : l + p.padding, d = d && p.autoFit, f = f || null === (i = p.legacy) || void 0 === i || i
                        }
                        1 === o.length && (this.defaultFilterStack[0].renderTexture = a.current), o.push(s), s.resolution = u, s.multisample = h, s.legacy = f, s.target = e, s.sourceFrame.copyFrom(e.filterArea || e.getBounds(!0)), s.sourceFrame.pad(l);
                        var v = this.tempRect.copyFrom(a.sourceFrame);
                        n.projection.transform && this.transformAABB(Q.copyFrom(n.projection.transform).invert(), v), d ? (s.sourceFrame.fit(v), (s.sourceFrame.width <= 0 || s.sourceFrame.height <= 0) && (s.sourceFrame.width = 0, s.sourceFrame.height = 0)) : s.sourceFrame.intersects(v) || (s.sourceFrame.width = 0, s.sourceFrame.height = 0), this.roundFrame(s.sourceFrame, a.current ? a.current.resolution : n.resolution, a.sourceFrame, a.destinationFrame, n.projection.transform), s.renderTexture = this.getOptimalFilterTexture(s.sourceFrame.width, s.sourceFrame.height, u, h), s.filters = t, s.destinationFrame.width = s.renderTexture.width, s.destinationFrame.height = s.renderTexture.height;
                        var m = this.tempRect;
                        m.x = 0, m.y = 0, m.width = s.sourceFrame.width, m.height = s.sourceFrame.height, s.renderTexture.filterFrame = s.sourceFrame, s.bindingSourceFrame.copyFrom(a.sourceFrame), s.bindingDestinationFrame.copyFrom(a.destinationFrame), s.transform = n.projection.transform, n.projection.transform = null, a.bind(s.renderTexture, s.sourceFrame, m), n.framebuffer.clear(0, 0, 0, 0)
                    }, e.prototype.pop = function() {
                        var e = this.defaultFilterStack,
                            t = e.pop(),
                            r = t.filters;
                        this.activeState = t;
                        var i = this.globalUniforms.uniforms;
                        i.outputFrame = t.sourceFrame, i.resolution = t.resolution;
                        var o = i.inputSize,
                            s = i.inputPixel,
                            a = i.inputClamp;
                        if (o[0] = t.destinationFrame.width, o[1] = t.destinationFrame.height, o[2] = 1 / o[0], o[3] = 1 / o[1], s[0] = Math.round(o[0] * t.resolution), s[1] = Math.round(o[1] * t.resolution), s[2] = 1 / s[0], s[3] = 1 / s[1], a[0] = .5 * s[2], a[1] = .5 * s[3], a[2] = t.sourceFrame.width * o[2] - .5 * s[2], a[3] = t.sourceFrame.height * o[3] - .5 * s[3], t.legacy) {
                            var u = i.filterArea;
                            u[0] = t.destinationFrame.width, u[1] = t.destinationFrame.height, u[2] = t.sourceFrame.x, u[3] = t.sourceFrame.y, i.filterClamp = i.inputClamp
                        }
                        this.globalUniforms.update();
                        var h = e[e.length - 1];
                        if (this.renderer.framebuffer.blit(), 1 === r.length) r[0].apply(this, t.renderTexture, h.renderTexture, n.yl.BLEND, t), this.returnFilterTexture(t.renderTexture);
                        else {
                            var l = t.renderTexture,
                                d = this.getOptimalFilterTexture(l.width, l.height, t.resolution);
                            d.filterFrame = l.filterFrame;
                            var f = 0;
                            for (f = 0; f < r.length - 1; ++f) {
                                1 === f && t.multisample > 1 && ((d = this.getOptimalFilterTexture(l.width, l.height, t.resolution)).filterFrame = l.filterFrame), r[f].apply(this, l, d, n.yl.CLEAR, t);
                                var c = l;
                                l = d, d = c
                            }
                            r[f].apply(this, l, h.renderTexture, n.yl.BLEND, t), f > 1 && t.multisample > 1 && this.returnFilterTexture(t.renderTexture), this.returnFilterTexture(l), this.returnFilterTexture(d)
                        }
                        t.clear(), this.statePool.push(t)
                    }, e.prototype.bindAndClear = function(e, t) {
                        void 0 === t && (t = n.yl.CLEAR);
                        var r = this.renderer,
                            i = r.renderTexture,
                            o = r.state;
                        if (e === this.defaultFilterStack[this.defaultFilterStack.length - 1].renderTexture ? this.renderer.projection.transform = this.activeState.transform : this.renderer.projection.transform = null, e && e.filterFrame) {
                            var s = this.tempRect;
                            s.x = 0, s.y = 0, s.width = e.filterFrame.width, s.height = e.filterFrame.height, i.bind(e, e.filterFrame, s)
                        } else e !== this.defaultFilterStack[this.defaultFilterStack.length - 1].renderTexture ? i.bind(e) : this.renderer.renderTexture.bind(e, this.activeState.bindingSourceFrame, this.activeState.bindingDestinationFrame);
                        var a = 1 & o.stateId || this.forceClear;
                        (t === n.yl.CLEAR || t === n.yl.BLIT && a) && this.renderer.framebuffer.clear(0, 0, 0, 0)
                    }, e.prototype.applyFilter = function(e, t, r, i) {
                        var o = this.renderer;
                        o.state.set(e.state), this.bindAndClear(r, i), e.uniforms.uSampler = t, e.uniforms.filterGlobals = this.globalUniforms, o.shader.bind(e), e.legacy = !!e.program.attributeData.aTextureCoord, e.legacy ? (this.quadUv.map(t._frame, t.filterFrame), o.geometry.bind(this.quadUv), o.geometry.draw(n.lg.TRIANGLES)) : (o.geometry.bind(this.quad), o.geometry.draw(n.lg.TRIANGLE_STRIP))
                    }, e.prototype.calculateSpriteMatrix = function(e, t) {
                        var r = this.activeState,
                            i = r.sourceFrame,
                            n = r.destinationFrame,
                            o = t._texture.orig,
                            s = e.set(n.width, 0, 0, n.height, i.x, i.y),
                            a = t.worldTransform.copyTo(h.y3.TEMP_MATRIX);
                        return a.invert(), s.prepend(a), s.scale(1 / o.width, 1 / o.height), s.translate(t.anchor.x, t.anchor.y), s
                    }, e.prototype.destroy = function() {
                        this.renderer = null, this.texturePool.clear(!1)
                    }, e.prototype.getOptimalFilterTexture = function(e, t, r, i) {
                        return void 0 === r && (r = 1), void 0 === i && (i = n.G5.NONE), this.texturePool.getOptimalTexture(e, t, r, i)
                    }, e.prototype.getFilterTexture = function(e, t, r) {
                        if ("number" === typeof e) {
                            var i = e;
                            e = t, t = i
                        }
                        e = e || this.activeState.renderTexture;
                        var o = this.texturePool.getOptimalTexture(e.width, e.height, t || e.resolution, r || n.G5.NONE);
                        return o.filterFrame = e.filterFrame, o
                    }, e.prototype.returnFilterTexture = function(e) {
                        this.texturePool.returnTexture(e)
                    }, e.prototype.emptyPool = function() {
                        this.texturePool.clear(!0)
                    }, e.prototype.resize = function() {
                        this.texturePool.setScreenSize(this.renderer.view)
                    }, e.prototype.transformAABB = function(e, t) {
                        var r = Z[0],
                            i = Z[1],
                            n = Z[2],
                            o = Z[3];
                        r.set(t.left, t.top), i.set(t.left, t.bottom), n.set(t.right, t.top), o.set(t.right, t.bottom), e.apply(r, r), e.apply(i, i), e.apply(n, n), e.apply(o, o);
                        var s = Math.min(r.x, i.x, n.x, o.x),
                            a = Math.min(r.y, i.y, n.y, o.y),
                            u = Math.max(r.x, i.x, n.x, o.x),
                            h = Math.max(r.y, i.y, n.y, o.y);
                        t.x = s, t.y = a, t.width = u - s, t.height = h - a
                    }, e.prototype.roundFrame = function(e, t, r, i, n) {
                        if (!(e.width <= 0 || e.height <= 0 || r.width <= 0 || r.height <= 0)) {
                            if (n) {
                                var o = n.a,
                                    s = n.b,
                                    a = n.c,
                                    u = n.d;
                                if ((Math.abs(s) > 1e-4 || Math.abs(a) > 1e-4) && (Math.abs(o) > 1e-4 || Math.abs(u) > 1e-4)) return
                            }(n = n ? Q.copyFrom(n) : Q.identity()).translate(-r.x, -r.y).scale(i.width / r.width, i.height / r.height).translate(i.x, i.y), this.transformAABB(n, e), e.ceil(t), this.transformAABB(n.invert(), e)
                        }
                    }, e
                }(),
                ee = function() {
                    function e(e) {
                        this.renderer = e
                    }
                    return e.prototype.flush = function() {}, e.prototype.destroy = function() {
                        this.renderer = null
                    }, e.prototype.start = function() {}, e.prototype.stop = function() {
                        this.flush()
                    }, e.prototype.render = function(e) {}, e
                }(),
                te = function() {
                    function e(e) {
                        this.renderer = e, this.emptyRenderer = new ee(e), this.currentRenderer = this.emptyRenderer
                    }
                    return e.prototype.setObjectRenderer = function(e) {
                        this.currentRenderer !== e && (this.currentRenderer.stop(), this.currentRenderer = e, this.currentRenderer.start())
                    }, e.prototype.flush = function() {
                        this.setObjectRenderer(this.emptyRenderer)
                    }, e.prototype.reset = function() {
                        this.setObjectRenderer(this.emptyRenderer)
                    }, e.prototype.copyBoundTextures = function(e, t) {
                        for (var r = this.renderer.texture.boundTextures, i = t - 1; i >= 0; --i) e[i] = r[i] || null, e[i] && (e[i]._batchLocation = i)
                    }, e.prototype.boundArray = function(e, t, r, i) {
                        for (var n = e.elements, o = e.ids, s = e.count, a = 0, u = 0; u < s; u++) {
                            var h = n[u],
                                l = h._batchLocation;
                            if (l >= 0 && l < i && t[l] === h) o[u] = l;
                            else
                                for (; a < i;) {
                                    var d = t[a];
                                    if (!d || d._batchEnabled !== r || d._batchLocation !== a) {
                                        o[u] = a, h._batchLocation = a, t[a] = h;
                                        break
                                    }
                                    a++
                                }
                        }
                    }, e.prototype.destroy = function() {
                        this.renderer = null
                    }, e
                }(),
                re = 0,
                ie = function() {
                    function e(e) {
                        this.renderer = e, this.webGLVersion = 1, this.extensions = {}, this.supports = {
                            uint32Indices: !1
                        }, this.handleContextLost = this.handleContextLost.bind(this), this.handleContextRestored = this.handleContextRestored.bind(this), e.view.addEventListener("webglcontextlost", this.handleContextLost, !1), e.view.addEventListener("webglcontextrestored", this.handleContextRestored, !1)
                    }
                    return Object.defineProperty(e.prototype, "isLost", {
                        get: function() {
                            return !this.gl || this.gl.isContextLost()
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.contextChange = function(e) {
                        this.gl = e, this.renderer.gl = e, this.renderer.CONTEXT_UID = re++
                    }, e.prototype.initFromContext = function(e) {
                        this.gl = e, this.validateContext(e), this.renderer.gl = e, this.renderer.CONTEXT_UID = re++, this.renderer.runners.contextChange.emit(e)
                    }, e.prototype.initFromOptions = function(e) {
                        var t = this.createContext(this.renderer.view, e);
                        this.initFromContext(t)
                    }, e.prototype.createContext = function(e, t) {
                        var r;
                        if (i.Xd.PREFER_ENV >= n.Vi.WEBGL2 && (r = e.getContext("webgl2", t)), r) this.webGLVersion = 2;
                        else if (this.webGLVersion = 1, !(r = e.getContext("webgl", t) || e.getContext("experimental-webgl", t))) throw new Error("This browser does not support WebGL. Try using the canvas renderer");
                        return this.gl = r, this.getExtensions(), this.gl
                    }, e.prototype.getExtensions = function() {
                        var e = this.gl,
                            t = {
                                loseContext: e.getExtension("WEBGL_lose_context"),
                                anisotropicFiltering: e.getExtension("EXT_texture_filter_anisotropic"),
                                floatTextureLinear: e.getExtension("OES_texture_float_linear"),
                                s3tc: e.getExtension("WEBGL_compressed_texture_s3tc"),
                                s3tc_sRGB: e.getExtension("WEBGL_compressed_texture_s3tc_srgb"),
                                etc: e.getExtension("WEBGL_compressed_texture_etc"),
                                etc1: e.getExtension("WEBGL_compressed_texture_etc1"),
                                pvrtc: e.getExtension("WEBGL_compressed_texture_pvrtc") || e.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc"),
                                atc: e.getExtension("WEBGL_compressed_texture_atc"),
                                astc: e.getExtension("WEBGL_compressed_texture_astc")
                            };
                        1 === this.webGLVersion ? Object.assign(this.extensions, t, {
                            drawBuffers: e.getExtension("WEBGL_draw_buffers"),
                            depthTexture: e.getExtension("WEBGL_depth_texture"),
                            vertexArrayObject: e.getExtension("OES_vertex_array_object") || e.getExtension("MOZ_OES_vertex_array_object") || e.getExtension("WEBKIT_OES_vertex_array_object"),
                            uint32ElementIndex: e.getExtension("OES_element_index_uint"),
                            floatTexture: e.getExtension("OES_texture_float"),
                            floatTextureLinear: e.getExtension("OES_texture_float_linear"),
                            textureHalfFloat: e.getExtension("OES_texture_half_float"),
                            textureHalfFloatLinear: e.getExtension("OES_texture_half_float_linear")
                        }) : 2 === this.webGLVersion && Object.assign(this.extensions, t, {
                            colorBufferFloat: e.getExtension("EXT_color_buffer_float")
                        })
                    }, e.prototype.handleContextLost = function(e) {
                        var t = this;
                        e.preventDefault(), setTimeout((function() {
                            t.gl.isContextLost() && t.extensions.loseContext && t.extensions.loseContext.restoreContext()
                        }), 0)
                    }, e.prototype.handleContextRestored = function() {
                        this.renderer.runners.contextChange.emit(this.gl)
                    }, e.prototype.destroy = function() {
                        var e = this.renderer.view;
                        this.renderer = null, e.removeEventListener("webglcontextlost", this.handleContextLost), e.removeEventListener("webglcontextrestored", this.handleContextRestored), this.gl.useProgram(null), this.extensions.loseContext && this.extensions.loseContext.loseContext()
                    }, e.prototype.postrender = function() {
                        this.renderer.renderingToScreen && this.gl.flush()
                    }, e.prototype.validateContext = function(e) {
                        var t = e.getContextAttributes(),
                            r = "WebGL2RenderingContext" in globalThis && e instanceof globalThis.WebGL2RenderingContext;
                        r && (this.webGLVersion = 2), t && !t.stencil && console.warn("Provided WebGL context does not have a stencil buffer, masks may not render correctly");
                        var i = r || !!e.getExtension("OES_element_index_uint");
                        this.supports.uint32Indices = i, i || console.warn("Provided WebGL context does not support 32 index buffer, complex graphics may not render correctly")
                    }, e
                }(),
                ne = function(e) {
                    this.framebuffer = e, this.stencil = null, this.dirtyId = -1, this.dirtyFormat = -1, this.dirtySize = -1, this.multisample = n.G5.NONE, this.msaaBuffer = null, this.blitFramebuffer = null, this.mipLevel = 0
                },
                oe = new h.Ae,
                se = function() {
                    function e(e) {
                        this.renderer = e, this.managedFramebuffers = [], this.unknownFramebuffer = new F(10, 10), this.msaaSamples = null
                    }
                    return e.prototype.contextChange = function() {
                        this.disposeAll(!0);
                        var e = this.gl = this.renderer.gl;
                        if (this.CONTEXT_UID = this.renderer.CONTEXT_UID, this.current = this.unknownFramebuffer, this.viewport = new h.Ae, this.hasMRT = !0, this.writeDepthTexture = !0, 1 === this.renderer.context.webGLVersion) {
                            var t = this.renderer.context.extensions.drawBuffers,
                                r = this.renderer.context.extensions.depthTexture;
                            i.Xd.PREFER_ENV === n.Vi.WEBGL_LEGACY && (t = null, r = null), t ? e.drawBuffers = function(e) {
                                return t.drawBuffersWEBGL(e)
                            } : (this.hasMRT = !1, e.drawBuffers = function() {}), r || (this.writeDepthTexture = !1)
                        } else this.msaaSamples = e.getInternalformatParameter(e.RENDERBUFFER, e.RGBA8, e.SAMPLES)
                    }, e.prototype.bind = function(e, t, r) {
                        void 0 === r && (r = 0);
                        var i = this.gl;
                        if (e) {
                            var n = e.glFramebuffers[this.CONTEXT_UID] || this.initFramebuffer(e);
                            this.current !== e && (this.current = e, i.bindFramebuffer(i.FRAMEBUFFER, n.framebuffer)), n.mipLevel !== r && (e.dirtyId++, e.dirtyFormat++, n.mipLevel = r), n.dirtyId !== e.dirtyId && (n.dirtyId = e.dirtyId, n.dirtyFormat !== e.dirtyFormat ? (n.dirtyFormat = e.dirtyFormat, n.dirtySize = e.dirtySize, this.updateFramebuffer(e, r)) : n.dirtySize !== e.dirtySize && (n.dirtySize = e.dirtySize, this.resizeFramebuffer(e)));
                            for (var o = 0; o < e.colorTextures.length; o++) {
                                var s = e.colorTextures[o];
                                this.renderer.texture.unbind(s.parentTextureArray || s)
                            }
                            if (e.depthTexture && this.renderer.texture.unbind(e.depthTexture), t) {
                                var a = t.width >> r,
                                    u = t.height >> r,
                                    h = a / t.width;
                                this.setViewport(t.x * h, t.y * h, a, u)
                            } else {
                                a = e.width >> r, u = e.height >> r;
                                this.setViewport(0, 0, a, u)
                            }
                        } else this.current && (this.current = null, i.bindFramebuffer(i.FRAMEBUFFER, null)), t ? this.setViewport(t.x, t.y, t.width, t.height) : this.setViewport(0, 0, this.renderer.width, this.renderer.height)
                    }, e.prototype.setViewport = function(e, t, r, i) {
                        var n = this.viewport;
                        e = Math.round(e), t = Math.round(t), r = Math.round(r), i = Math.round(i), n.width === r && n.height === i && n.x === e && n.y === t || (n.x = e, n.y = t, n.width = r, n.height = i, this.gl.viewport(e, t, r, i))
                    }, Object.defineProperty(e.prototype, "size", {
                        get: function() {
                            return this.current ? {
                                x: 0,
                                y: 0,
                                width: this.current.width,
                                height: this.current.height
                            } : {
                                x: 0,
                                y: 0,
                                width: this.renderer.width,
                                height: this.renderer.height
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.clear = function(e, t, r, i, o) {
                        void 0 === o && (o = n.V0.COLOR | n.V0.DEPTH);
                        var s = this.gl;
                        s.clearColor(e, t, r, i), s.clear(o)
                    }, e.prototype.initFramebuffer = function(e) {
                        var t = this.gl,
                            r = new ne(t.createFramebuffer());
                        return r.multisample = this.detectSamples(e.multisample), e.glFramebuffers[this.CONTEXT_UID] = r, this.managedFramebuffers.push(e), e.disposeRunner.add(this), r
                    }, e.prototype.resizeFramebuffer = function(e) {
                        var t = this.gl,
                            r = e.glFramebuffers[this.CONTEXT_UID];
                        r.msaaBuffer && (t.bindRenderbuffer(t.RENDERBUFFER, r.msaaBuffer), t.renderbufferStorageMultisample(t.RENDERBUFFER, r.multisample, t.RGBA8, e.width, e.height)), r.stencil && (t.bindRenderbuffer(t.RENDERBUFFER, r.stencil), r.msaaBuffer ? t.renderbufferStorageMultisample(t.RENDERBUFFER, r.multisample, t.DEPTH24_STENCIL8, e.width, e.height) : t.renderbufferStorage(t.RENDERBUFFER, t.DEPTH_STENCIL, e.width, e.height));
                        var i = e.colorTextures,
                            n = i.length;
                        t.drawBuffers || (n = Math.min(n, 1));
                        for (var o = 0; o < n; o++) {
                            var s = i[o],
                                a = s.parentTextureArray || s;
                            this.renderer.texture.bind(a, 0)
                        }
                        e.depthTexture && this.writeDepthTexture && this.renderer.texture.bind(e.depthTexture, 0)
                    }, e.prototype.updateFramebuffer = function(e, t) {
                        var r = this.gl,
                            i = e.glFramebuffers[this.CONTEXT_UID],
                            n = e.colorTextures,
                            o = n.length;
                        r.drawBuffers || (o = Math.min(o, 1)), i.multisample > 1 && this.canMultisampleFramebuffer(e) ? (i.msaaBuffer = i.msaaBuffer || r.createRenderbuffer(), r.bindRenderbuffer(r.RENDERBUFFER, i.msaaBuffer), r.renderbufferStorageMultisample(r.RENDERBUFFER, i.multisample, r.RGBA8, e.width, e.height), r.framebufferRenderbuffer(r.FRAMEBUFFER, r.COLOR_ATTACHMENT0, r.RENDERBUFFER, i.msaaBuffer)) : i.msaaBuffer && (r.deleteRenderbuffer(i.msaaBuffer), i.msaaBuffer = null, i.blitFramebuffer && (i.blitFramebuffer.dispose(), i.blitFramebuffer = null));
                        for (var s = [], a = 0; a < o; a++) {
                            var u = n[a],
                                h = u.parentTextureArray || u;
                            this.renderer.texture.bind(h, 0), 0 === a && i.msaaBuffer || (r.framebufferTexture2D(r.FRAMEBUFFER, r.COLOR_ATTACHMENT0 + a, u.target, h._glTextures[this.CONTEXT_UID].texture, t), s.push(r.COLOR_ATTACHMENT0 + a))
                        }
                        if ((s.length > 1 && r.drawBuffers(s), e.depthTexture) && this.writeDepthTexture) {
                            var l = e.depthTexture;
                            this.renderer.texture.bind(l, 0), r.framebufferTexture2D(r.FRAMEBUFFER, r.DEPTH_ATTACHMENT, r.TEXTURE_2D, l._glTextures[this.CONTEXT_UID].texture, t)
                        }!e.stencil && !e.depth || e.depthTexture && this.writeDepthTexture ? i.stencil && (r.deleteRenderbuffer(i.stencil), i.stencil = null) : (i.stencil = i.stencil || r.createRenderbuffer(), r.bindRenderbuffer(r.RENDERBUFFER, i.stencil), i.msaaBuffer ? r.renderbufferStorageMultisample(r.RENDERBUFFER, i.multisample, r.DEPTH24_STENCIL8, e.width, e.height) : r.renderbufferStorage(r.RENDERBUFFER, r.DEPTH_STENCIL, e.width, e.height), r.framebufferRenderbuffer(r.FRAMEBUFFER, r.DEPTH_STENCIL_ATTACHMENT, r.RENDERBUFFER, i.stencil))
                    }, e.prototype.canMultisampleFramebuffer = function(e) {
                        return 1 !== this.renderer.context.webGLVersion && e.colorTextures.length <= 1 && !e.depthTexture
                    }, e.prototype.detectSamples = function(e) {
                        var t = this.msaaSamples,
                            r = n.G5.NONE;
                        if (e <= 1 || null === t) return r;
                        for (var i = 0; i < t.length; i++)
                            if (t[i] <= e) {
                                r = t[i];
                                break
                            }
                        return 1 === r && (r = n.G5.NONE), r
                    }, e.prototype.blit = function(e, t, r) {
                        var i = this,
                            n = i.current,
                            o = i.renderer,
                            s = i.gl,
                            a = i.CONTEXT_UID;
                        if (2 === o.context.webGLVersion && n) {
                            var u = n.glFramebuffers[a];
                            if (u) {
                                if (!e) {
                                    if (!u.msaaBuffer) return;
                                    var h = n.colorTextures[0];
                                    if (!h) return;
                                    u.blitFramebuffer || (u.blitFramebuffer = new F(n.width, n.height), u.blitFramebuffer.addColorTexture(0, h)), (e = u.blitFramebuffer).colorTextures[0] !== h && (e.colorTextures[0] = h, e.dirtyId++, e.dirtyFormat++), e.width === n.width && e.height === n.height || (e.width = n.width, e.height = n.height, e.dirtyId++, e.dirtySize++)
                                }
                                t || ((t = oe).width = n.width, t.height = n.height), r || (r = t);
                                var l = t.width === r.width && t.height === r.height;
                                this.bind(e), s.bindFramebuffer(s.READ_FRAMEBUFFER, u.framebuffer), s.blitFramebuffer(t.left, t.top, t.right, t.bottom, r.left, r.top, r.right, r.bottom, s.COLOR_BUFFER_BIT, l ? s.NEAREST : s.LINEAR)
                            }
                        }
                    }, e.prototype.disposeFramebuffer = function(e, t) {
                        var r = e.glFramebuffers[this.CONTEXT_UID],
                            i = this.gl;
                        if (r) {
                            delete e.glFramebuffers[this.CONTEXT_UID];
                            var n = this.managedFramebuffers.indexOf(e);
                            n >= 0 && this.managedFramebuffers.splice(n, 1), e.disposeRunner.remove(this), t || (i.deleteFramebuffer(r.framebuffer), r.msaaBuffer && i.deleteRenderbuffer(r.msaaBuffer), r.stencil && i.deleteRenderbuffer(r.stencil)), r.blitFramebuffer && r.blitFramebuffer.dispose()
                        }
                    }, e.prototype.disposeAll = function(e) {
                        var t = this.managedFramebuffers;
                        this.managedFramebuffers = [];
                        for (var r = 0; r < t.length; r++) this.disposeFramebuffer(t[r], e)
                    }, e.prototype.forceStencil = function() {
                        var e = this.current;
                        if (e) {
                            var t = e.glFramebuffers[this.CONTEXT_UID];
                            if (t && !t.stencil) {
                                e.stencil = !0;
                                var r = e.width,
                                    i = e.height,
                                    n = this.gl,
                                    o = n.createRenderbuffer();
                                n.bindRenderbuffer(n.RENDERBUFFER, o), t.msaaBuffer ? n.renderbufferStorageMultisample(n.RENDERBUFFER, t.multisample, n.DEPTH24_STENCIL8, r, i) : n.renderbufferStorage(n.RENDERBUFFER, n.DEPTH_STENCIL, r, i), t.stencil = o, n.framebufferRenderbuffer(n.FRAMEBUFFER, n.DEPTH_STENCIL_ATTACHMENT, n.RENDERBUFFER, o)
                            }
                        }
                    }, e.prototype.reset = function() {
                        this.current = this.unknownFramebuffer, this.viewport = new h.Ae
                    }, e.prototype.destroy = function() {
                        this.renderer = null
                    }, e
                }(),
                ae = {
                    5126: 4,
                    5123: 2,
                    5121: 1
                },
                ue = function() {
                    function e(e) {
                        this.renderer = e, this._activeGeometry = null, this._activeVao = null, this.hasVao = !0, this.hasInstance = !0, this.canUseUInt32ElementIndex = !1, this.managedGeometries = {}
                    }
                    return e.prototype.contextChange = function() {
                        this.disposeAll(!0);
                        var e = this.gl = this.renderer.gl,
                            t = this.renderer.context;
                        if (this.CONTEXT_UID = this.renderer.CONTEXT_UID, 2 !== t.webGLVersion) {
                            var r = this.renderer.context.extensions.vertexArrayObject;
                            i.Xd.PREFER_ENV === n.Vi.WEBGL_LEGACY && (r = null), r ? (e.createVertexArray = function() {
                                return r.createVertexArrayOES()
                            }, e.bindVertexArray = function(e) {
                                return r.bindVertexArrayOES(e)
                            }, e.deleteVertexArray = function(e) {
                                return r.deleteVertexArrayOES(e)
                            }) : (this.hasVao = !1, e.createVertexArray = function() {
                                return null
                            }, e.bindVertexArray = function() {
                                return null
                            }, e.deleteVertexArray = function() {
                                return null
                            })
                        }
                        if (2 !== t.webGLVersion) {
                            var o = e.getExtension("ANGLE_instanced_arrays");
                            o ? (e.vertexAttribDivisor = function(e, t) {
                                return o.vertexAttribDivisorANGLE(e, t)
                            }, e.drawElementsInstanced = function(e, t, r, i, n) {
                                return o.drawElementsInstancedANGLE(e, t, r, i, n)
                            }, e.drawArraysInstanced = function(e, t, r, i) {
                                return o.drawArraysInstancedANGLE(e, t, r, i)
                            }) : this.hasInstance = !1
                        }
                        this.canUseUInt32ElementIndex = 2 === t.webGLVersion || !!t.extensions.uint32ElementIndex
                    }, e.prototype.bind = function(e, t) {
                        t = t || this.renderer.shader.shader;
                        var r = this.gl,
                            i = e.glVertexArrayObjects[this.CONTEXT_UID],
                            n = !1;
                        i || (this.managedGeometries[e.id] = e, e.disposeRunner.add(this), e.glVertexArrayObjects[this.CONTEXT_UID] = i = {}, n = !0);
                        var o = i[t.program.id] || this.initGeometryVao(e, t, n);
                        this._activeGeometry = e, this._activeVao !== o && (this._activeVao = o, this.hasVao ? r.bindVertexArray(o) : this.activateVao(e, t.program)), this.updateBuffers()
                    }, e.prototype.reset = function() {
                        this.unbind()
                    }, e.prototype.updateBuffers = function() {
                        for (var e = this._activeGeometry, t = this.renderer.buffer, r = 0; r < e.buffers.length; r++) {
                            var i = e.buffers[r];
                            t.update(i)
                        }
                    }, e.prototype.checkCompatibility = function(e, t) {
                        var r = e.attributes,
                            i = t.attributeData;
                        for (var n in i)
                            if (!r[n]) throw new Error('shader and geometry incompatible, geometry missing the "' + n + '" attribute')
                    }, e.prototype.getSignature = function(e, t) {
                        var r = e.attributes,
                            i = t.attributeData,
                            n = ["g", e.id];
                        for (var o in r) i[o] && n.push(o, i[o].location);
                        return n.join("-")
                    }, e.prototype.initGeometryVao = function(e, t, r) {
                        void 0 === r && (r = !0);
                        var i = this.gl,
                            n = this.CONTEXT_UID,
                            o = this.renderer.buffer,
                            s = t.program;
                        s.glPrograms[n] || this.renderer.shader.generateProgram(t), this.checkCompatibility(e, s);
                        var a = this.getSignature(e, s),
                            u = e.glVertexArrayObjects[this.CONTEXT_UID],
                            h = u[a];
                        if (h) return u[s.id] = h, h;
                        var l = e.buffers,
                            d = e.attributes,
                            f = {},
                            c = {};
                        for (var p in l) f[p] = 0, c[p] = 0;
                        for (var p in d) !d[p].size && s.attributeData[p] ? d[p].size = s.attributeData[p].size : d[p].size || console.warn("PIXI Geometry attribute '" + p + "' size cannot be determined (likely the bound shader does not have the attribute)"), f[d[p].buffer] += d[p].size * ae[d[p].type];
                        for (var p in d) {
                            var v = d[p],
                                m = v.size;
                            void 0 === v.stride && (f[v.buffer] === m * ae[v.type] ? v.stride = 0 : v.stride = f[v.buffer]), void 0 === v.start && (v.start = c[v.buffer], c[v.buffer] += m * ae[v.type])
                        }
                        h = i.createVertexArray(), i.bindVertexArray(h);
                        for (var g = 0; g < l.length; g++) {
                            var y = l[g];
                            o.bind(y), r && y._glBuffers[n].refCount++
                        }
                        return this.activateVao(e, s), this._activeVao = h, u[s.id] = h, u[a] = h, h
                    }, e.prototype.disposeGeometry = function(e, t) {
                        var r;
                        if (this.managedGeometries[e.id]) {
                            delete this.managedGeometries[e.id];
                            var i = e.glVertexArrayObjects[this.CONTEXT_UID],
                                n = this.gl,
                                o = e.buffers,
                                s = null === (r = this.renderer) || void 0 === r ? void 0 : r.buffer;
                            if (e.disposeRunner.remove(this), i) {
                                if (s)
                                    for (var a = 0; a < o.length; a++) {
                                        var u = o[a]._glBuffers[this.CONTEXT_UID];
                                        u && (u.refCount--, 0 !== u.refCount || t || s.dispose(o[a], t))
                                    }
                                if (!t)
                                    for (var h in i)
                                        if ("g" === h[0]) {
                                            var l = i[h];
                                            this._activeVao === l && this.unbind(), n.deleteVertexArray(l)
                                        }
                                delete e.glVertexArrayObjects[this.CONTEXT_UID]
                            }
                        }
                    }, e.prototype.disposeAll = function(e) {
                        for (var t = Object.keys(this.managedGeometries), r = 0; r < t.length; r++) this.disposeGeometry(this.managedGeometries[t[r]], e)
                    }, e.prototype.activateVao = function(e, t) {
                        var r = this.gl,
                            i = this.CONTEXT_UID,
                            n = this.renderer.buffer,
                            o = e.buffers,
                            s = e.attributes;
                        e.indexBuffer && n.bind(e.indexBuffer);
                        var a = null;
                        for (var u in s) {
                            var h = s[u],
                                l = o[h.buffer],
                                d = l._glBuffers[i];
                            if (t.attributeData[u]) {
                                a !== d && (n.bind(l), a = d);
                                var f = t.attributeData[u].location;
                                if (r.enableVertexAttribArray(f), r.vertexAttribPointer(f, h.size, h.type || r.FLOAT, h.normalized, h.stride, h.start), h.instance) {
                                    if (!this.hasInstance) throw new Error("geometry error, GPU Instancing is not supported on this device");
                                    r.vertexAttribDivisor(f, 1)
                                }
                            }
                        }
                    }, e.prototype.draw = function(e, t, r, i) {
                        var n = this.gl,
                            o = this._activeGeometry;
                        if (o.indexBuffer) {
                            var s = o.indexBuffer.data.BYTES_PER_ELEMENT,
                                a = 2 === s ? n.UNSIGNED_SHORT : n.UNSIGNED_INT;
                            2 === s || 4 === s && this.canUseUInt32ElementIndex ? o.instanced ? n.drawElementsInstanced(e, t || o.indexBuffer.data.length, a, (r || 0) * s, i || 1) : n.drawElements(e, t || o.indexBuffer.data.length, a, (r || 0) * s) : console.warn("unsupported index buffer type: uint32")
                        } else o.instanced ? n.drawArraysInstanced(e, r, t || o.getSize(), i || 1) : n.drawArrays(e, r, t || o.getSize());
                        return this
                    }, e.prototype.unbind = function() {
                        this.gl.bindVertexArray(null), this._activeVao = null, this._activeGeometry = null
                    }, e.prototype.destroy = function() {
                        this.renderer = null
                    }, e
                }(),
                he = function() {
                    function e(e) {
                        void 0 === e && (e = null), this.type = n.A7.NONE, this.autoDetect = !0, this.maskObject = e || null, this.pooled = !1, this.isMaskData = !0, this.resolution = null, this.multisample = i.Xd.FILTER_MULTISAMPLE, this.enabled = !0, this.colorMask = 15, this._filters = null, this._stencilCounter = 0, this._scissorCounter = 0, this._scissorRect = null, this._scissorRectLocal = null, this._colorMask = 15, this._target = null
                    }
                    return Object.defineProperty(e.prototype, "filter", {
                        get: function() {
                            return this._filters ? this._filters[0] : null
                        },
                        set: function(e) {
                            e ? this._filters ? this._filters[0] = e : this._filters = [e] : this._filters = null
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.reset = function() {
                        this.pooled && (this.maskObject = null, this.type = n.A7.NONE, this.autoDetect = !0), this._target = null, this._scissorRectLocal = null
                    }, e.prototype.copyCountersOrReset = function(e) {
                        e ? (this._stencilCounter = e._stencilCounter, this._scissorCounter = e._scissorCounter, this._scissorRect = e._scissorRect) : (this._stencilCounter = 0, this._scissorCounter = 0, this._scissorRect = null)
                    }, e
                }();

            function le(e, t, r) {
                var i = e.createShader(t);
                return e.shaderSource(i, r), e.compileShader(i), i
            }

            function de(e, t) {
                var r = e.getShaderSource(t).split("\n").map((function(e, t) {
                        return t + ": " + e
                    })),
                    i = e.getShaderInfoLog(t),
                    n = i.split("\n"),
                    o = {},
                    s = n.map((function(e) {
                        return parseFloat(e.replace(/^ERROR\: 0\:([\d]+)\:.*$/, "$1"))
                    })).filter((function(e) {
                        return !(!e || o[e]) && (o[e] = !0, !0)
                    })),
                    a = [""];
                s.forEach((function(e) {
                    r[e - 1] = "%c" + r[e - 1] + "%c", a.push("background: #FF0000; color:#FFFFFF; font-size: 10px", "font-size: 10px")
                }));
                var u = r.join("\n");
                a[0] = u, console.error(i), console.groupCollapsed("click to view full shader code"), console.warn.apply(console, a), console.groupEnd()
            }

            function fe(e) {
                for (var t = new Array(e), r = 0; r < t.length; r++) t[r] = !1;
                return t
            }

            function ce(e, t) {
                switch (e) {
                    case "float":
                    case "int":
                    case "uint":
                    case "sampler2D":
                    case "sampler2DArray":
                        return 0;
                    case "vec2":
                        return new Float32Array(2 * t);
                    case "vec3":
                        return new Float32Array(3 * t);
                    case "vec4":
                        return new Float32Array(4 * t);
                    case "ivec2":
                        return new Int32Array(2 * t);
                    case "ivec3":
                        return new Int32Array(3 * t);
                    case "ivec4":
                        return new Int32Array(4 * t);
                    case "uvec2":
                        return new Uint32Array(2 * t);
                    case "uvec3":
                        return new Uint32Array(3 * t);
                    case "uvec4":
                        return new Uint32Array(4 * t);
                    case "bool":
                        return !1;
                    case "bvec2":
                        return fe(2 * t);
                    case "bvec3":
                        return fe(3 * t);
                    case "bvec4":
                        return fe(4 * t);
                    case "mat2":
                        return new Float32Array([1, 0, 0, 1]);
                    case "mat3":
                        return new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]);
                    case "mat4":
                        return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1])
                }
                return null
            }
            var pe, ve = {},
                me = ve;

            function ge() {
                if (!pe) {
                    pe = n.cB.MEDIUM;
                    var e = function() {
                        if (me === ve || me && me.isContextLost()) {
                            var e = i.Xd.ADAPTER.createCanvas(),
                                t = void 0;
                            i.Xd.PREFER_ENV >= n.Vi.WEBGL2 && (t = e.getContext("webgl2", {})), t || ((t = e.getContext("webgl", {}) || e.getContext("experimental-webgl", {})) ? t.getExtension("WEBGL_draw_buffers") : t = null), me = t
                        }
                        return me
                    }();
                    if (e && e.getShaderPrecisionFormat) {
                        var t = e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_FLOAT);
                        pe = t.precision ? n.cB.HIGH : n.cB.MEDIUM
                    }
                }
                return pe
            }

            function ye(e, t, r) {
                if ("precision" !== e.substring(0, 9)) {
                    var i = t;
                    return t === n.cB.HIGH && r !== n.cB.HIGH && (i = n.cB.MEDIUM), "precision " + i + " float;\n" + e
                }
                return r !== n.cB.HIGH && "precision highp" === e.substring(0, 15) ? e.replace("precision highp", "precision mediump") : e
            }
            var _e = {
                float: 1,
                vec2: 2,
                vec3: 3,
                vec4: 4,
                int: 1,
                ivec2: 2,
                ivec3: 3,
                ivec4: 4,
                uint: 1,
                uvec2: 2,
                uvec3: 3,
                uvec4: 4,
                bool: 1,
                bvec2: 2,
                bvec3: 3,
                bvec4: 4,
                mat2: 4,
                mat3: 9,
                mat4: 16,
                sampler2D: 1
            };

            function be(e) {
                return _e[e]
            }
            var xe = null,
                Te = {
                    FLOAT: "float",
                    FLOAT_VEC2: "vec2",
                    FLOAT_VEC3: "vec3",
                    FLOAT_VEC4: "vec4",
                    INT: "int",
                    INT_VEC2: "ivec2",
                    INT_VEC3: "ivec3",
                    INT_VEC4: "ivec4",
                    UNSIGNED_INT: "uint",
                    UNSIGNED_INT_VEC2: "uvec2",
                    UNSIGNED_INT_VEC3: "uvec3",
                    UNSIGNED_INT_VEC4: "uvec4",
                    BOOL: "bool",
                    BOOL_VEC2: "bvec2",
                    BOOL_VEC3: "bvec3",
                    BOOL_VEC4: "bvec4",
                    FLOAT_MAT2: "mat2",
                    FLOAT_MAT3: "mat3",
                    FLOAT_MAT4: "mat4",
                    SAMPLER_2D: "sampler2D",
                    INT_SAMPLER_2D: "sampler2D",
                    UNSIGNED_INT_SAMPLER_2D: "sampler2D",
                    SAMPLER_CUBE: "samplerCube",
                    INT_SAMPLER_CUBE: "samplerCube",
                    UNSIGNED_INT_SAMPLER_CUBE: "samplerCube",
                    SAMPLER_2D_ARRAY: "sampler2DArray",
                    INT_SAMPLER_2D_ARRAY: "sampler2DArray",
                    UNSIGNED_INT_SAMPLER_2D_ARRAY: "sampler2DArray"
                };

            function Ee(e, t) {
                if (!xe) {
                    var r = Object.keys(Te);
                    xe = {};
                    for (var i = 0; i < r.length; ++i) {
                        var n = r[i];
                        xe[e[n]] = Te[n]
                    }
                }
                return xe[t]
            }
            var Re = [{
                    test: function(e) {
                        return "float" === e.type && 1 === e.size && !e.isArray
                    },
                    code: function(e) {
                        return '\n            if(uv["' + e + '"] !== ud["' + e + '"].value)\n            {\n                ud["' + e + '"].value = uv["' + e + '"]\n                gl.uniform1f(ud["' + e + '"].location, uv["' + e + '"])\n            }\n            '
                    }
                }, {
                    test: function(e, t) {
                        return ("sampler2D" === e.type || "samplerCube" === e.type || "sampler2DArray" === e.type) && 1 === e.size && !e.isArray && (null == t || void 0 !== t.castToBaseTexture)
                    },
                    code: function(e) {
                        return 't = syncData.textureCount++;\n\n            renderer.texture.bind(uv["' + e + '"], t);\n\n            if(ud["' + e + '"].value !== t)\n            {\n                ud["' + e + '"].value = t;\n                gl.uniform1i(ud["' + e + '"].location, t);\n; // eslint-disable-line max-len\n            }'
                    }
                }, {
                    test: function(e, t) {
                        return "mat3" === e.type && 1 === e.size && !e.isArray && void 0 !== t.a
                    },
                    code: function(e) {
                        return '\n            gl.uniformMatrix3fv(ud["' + e + '"].location, false, uv["' + e + '"].toArray(true));\n            '
                    },
                    codeUbo: function(e) {
                        return "\n                var " + e + "_matrix = uv." + e + ".toArray(true);\n\n                data[offset] = " + e + "_matrix[0];\n                data[offset+1] = " + e + "_matrix[1];\n                data[offset+2] = " + e + "_matrix[2];\n        \n                data[offset + 4] = " + e + "_matrix[3];\n                data[offset + 5] = " + e + "_matrix[4];\n                data[offset + 6] = " + e + "_matrix[5];\n        \n                data[offset + 8] = " + e + "_matrix[6];\n                data[offset + 9] = " + e + "_matrix[7];\n                data[offset + 10] = " + e + "_matrix[8];\n            "
                    }
                }, {
                    test: function(e, t) {
                        return "vec2" === e.type && 1 === e.size && !e.isArray && void 0 !== t.x
                    },
                    code: function(e) {
                        return '\n                cv = ud["' + e + '"].value;\n                v = uv["' + e + '"];\n\n                if(cv[0] !== v.x || cv[1] !== v.y)\n                {\n                    cv[0] = v.x;\n                    cv[1] = v.y;\n                    gl.uniform2f(ud["' + e + '"].location, v.x, v.y);\n                }'
                    },
                    codeUbo: function(e) {
                        return "\n                v = uv." + e + ";\n\n                data[offset] = v.x;\n                data[offset+1] = v.y;\n            "
                    }
                }, {
                    test: function(e) {
                        return "vec2" === e.type && 1 === e.size && !e.isArray
                    },
                    code: function(e) {
                        return '\n                cv = ud["' + e + '"].value;\n                v = uv["' + e + '"];\n\n                if(cv[0] !== v[0] || cv[1] !== v[1])\n                {\n                    cv[0] = v[0];\n                    cv[1] = v[1];\n                    gl.uniform2f(ud["' + e + '"].location, v[0], v[1]);\n                }\n            '
                    }
                }, {
                    test: function(e, t) {
                        return "vec4" === e.type && 1 === e.size && !e.isArray && void 0 !== t.width
                    },
                    code: function(e) {
                        return '\n                cv = ud["' + e + '"].value;\n                v = uv["' + e + '"];\n\n                if(cv[0] !== v.x || cv[1] !== v.y || cv[2] !== v.width || cv[3] !== v.height)\n                {\n                    cv[0] = v.x;\n                    cv[1] = v.y;\n                    cv[2] = v.width;\n                    cv[3] = v.height;\n                    gl.uniform4f(ud["' + e + '"].location, v.x, v.y, v.width, v.height)\n                }'
                    },
                    codeUbo: function(e) {
                        return "\n                    v = uv." + e + ";\n\n                    data[offset] = v.x;\n                    data[offset+1] = v.y;\n                    data[offset+2] = v.width;\n                    data[offset+3] = v.height;\n                "
                    }
                }, {
                    test: function(e) {
                        return "vec4" === e.type && 1 === e.size && !e.isArray
                    },
                    code: function(e) {
                        return '\n                cv = ud["' + e + '"].value;\n                v = uv["' + e + '"];\n\n                if(cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])\n                {\n                    cv[0] = v[0];\n                    cv[1] = v[1];\n                    cv[2] = v[2];\n                    cv[3] = v[3];\n\n                    gl.uniform4f(ud["' + e + '"].location, v[0], v[1], v[2], v[3])\n                }'
                    }
                }],
                Ie = {
                    float: "\n    if (cv !== v)\n    {\n        cu.value = v;\n        gl.uniform1f(location, v);\n    }",
                    vec2: "\n    if (cv[0] !== v[0] || cv[1] !== v[1])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n\n        gl.uniform2f(location, v[0], v[1])\n    }",
                    vec3: "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n\n        gl.uniform3f(location, v[0], v[1], v[2])\n    }",
                    vec4: "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n        cv[3] = v[3];\n\n        gl.uniform4f(location, v[0], v[1], v[2], v[3]);\n    }",
                    int: "\n    if (cv !== v)\n    {\n        cu.value = v;\n\n        gl.uniform1i(location, v);\n    }",
                    ivec2: "\n    if (cv[0] !== v[0] || cv[1] !== v[1])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n\n        gl.uniform2i(location, v[0], v[1]);\n    }",
                    ivec3: "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n\n        gl.uniform3i(location, v[0], v[1], v[2]);\n    }",
                    ivec4: "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n        cv[3] = v[3];\n\n        gl.uniform4i(location, v[0], v[1], v[2], v[3]);\n    }",
                    uint: "\n    if (cv !== v)\n    {\n        cu.value = v;\n\n        gl.uniform1ui(location, v);\n    }",
                    uvec2: "\n    if (cv[0] !== v[0] || cv[1] !== v[1])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n\n        gl.uniform2ui(location, v[0], v[1]);\n    }",
                    uvec3: "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n\n        gl.uniform3ui(location, v[0], v[1], v[2]);\n    }",
                    uvec4: "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n        cv[3] = v[3];\n\n        gl.uniform4ui(location, v[0], v[1], v[2], v[3]);\n    }",
                    bool: "\n    if (cv !== v)\n    {\n        cu.value = v;\n        gl.uniform1i(location, v);\n    }",
                    bvec2: "\n    if (cv[0] != v[0] || cv[1] != v[1])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n\n        gl.uniform2i(location, v[0], v[1]);\n    }",
                    bvec3: "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n\n        gl.uniform3i(location, v[0], v[1], v[2]);\n    }",
                    bvec4: "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n        cv[3] = v[3];\n\n        gl.uniform4i(location, v[0], v[1], v[2], v[3]);\n    }",
                    mat2: "gl.uniformMatrix2fv(location, false, v)",
                    mat3: "gl.uniformMatrix3fv(location, false, v)",
                    mat4: "gl.uniformMatrix4fv(location, false, v)",
                    sampler2D: "\n    if (cv !== v)\n    {\n        cu.value = v;\n\n        gl.uniform1i(location, v);\n    }",
                    samplerCube: "\n    if (cv !== v)\n    {\n        cu.value = v;\n\n        gl.uniform1i(location, v);\n    }",
                    sampler2DArray: "\n    if (cv !== v)\n    {\n        cu.value = v;\n\n        gl.uniform1i(location, v);\n    }"
                },
                Ae = {
                    float: "gl.uniform1fv(location, v)",
                    vec2: "gl.uniform2fv(location, v)",
                    vec3: "gl.uniform3fv(location, v)",
                    vec4: "gl.uniform4fv(location, v)",
                    mat4: "gl.uniformMatrix4fv(location, false, v)",
                    mat3: "gl.uniformMatrix3fv(location, false, v)",
                    mat2: "gl.uniformMatrix2fv(location, false, v)",
                    int: "gl.uniform1iv(location, v)",
                    ivec2: "gl.uniform2iv(location, v)",
                    ivec3: "gl.uniform3iv(location, v)",
                    ivec4: "gl.uniform4iv(location, v)",
                    uint: "gl.uniform1uiv(location, v)",
                    uvec2: "gl.uniform2uiv(location, v)",
                    uvec3: "gl.uniform3uiv(location, v)",
                    uvec4: "gl.uniform4uiv(location, v)",
                    bool: "gl.uniform1iv(location, v)",
                    bvec2: "gl.uniform2iv(location, v)",
                    bvec3: "gl.uniform3iv(location, v)",
                    bvec4: "gl.uniform4iv(location, v)",
                    sampler2D: "gl.uniform1iv(location, v)",
                    samplerCube: "gl.uniform1iv(location, v)",
                    sampler2DArray: "gl.uniform1iv(location, v)"
                };
            var we, Se = ["precision mediump float;", "void main(void){", "float test = 0.1;", "%forloop%", "gl_FragColor = vec4(0.0);", "}"].join("\n");

            function Ce(e) {
                for (var t = "", r = 0; r < e; ++r) r > 0 && (t += "\nelse "), r < e - 1 && (t += "if(test == " + r + ".0){}");
                return t
            }
            var Fe = 0,
                Ne = {},
                Oe = function() {
                    function e(t, r, o) {
                        void 0 === o && (o = "pixi-shader"), this.id = Fe++, this.vertexSrc = t || e.defaultVertexSrc, this.fragmentSrc = r || e.defaultFragmentSrc, this.vertexSrc = this.vertexSrc.trim(), this.fragmentSrc = this.fragmentSrc.trim(), "#version" !== this.vertexSrc.substring(0, 8) && (o = o.replace(/\s+/g, "-"), Ne[o] ? (Ne[o]++, o += "-" + Ne[o]) : Ne[o] = 1, this.vertexSrc = "#define SHADER_NAME " + o + "\n" + this.vertexSrc, this.fragmentSrc = "#define SHADER_NAME " + o + "\n" + this.fragmentSrc, this.vertexSrc = ye(this.vertexSrc, i.Xd.PRECISION_VERTEX, n.cB.HIGH), this.fragmentSrc = ye(this.fragmentSrc, i.Xd.PRECISION_FRAGMENT, ge())), this.glPrograms = {}, this.syncUniforms = null
                    }
                    return Object.defineProperty(e, "defaultVertexSrc", {
                        get: function() {
                            return "attribute vec2 aVertexPosition;\nattribute vec2 aTextureCoord;\n\nuniform mat3 projectionMatrix;\n\nvarying vec2 vTextureCoord;\n\nvoid main(void){\n   gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\n   vTextureCoord = aTextureCoord;\n}\n"
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e, "defaultFragmentSrc", {
                        get: function() {
                            return "varying vec2 vTextureCoord;\n\nuniform sampler2D uSampler;\n\nvoid main(void){\n   gl_FragColor *= texture2D(uSampler, vTextureCoord);\n}"
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.from = function(t, r, i) {
                        var n = t + r,
                            s = o.GG[n];
                        return s || (o.GG[n] = s = new e(t, r, i)), s
                    }, e
                }(),
                Me = function() {
                    function e(e, t) {
                        this.uniformBindCount = 0, this.program = e, this.uniformGroup = t ? t instanceof $ ? t : new $(t) : new $({}), this.disposeRunner = new a.R("disposeShader")
                    }
                    return e.prototype.checkUniformExists = function(e, t) {
                        if (t.uniforms[e]) return !0;
                        for (var r in t.uniforms) {
                            var i = t.uniforms[r];
                            if (i.group && this.checkUniformExists(e, i)) return !0
                        }
                        return !1
                    }, e.prototype.destroy = function() {
                        this.uniformGroup = null, this.disposeRunner.emit(this), this.disposeRunner.destroy()
                    }, Object.defineProperty(e.prototype, "uniforms", {
                        get: function() {
                            return this.uniformGroup.uniforms
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.from = function(t, r, i) {
                        return new e(Oe.from(t, r), i)
                    }, e
                }(),
                Be = function() {
                    function e() {
                        this.data = 0, this.blendMode = n.T$.NORMAL, this.polygonOffset = 0, this.blend = !0, this.depthMask = !0
                    }
                    return Object.defineProperty(e.prototype, "blend", {
                        get: function() {
                            return !!(1 & this.data)
                        },
                        set: function(e) {
                            !!(1 & this.data) !== e && (this.data ^= 1)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "offsets", {
                        get: function() {
                            return !!(2 & this.data)
                        },
                        set: function(e) {
                            !!(2 & this.data) !== e && (this.data ^= 2)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "culling", {
                        get: function() {
                            return !!(4 & this.data)
                        },
                        set: function(e) {
                            !!(4 & this.data) !== e && (this.data ^= 4)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "depthTest", {
                        get: function() {
                            return !!(8 & this.data)
                        },
                        set: function(e) {
                            !!(8 & this.data) !== e && (this.data ^= 8)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "depthMask", {
                        get: function() {
                            return !!(32 & this.data)
                        },
                        set: function(e) {
                            !!(32 & this.data) !== e && (this.data ^= 32)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "clockwiseFrontFace", {
                        get: function() {
                            return !!(16 & this.data)
                        },
                        set: function(e) {
                            !!(16 & this.data) !== e && (this.data ^= 16)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "blendMode", {
                        get: function() {
                            return this._blendMode
                        },
                        set: function(e) {
                            this.blend = e !== n.T$.NONE, this._blendMode = e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "polygonOffset", {
                        get: function() {
                            return this._polygonOffset
                        },
                        set: function(e) {
                            this.offsets = !!e, this._polygonOffset = e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.toString = function() {
                        return "[@pixi/core:State blendMode=" + this.blendMode + " clockwiseFrontFace=" + this.clockwiseFrontFace + " culling=" + this.culling + " depthMask=" + this.depthMask + " polygonOffset=" + this.polygonOffset + "]"
                    }, e.for2d = function() {
                        var t = new e;
                        return t.depthTest = !1, t.blend = !0, t
                    }, e
                }(),
                Pe = function(e) {
                    function t(r, n, o) {
                        var s = this,
                            a = Oe.from(r || t.defaultVertexSrc, n || t.defaultFragmentSrc);
                        return (s = e.call(this, a, o) || this).padding = 0, s.resolution = i.Xd.FILTER_RESOLUTION, s.multisample = i.Xd.FILTER_MULTISAMPLE, s.enabled = !0, s.autoFit = !0, s.state = new Be, s
                    }
                    return c(t, e), t.prototype.apply = function(e, t, r, i, n) {
                        e.applyFilter(this, t, r, i)
                    }, Object.defineProperty(t.prototype, "blendMode", {
                        get: function() {
                            return this.state.blendMode
                        },
                        set: function(e) {
                            this.state.blendMode = e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "resolution", {
                        get: function() {
                            return this._resolution
                        },
                        set: function(e) {
                            this._resolution = e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t, "defaultVertexSrc", {
                        get: function() {
                            return "attribute vec2 aVertexPosition;\n\nuniform mat3 projectionMatrix;\n\nvarying vec2 vTextureCoord;\n\nuniform vec4 inputSize;\nuniform vec4 outputFrame;\n\nvec4 filterVertexPosition( void )\n{\n    vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;\n\n    return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord( void )\n{\n    return aVertexPosition * (outputFrame.zw * inputSize.zw);\n}\n\nvoid main(void)\n{\n    gl_Position = filterVertexPosition();\n    vTextureCoord = filterTextureCoord();\n}\n"
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t, "defaultFragmentSrc", {
                        get: function() {
                            return "varying vec2 vTextureCoord;\n\nuniform sampler2D uSampler;\n\nvoid main(void){\n   gl_FragColor = texture2D(uSampler, vTextureCoord);\n}\n"
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t
                }(Me),
                Ue = new h.y3,
                Le = function() {
                    function e(e, t) {
                        this._texture = e, this.mapCoord = new h.y3, this.uClampFrame = new Float32Array(4), this.uClampOffset = new Float32Array(2), this._textureID = -1, this._updateID = 0, this.clampOffset = 0, this.clampMargin = "undefined" === typeof t ? .5 : t, this.isSimple = !1
                    }
                    return Object.defineProperty(e.prototype, "texture", {
                        get: function() {
                            return this._texture
                        },
                        set: function(e) {
                            this._texture = e, this._textureID = -1
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.multiplyUvs = function(e, t) {
                        void 0 === t && (t = e);
                        for (var r = this.mapCoord, i = 0; i < e.length; i += 2) {
                            var n = e[i],
                                o = e[i + 1];
                            t[i] = n * r.a + o * r.c + r.tx, t[i + 1] = n * r.b + o * r.d + r.ty
                        }
                        return t
                    }, e.prototype.update = function(e) {
                        var t = this._texture;
                        if (!t || !t.valid) return !1;
                        if (!e && this._textureID === t._updateID) return !1;
                        this._textureID = t._updateID, this._updateID++;
                        var r = t._uvs;
                        this.mapCoord.set(r.x1 - r.x0, r.y1 - r.y0, r.x3 - r.x0, r.y3 - r.y0, r.x0, r.y0);
                        var i = t.orig,
                            n = t.trim;
                        n && (Ue.set(i.width / n.width, 0, 0, i.height / n.height, -n.x / n.width, -n.y / n.height), this.mapCoord.append(Ue));
                        var o = t.baseTexture,
                            s = this.uClampFrame,
                            a = this.clampMargin / o.resolution,
                            u = this.clampOffset;
                        return s[0] = (t._frame.x + a + u) / o.width, s[1] = (t._frame.y + a + u) / o.height, s[2] = (t._frame.x + t._frame.width - a + u) / o.width, s[3] = (t._frame.y + t._frame.height - a + u) / o.height, this.uClampOffset[0] = u / o.realWidth, this.uClampOffset[1] = u / o.realHeight, this.isSimple = t._frame.width === o.width && t._frame.height === o.height && 0 === t.rotate, !0
                    }, e
                }(),
                De = function(e) {
                    function t(t, r, i) {
                        var n = this,
                            o = null;
                        return "string" !== typeof t && void 0 === r && void 0 === i && (o = t, t = void 0, r = void 0, i = void 0), (n = e.call(this, t || "attribute vec2 aVertexPosition;\nattribute vec2 aTextureCoord;\n\nuniform mat3 projectionMatrix;\nuniform mat3 otherMatrix;\n\nvarying vec2 vMaskCoord;\nvarying vec2 vTextureCoord;\n\nvoid main(void)\n{\n    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\n\n    vTextureCoord = aTextureCoord;\n    vMaskCoord = ( otherMatrix * vec3( aTextureCoord, 1.0)  ).xy;\n}\n", r || "varying vec2 vMaskCoord;\nvarying vec2 vTextureCoord;\n\nuniform sampler2D uSampler;\nuniform sampler2D mask;\nuniform float alpha;\nuniform float npmAlpha;\nuniform vec4 maskClamp;\n\nvoid main(void)\n{\n    float clip = step(3.5,\n        step(maskClamp.x, vMaskCoord.x) +\n        step(maskClamp.y, vMaskCoord.y) +\n        step(vMaskCoord.x, maskClamp.z) +\n        step(vMaskCoord.y, maskClamp.w));\n\n    vec4 original = texture2D(uSampler, vTextureCoord);\n    vec4 masky = texture2D(mask, vMaskCoord);\n    float alphaMul = 1.0 - npmAlpha * (1.0 - masky.a);\n\n    original *= (alphaMul * masky.r * alpha * clip);\n\n    gl_FragColor = original;\n}\n", i) || this).maskSprite = o, n.maskMatrix = new h.y3, n
                    }
                    return c(t, e), Object.defineProperty(t.prototype, "maskSprite", {
                        get: function() {
                            return this._maskSprite
                        },
                        set: function(e) {
                            this._maskSprite = e, this._maskSprite && (this._maskSprite.renderable = !1)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t.prototype.apply = function(e, t, r, i) {
                        var n = this._maskSprite,
                            o = n._texture;
                        o.valid && (o.uvMatrix || (o.uvMatrix = new Le(o, 0)), o.uvMatrix.update(), this.uniforms.npmAlpha = o.baseTexture.alphaMode ? 0 : 1, this.uniforms.mask = o, this.uniforms.otherMatrix = e.calculateSpriteMatrix(this.maskMatrix, n).prepend(o.uvMatrix.mapCoord), this.uniforms.alpha = n.worldAlpha, this.uniforms.maskClamp = o.uvMatrix.uClampFrame, e.applyFilter(this, t, r, i))
                    }, t
                }(Pe),
                Ge = function() {
                    function e(e) {
                        this.renderer = e, this.enableScissor = !0, this.alphaMaskPool = [], this.maskDataPool = [], this.maskStack = [], this.alphaMaskIndex = 0
                    }
                    return e.prototype.setMaskStack = function(e) {
                        this.maskStack = e, this.renderer.scissor.setMaskStack(e), this.renderer.stencil.setMaskStack(e)
                    }, e.prototype.push = function(e, t) {
                        var r = t;
                        if (!r.isMaskData) {
                            var i = this.maskDataPool.pop() || new he;
                            i.pooled = !0, i.maskObject = t, r = i
                        }
                        var o = 0 !== this.maskStack.length ? this.maskStack[this.maskStack.length - 1] : null;
                        if (r.copyCountersOrReset(o), r._colorMask = o ? o._colorMask : 15, r.autoDetect && this.detect(r), r._target = e, r.type !== n.A7.SPRITE && this.maskStack.push(r), r.enabled) switch (r.type) {
                            case n.A7.SCISSOR:
                                this.renderer.scissor.push(r);
                                break;
                            case n.A7.STENCIL:
                                this.renderer.stencil.push(r);
                                break;
                            case n.A7.SPRITE:
                                r.copyCountersOrReset(null), this.pushSpriteMask(r);
                                break;
                            case n.A7.COLOR:
                                this.pushColorMask(r)
                        }
                        r.type === n.A7.SPRITE && this.maskStack.push(r)
                    }, e.prototype.pop = function(e) {
                        var t = this.maskStack.pop();
                        if (t && t._target === e) {
                            if (t.enabled) switch (t.type) {
                                case n.A7.SCISSOR:
                                    this.renderer.scissor.pop(t);
                                    break;
                                case n.A7.STENCIL:
                                    this.renderer.stencil.pop(t.maskObject);
                                    break;
                                case n.A7.SPRITE:
                                    this.popSpriteMask(t);
                                    break;
                                case n.A7.COLOR:
                                    this.popColorMask(t)
                            }
                            if (t.reset(), t.pooled && this.maskDataPool.push(t), 0 !== this.maskStack.length) {
                                var r = this.maskStack[this.maskStack.length - 1];
                                r.type === n.A7.SPRITE && r._filters && (r._filters[0].maskSprite = r.maskObject)
                            }
                        }
                    }, e.prototype.detect = function(e) {
                        var t = e.maskObject;
                        t ? t.isSprite ? e.type = n.A7.SPRITE : this.enableScissor && this.renderer.scissor.testScissor(e) ? e.type = n.A7.SCISSOR : e.type = n.A7.STENCIL : e.type = n.A7.COLOR
                    }, e.prototype.pushSpriteMask = function(e) {
                        var t, r, i = e.maskObject,
                            n = e._target,
                            o = e._filters;
                        o || (o = this.alphaMaskPool[this.alphaMaskIndex]) || (o = this.alphaMaskPool[this.alphaMaskIndex] = [new De]);
                        var s, a, u = this.renderer,
                            h = u.renderTexture;
                        if (h.current) {
                            var l = h.current;
                            s = e.resolution || l.resolution, a = null !== (t = e.multisample) && void 0 !== t ? t : l.multisample
                        } else s = e.resolution || u.resolution, a = null !== (r = e.multisample) && void 0 !== r ? r : u.multisample;
                        o[0].resolution = s, o[0].multisample = a, o[0].maskSprite = i;
                        var d = n.filterArea;
                        n.filterArea = i.getBounds(!0), u.filter.push(n, o), n.filterArea = d, e._filters || this.alphaMaskIndex++
                    }, e.prototype.popSpriteMask = function(e) {
                        this.renderer.filter.pop(), e._filters ? e._filters[0].maskSprite = null : (this.alphaMaskIndex--, this.alphaMaskPool[this.alphaMaskIndex][0].maskSprite = null)
                    }, e.prototype.pushColorMask = function(e) {
                        var t = e._colorMask,
                            r = e._colorMask = t & e.colorMask;
                        r !== t && this.renderer.gl.colorMask(0 !== (1 & r), 0 !== (2 & r), 0 !== (4 & r), 0 !== (8 & r))
                    }, e.prototype.popColorMask = function(e) {
                        var t = e._colorMask,
                            r = this.maskStack.length > 0 ? this.maskStack[this.maskStack.length - 1]._colorMask : 15;
                        r !== t && this.renderer.gl.colorMask(0 !== (1 & r), 0 !== (2 & r), 0 !== (4 & r), 0 !== (8 & r))
                    }, e.prototype.destroy = function() {
                        this.renderer = null
                    }, e
                }(),
                ke = function() {
                    function e(e) {
                        this.renderer = e, this.maskStack = [], this.glConst = 0
                    }
                    return e.prototype.getStackLength = function() {
                        return this.maskStack.length
                    }, e.prototype.setMaskStack = function(e) {
                        var t = this.renderer.gl,
                            r = this.getStackLength();
                        this.maskStack = e;
                        var i = this.getStackLength();
                        i !== r && (0 === i ? t.disable(this.glConst) : (t.enable(this.glConst), this._useCurrent()))
                    }, e.prototype._useCurrent = function() {}, e.prototype.destroy = function() {
                        this.renderer = null, this.maskStack = null
                    }, e
                }(),
                Ve = new h.y3,
                Xe = [],
                He = function(e) {
                    function t(t) {
                        var r = e.call(this, t) || this;
                        return r.glConst = i.Xd.ADAPTER.getWebGLRenderingContext().SCISSOR_TEST, r
                    }
                    return c(t, e), t.prototype.getStackLength = function() {
                        var e = this.maskStack[this.maskStack.length - 1];
                        return e ? e._scissorCounter : 0
                    }, t.prototype.calcScissorRect = function(e) {
                        var t;
                        if (!e._scissorRectLocal) {
                            var r = e._scissorRect,
                                i = e.maskObject,
                                n = this.renderer,
                                o = n.renderTexture,
                                s = i.getBounds(!0, null !== (t = Xe.pop()) && void 0 !== t ? t : new h.Ae);
                            this.roundFrameToPixels(s, o.current ? o.current.resolution : n.resolution, o.sourceFrame, o.destinationFrame, n.projection.transform), r && s.fit(r), e._scissorRectLocal = s
                        }
                    }, t.isMatrixRotated = function(e) {
                        if (!e) return !1;
                        var t = e.a,
                            r = e.b,
                            i = e.c,
                            n = e.d;
                        return (Math.abs(r) > 1e-4 || Math.abs(i) > 1e-4) && (Math.abs(t) > 1e-4 || Math.abs(n) > 1e-4)
                    }, t.prototype.testScissor = function(e) {
                        var r = e.maskObject;
                        if (!r.isFastRect || !r.isFastRect()) return !1;
                        if (t.isMatrixRotated(r.worldTransform)) return !1;
                        if (t.isMatrixRotated(this.renderer.projection.transform)) return !1;
                        this.calcScissorRect(e);
                        var i = e._scissorRectLocal;
                        return i.width > 0 && i.height > 0
                    }, t.prototype.roundFrameToPixels = function(e, r, i, n, o) {
                        t.isMatrixRotated(o) || ((o = o ? Ve.copyFrom(o) : Ve.identity()).translate(-i.x, -i.y).scale(n.width / i.width, n.height / i.height).translate(n.x, n.y), this.renderer.filter.transformAABB(o, e), e.fit(n), e.x = Math.round(e.x * r), e.y = Math.round(e.y * r), e.width = Math.round(e.width * r), e.height = Math.round(e.height * r))
                    }, t.prototype.push = function(e) {
                        e._scissorRectLocal || this.calcScissorRect(e);
                        var t = this.renderer.gl;
                        e._scissorRect || t.enable(t.SCISSOR_TEST), e._scissorCounter++, e._scissorRect = e._scissorRectLocal, this._useCurrent()
                    }, t.prototype.pop = function(e) {
                        var t = this.renderer.gl;
                        e && Xe.push(e._scissorRectLocal), this.getStackLength() > 0 ? this._useCurrent() : t.disable(t.SCISSOR_TEST)
                    }, t.prototype._useCurrent = function() {
                        var e, t = this.maskStack[this.maskStack.length - 1]._scissorRect;
                        e = this.renderer.renderTexture.current ? t.y : this.renderer.height - t.height - t.y, this.renderer.gl.scissor(t.x, e, t.width, t.height)
                    }, t
                }(ke),
                je = function(e) {
                    function t(t) {
                        var r = e.call(this, t) || this;
                        return r.glConst = i.Xd.ADAPTER.getWebGLRenderingContext().STENCIL_TEST, r
                    }
                    return c(t, e), t.prototype.getStackLength = function() {
                        var e = this.maskStack[this.maskStack.length - 1];
                        return e ? e._stencilCounter : 0
                    }, t.prototype.push = function(e) {
                        var t = e.maskObject,
                            r = this.renderer.gl,
                            i = e._stencilCounter;
                        0 === i && (this.renderer.framebuffer.forceStencil(), r.clearStencil(0), r.clear(r.STENCIL_BUFFER_BIT), r.enable(r.STENCIL_TEST)), e._stencilCounter++;
                        var n = e._colorMask;
                        0 !== n && (e._colorMask = 0, r.colorMask(!1, !1, !1, !1)), r.stencilFunc(r.EQUAL, i, 4294967295), r.stencilOp(r.KEEP, r.KEEP, r.INCR), t.renderable = !0, t.render(this.renderer), this.renderer.batch.flush(), t.renderable = !1, 0 !== n && (e._colorMask = n, r.colorMask(0 !== (1 & n), 0 !== (2 & n), 0 !== (4 & n), 0 !== (8 & n))), this._useCurrent()
                    }, t.prototype.pop = function(e) {
                        var t = this.renderer.gl;
                        if (0 === this.getStackLength()) t.disable(t.STENCIL_TEST);
                        else {
                            var r = 0 !== this.maskStack.length ? this.maskStack[this.maskStack.length - 1] : null,
                                i = r ? r._colorMask : 15;
                            0 !== i && (r._colorMask = 0, t.colorMask(!1, !1, !1, !1)), t.stencilOp(t.KEEP, t.KEEP, t.DECR), e.renderable = !0, e.render(this.renderer), this.renderer.batch.flush(), e.renderable = !1, 0 !== i && (r._colorMask = i, t.colorMask(0 !== (1 & i), 0 !== (2 & i), 0 !== (4 & i), 0 !== (8 & i))), this._useCurrent()
                        }
                    }, t.prototype._useCurrent = function() {
                        var e = this.renderer.gl;
                        e.stencilFunc(e.EQUAL, this.getStackLength(), 4294967295), e.stencilOp(e.KEEP, e.KEEP, e.KEEP)
                    }, t
                }(ke),
                ze = function() {
                    function e(e) {
                        this.renderer = e, this.destinationFrame = null, this.sourceFrame = null, this.defaultFrame = null, this.projectionMatrix = new h.y3, this.transform = null
                    }
                    return e.prototype.update = function(e, t, r, i) {
                        this.destinationFrame = e || this.destinationFrame || this.defaultFrame, this.sourceFrame = t || this.sourceFrame || e, this.calculateProjection(this.destinationFrame, this.sourceFrame, r, i), this.transform && this.projectionMatrix.append(this.transform);
                        var n = this.renderer;
                        n.globalUniforms.uniforms.projectionMatrix = this.projectionMatrix, n.globalUniforms.update(), n.shader.shader && n.shader.syncUniformGroup(n.shader.shader.uniforms.globals)
                    }, e.prototype.calculateProjection = function(e, t, r, i) {
                        var n = this.projectionMatrix,
                            o = i ? -1 : 1;
                        n.identity(), n.a = 1 / t.width * 2, n.d = o * (1 / t.height * 2), n.tx = -1 - t.x * n.a, n.ty = -o - t.y * n.d
                    }, e.prototype.setTransform = function(e) {}, e.prototype.destroy = function() {
                        this.renderer = null
                    }, e
                }(),
                We = new h.Ae,
                Ke = new h.Ae,
                Ye = function() {
                    function e(e) {
                        this.renderer = e, this.clearColor = e._backgroundColorRgba, this.defaultMaskStack = [], this.current = null, this.sourceFrame = new h.Ae, this.destinationFrame = new h.Ae, this.viewportFrame = new h.Ae
                    }
                    return e.prototype.bind = function(e, t, r) {
                        void 0 === e && (e = null);
                        var i, n, o, s = this.renderer;
                        this.current = e, e ? (o = (i = e.baseTexture).resolution, t || (We.width = e.frame.width, We.height = e.frame.height, t = We), r || (Ke.x = e.frame.x, Ke.y = e.frame.y, Ke.width = t.width, Ke.height = t.height, r = Ke), n = i.framebuffer) : (o = s.resolution, t || (We.width = s.screen.width, We.height = s.screen.height, t = We), r || ((r = We).width = t.width, r.height = t.height));
                        var a = this.viewportFrame;
                        a.x = r.x * o, a.y = r.y * o, a.width = r.width * o, a.height = r.height * o, e || (a.y = s.view.height - (a.y + a.height)), a.ceil(), this.renderer.framebuffer.bind(n, a), this.renderer.projection.update(r, t, o, !n), e ? this.renderer.mask.setMaskStack(i.maskStack) : this.renderer.mask.setMaskStack(this.defaultMaskStack), this.sourceFrame.copyFrom(t), this.destinationFrame.copyFrom(r)
                    }, e.prototype.clear = function(e, t) {
                        e = this.current ? e || this.current.baseTexture.clearColor : e || this.clearColor;
                        var r = this.destinationFrame,
                            i = this.current ? this.current.baseTexture : this.renderer.screen,
                            n = r.width !== i.width || r.height !== i.height;
                        if (n) {
                            var o = this.viewportFrame,
                                s = o.x,
                                a = o.y,
                                u = o.width,
                                h = o.height;
                            s = Math.round(s), a = Math.round(a), u = Math.round(u), h = Math.round(h), this.renderer.gl.enable(this.renderer.gl.SCISSOR_TEST), this.renderer.gl.scissor(s, a, u, h)
                        }
                        this.renderer.framebuffer.clear(e[0], e[1], e[2], e[3], t), n && this.renderer.scissor.pop()
                    }, e.prototype.resize = function() {
                        this.bind(null)
                    }, e.prototype.reset = function() {
                        this.bind(null)
                    }, e.prototype.destroy = function() {
                        this.renderer = null
                    }, e
                }();

            function $e(e, t, r, i, n) {
                r.buffer.update(n)
            }
            var qe = {
                    float: "\n        data[offset] = v;\n    ",
                    vec2: "\n        data[offset] = v[0];\n        data[offset+1] = v[1];\n    ",
                    vec3: "\n        data[offset] = v[0];\n        data[offset+1] = v[1];\n        data[offset+2] = v[2];\n\n    ",
                    vec4: "\n        data[offset] = v[0];\n        data[offset+1] = v[1];\n        data[offset+2] = v[2];\n        data[offset+3] = v[3];\n    ",
                    mat2: "\n        data[offset] = v[0];\n        data[offset+1] = v[1];\n\n        data[offset+4] = v[2];\n        data[offset+5] = v[3];\n    ",
                    mat3: "\n        data[offset] = v[0];\n        data[offset+1] = v[1];\n        data[offset+2] = v[2];\n\n        data[offset + 4] = v[3];\n        data[offset + 5] = v[4];\n        data[offset + 6] = v[5];\n\n        data[offset + 8] = v[6];\n        data[offset + 9] = v[7];\n        data[offset + 10] = v[8];\n    ",
                    mat4: "\n        for(var i = 0; i < 16; i++)\n        {\n            data[offset + i] = v[i];\n        }\n    "
                },
                Ze = {
                    float: 4,
                    vec2: 8,
                    vec3: 12,
                    vec4: 16,
                    int: 4,
                    ivec2: 8,
                    ivec3: 12,
                    ivec4: 16,
                    uint: 4,
                    uvec2: 8,
                    uvec3: 12,
                    uvec4: 16,
                    bool: 4,
                    bvec2: 8,
                    bvec3: 12,
                    bvec4: 16,
                    mat2: 32,
                    mat3: 48,
                    mat4: 64
                };

            function Qe(e, t) {
                if (!e.autoManage) return {
                    size: 0,
                    syncFunc: $e
                };
                for (var r = function(e, t) {
                        var r = [];
                        for (var i in e) t[i] && r.push(t[i]);
                        return r.sort((function(e, t) {
                            return e.index - t.index
                        })), r
                    }(e.uniforms, t), i = function(e) {
                        for (var t = e.map((function(e) {
                                return {
                                    data: e,
                                    offset: 0,
                                    dataLen: 0,
                                    dirty: 0
                                }
                            })), r = 0, i = 0, n = 0, o = 0; o < t.length; o++) {
                            var s = t[o];
                            if (r = Ze[s.data.type], s.data.size > 1 && (r = Math.max(r, 16) * s.data.size), s.dataLen = r, i % r !== 0 && i < 16) {
                                var a = i % r % 16;
                                i += a, n += a
                            }
                            i + r > 16 ? (n = 16 * Math.ceil(n / 16), s.offset = n, n += r, i = r) : (s.offset = n, i += r, n += r)
                        }
                        return {
                            uboElements: t,
                            size: n = 16 * Math.ceil(n / 16)
                        }
                    }(r), n = i.uboElements, o = i.size, s = ["\n    var v = null;\n    var v2 = null;\n    var cv = null;\n    var t = 0;\n    var gl = renderer.gl\n    var index = 0;\n    var data = buffer.data;\n    "], a = 0; a < n.length; a++) {
                    for (var u = n[a], h = e.uniforms[u.data.name], l = u.data.name, d = !1, f = 0; f < Re.length; f++) {
                        var c = Re[f];
                        if (c.codeUbo && c.test(u.data, h)) {
                            s.push("offset = " + u.offset / 4 + ";", Re[f].codeUbo(u.data.name, h)), d = !0;
                            break
                        }
                    }
                    if (!d)
                        if (u.data.size > 1) {
                            var p = be(u.data.type),
                                v = Math.max(Ze[u.data.type] / 16, 1),
                                m = p / v,
                                g = (4 - m % 4) % 4;
                            s.push("\n                cv = ud." + l + ".value;\n                v = uv." + l + ";\n                offset = " + u.offset / 4 + ";\n\n                t = 0;\n\n                for(var i=0; i < " + u.data.size * v + "; i++)\n                {\n                    for(var j = 0; j < " + m + "; j++)\n                    {\n                        data[offset++] = v[t++];\n                    }\n                    offset += " + g + ";\n                }\n\n                ")
                        } else {
                            var y = qe[u.data.type];
                            s.push("\n                cv = ud." + l + ".value;\n                v = uv." + l + ";\n                offset = " + u.offset / 4 + ";\n                " + y + ";\n                ")
                        }
                }
                return s.push("\n       renderer.buffer.update(buffer);\n    "), {
                    size: o,
                    syncFunc: new Function("ud", "uv", "renderer", "syncData", "buffer", s.join("\n"))
                }
            }
            var Je = function() {
                function e(e, t) {
                    this.program = e, this.uniformData = t, this.uniformGroups = {}, this.uniformDirtyGroups = {}, this.uniformBufferBindings = {}
                }
                return e.prototype.destroy = function() {
                    this.uniformData = null, this.uniformGroups = null, this.uniformDirtyGroups = null, this.uniformBufferBindings = null, this.program = null
                }, e
            }();

            function et(e, t) {
                var r = le(e, e.VERTEX_SHADER, t.vertexSrc),
                    i = le(e, e.FRAGMENT_SHADER, t.fragmentSrc),
                    n = e.createProgram();
                if (e.attachShader(n, r), e.attachShader(n, i), e.linkProgram(n), e.getProgramParameter(n, e.LINK_STATUS) || function(e, t, r, i) {
                        e.getProgramParameter(t, e.LINK_STATUS) || (e.getShaderParameter(r, e.COMPILE_STATUS) || de(e, r), e.getShaderParameter(i, e.COMPILE_STATUS) || de(e, i), console.error("PixiJS Error: Could not initialize shader."), "" !== e.getProgramInfoLog(t) && console.warn("PixiJS Warning: gl.getProgramInfoLog()", e.getProgramInfoLog(t)))
                    }(e, n, r, i), t.attributeData = function(e, t) {
                        for (var r = {}, i = t.getProgramParameter(e, t.ACTIVE_ATTRIBUTES), n = 0; n < i; n++) {
                            var o = t.getActiveAttrib(e, n);
                            if (0 !== o.name.indexOf("gl_")) {
                                var s = Ee(t, o.type),
                                    a = {
                                        type: s,
                                        name: o.name,
                                        size: be(s),
                                        location: t.getAttribLocation(e, o.name)
                                    };
                                r[o.name] = a
                            }
                        }
                        return r
                    }(n, e), t.uniformData = function(e, t) {
                        for (var r = {}, i = t.getProgramParameter(e, t.ACTIVE_UNIFORMS), n = 0; n < i; n++) {
                            var o = t.getActiveUniform(e, n),
                                s = o.name.replace(/\[.*?\]$/, ""),
                                a = !!o.name.match(/\[.*?\]$/),
                                u = Ee(t, o.type);
                            r[s] = {
                                name: s,
                                index: n,
                                type: u,
                                size: o.size,
                                isArray: a,
                                value: ce(u, o.size)
                            }
                        }
                        return r
                    }(n, e), !/^[ \t]*#[ \t]*version[ \t]+300[ \t]+es[ \t]*$/m.test(t.vertexSrc)) {
                    var o = Object.keys(t.attributeData);
                    o.sort((function(e, t) {
                        return e > t ? 1 : -1
                    }));
                    for (var s = 0; s < o.length; s++) t.attributeData[o[s]].location = s, e.bindAttribLocation(n, s, o[s]);
                    e.linkProgram(n)
                }
                e.deleteShader(r), e.deleteShader(i);
                var a = {};
                for (var s in t.uniformData) {
                    var u = t.uniformData[s];
                    a[s] = {
                        location: e.getUniformLocation(n, s),
                        value: ce(u.type, u.size)
                    }
                }
                return new Je(n, a)
            }
            var tt = 0,
                rt = {
                    textureCount: 0,
                    uboCount: 0
                },
                it = function() {
                    function e(e) {
                        this.destroyed = !1, this.renderer = e, this.systemCheck(), this.gl = null, this.shader = null, this.program = null, this.cache = {}, this._uboCache = {}, this.id = tt++
                    }
                    return e.prototype.systemCheck = function() {
                        if (! function() {
                                if ("boolean" === typeof we) return we;
                                try {
                                    var e = new Function("param1", "param2", "param3", "return param1[param2] === param3;");
                                    we = !0 === e({
                                        a: "b"
                                    }, "a", "b")
                                } catch (t) {
                                    we = !1
                                }
                                return we
                            }()) throw new Error("Current environment does not allow unsafe-eval, please use @pixi/unsafe-eval module to enable support.")
                    }, e.prototype.contextChange = function(e) {
                        this.gl = e, this.reset()
                    }, e.prototype.bind = function(e, t) {
                        e.disposeRunner.add(this), e.uniforms.globals = this.renderer.globalUniforms;
                        var r = e.program,
                            i = r.glPrograms[this.renderer.CONTEXT_UID] || this.generateProgram(e);
                        return this.shader = e, this.program !== r && (this.program = r, this.gl.useProgram(i.program)), t || (rt.textureCount = 0, rt.uboCount = 0, this.syncUniformGroup(e.uniformGroup, rt)), i
                    }, e.prototype.setUniforms = function(e) {
                        var t = this.shader.program,
                            r = t.glPrograms[this.renderer.CONTEXT_UID];
                        t.syncUniforms(r.uniformData, e, this.renderer)
                    }, e.prototype.syncUniformGroup = function(e, t) {
                        var r = this.getGlProgram();
                        e.static && e.dirtyId === r.uniformDirtyGroups[e.id] || (r.uniformDirtyGroups[e.id] = e.dirtyId, this.syncUniforms(e, r, t))
                    }, e.prototype.syncUniforms = function(e, t, r) {
                        (e.syncUniforms[this.shader.program.id] || this.createSyncGroups(e))(t.uniformData, e.uniforms, this.renderer, r)
                    }, e.prototype.createSyncGroups = function(e) {
                        var t = this.getSignature(e, this.shader.program.uniformData, "u");
                        return this.cache[t] || (this.cache[t] = function(e, t) {
                            var r, i = ["\n        var v = null;\n        var cv = null;\n        var cu = null;\n        var t = 0;\n        var gl = renderer.gl;\n    "];
                            for (var n in e.uniforms) {
                                var o = t[n];
                                if (o) {
                                    for (var s = e.uniforms[n], a = !1, u = 0; u < Re.length; u++)
                                        if (Re[u].test(o, s)) {
                                            i.push(Re[u].code(n, s)), a = !0;
                                            break
                                        }
                                    if (!a) {
                                        var h = (1 !== o.size || o.isArray ? Ae : Ie)[o.type].replace("location", 'ud["' + n + '"].location');
                                        i.push('\n            cu = ud["' + n + '"];\n            cv = cu.value;\n            v = uv["' + n + '"];\n            ' + h + ";")
                                    }
                                } else(null === (r = e.uniforms[n]) || void 0 === r ? void 0 : r.group) && (e.uniforms[n].ubo ? i.push("\n                        renderer.shader.syncUniformBufferGroup(uv." + n + ", '" + n + "');\n                    ") : i.push("\n                        renderer.shader.syncUniformGroup(uv." + n + ", syncData);\n                    "))
                            }
                            return new Function("ud", "uv", "renderer", "syncData", i.join("\n"))
                        }(e, this.shader.program.uniformData)), e.syncUniforms[this.shader.program.id] = this.cache[t], e.syncUniforms[this.shader.program.id]
                    }, e.prototype.syncUniformBufferGroup = function(e, t) {
                        var r = this.getGlProgram();
                        if (!e.static || 0 !== e.dirtyId || !r.uniformGroups[e.id]) {
                            e.dirtyId = 0;
                            var i = r.uniformGroups[e.id] || this.createSyncBufferGroup(e, r, t);
                            e.buffer.update(), i(r.uniformData, e.uniforms, this.renderer, rt, e.buffer)
                        }
                        this.renderer.buffer.bindBufferBase(e.buffer, r.uniformBufferBindings[t])
                    }, e.prototype.createSyncBufferGroup = function(e, t, r) {
                        var i = this.renderer.gl;
                        this.renderer.buffer.bind(e.buffer);
                        var n = this.gl.getUniformBlockIndex(t.program, r);
                        t.uniformBufferBindings[r] = this.shader.uniformBindCount, i.uniformBlockBinding(t.program, n, this.shader.uniformBindCount), this.shader.uniformBindCount++;
                        var o = this.getSignature(e, this.shader.program.uniformData, "ubo"),
                            s = this._uboCache[o];
                        if (s || (s = this._uboCache[o] = Qe(e, this.shader.program.uniformData)), e.autoManage) {
                            var a = new Float32Array(s.size / 4);
                            e.buffer.update(a)
                        }
                        return t.uniformGroups[e.id] = s.syncFunc, t.uniformGroups[e.id]
                    }, e.prototype.getSignature = function(e, t, r) {
                        var i = e.uniforms,
                            n = [r + "-"];
                        for (var o in i) n.push(o), t[o] && n.push(t[o].type);
                        return n.join("-")
                    }, e.prototype.getGlProgram = function() {
                        return this.shader ? this.shader.program.glPrograms[this.renderer.CONTEXT_UID] : null
                    }, e.prototype.generateProgram = function(e) {
                        var t = this.gl,
                            r = e.program,
                            i = et(t, r);
                        return r.glPrograms[this.renderer.CONTEXT_UID] = i, i
                    }, e.prototype.reset = function() {
                        this.program = null, this.shader = null
                    }, e.prototype.disposeShader = function(e) {
                        this.shader === e && (this.shader = null)
                    }, e.prototype.destroy = function() {
                        this.renderer = null, this.destroyed = !0
                    }, e
                }();
            var nt = function() {
                    function e() {
                        this.gl = null, this.stateId = 0, this.polygonOffset = 0, this.blendMode = n.T$.NONE, this._blendEq = !1, this.map = [], this.map[0] = this.setBlend, this.map[1] = this.setOffset, this.map[2] = this.setCullFace, this.map[3] = this.setDepthTest, this.map[4] = this.setFrontFace, this.map[5] = this.setDepthMask, this.checks = [], this.defaultState = new Be, this.defaultState.blend = !0
                    }
                    return e.prototype.contextChange = function(e) {
                        this.gl = e, this.blendModes = function(e, t) {
                            return void 0 === t && (t = []), t[n.T$.NORMAL] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.ADD] = [e.ONE, e.ONE], t[n.T$.MULTIPLY] = [e.DST_COLOR, e.ONE_MINUS_SRC_ALPHA, e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.SCREEN] = [e.ONE, e.ONE_MINUS_SRC_COLOR, e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.OVERLAY] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.DARKEN] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.LIGHTEN] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.COLOR_DODGE] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.COLOR_BURN] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.HARD_LIGHT] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.SOFT_LIGHT] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.DIFFERENCE] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.EXCLUSION] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.HUE] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.SATURATION] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.COLOR] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.LUMINOSITY] = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.NONE] = [0, 0], t[n.T$.NORMAL_NPM] = [e.SRC_ALPHA, e.ONE_MINUS_SRC_ALPHA, e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.ADD_NPM] = [e.SRC_ALPHA, e.ONE, e.ONE, e.ONE], t[n.T$.SCREEN_NPM] = [e.SRC_ALPHA, e.ONE_MINUS_SRC_COLOR, e.ONE, e.ONE_MINUS_SRC_ALPHA], t[n.T$.SRC_IN] = [e.DST_ALPHA, e.ZERO], t[n.T$.SRC_OUT] = [e.ONE_MINUS_DST_ALPHA, e.ZERO], t[n.T$.SRC_ATOP] = [e.DST_ALPHA, e.ONE_MINUS_SRC_ALPHA], t[n.T$.DST_OVER] = [e.ONE_MINUS_DST_ALPHA, e.ONE], t[n.T$.DST_IN] = [e.ZERO, e.SRC_ALPHA], t[n.T$.DST_OUT] = [e.ZERO, e.ONE_MINUS_SRC_ALPHA], t[n.T$.DST_ATOP] = [e.ONE_MINUS_DST_ALPHA, e.SRC_ALPHA], t[n.T$.XOR] = [e.ONE_MINUS_DST_ALPHA, e.ONE_MINUS_SRC_ALPHA], t[n.T$.SUBTRACT] = [e.ONE, e.ONE, e.ONE, e.ONE, e.FUNC_REVERSE_SUBTRACT, e.FUNC_ADD], t
                        }(e), this.set(this.defaultState), this.reset()
                    }, e.prototype.set = function(e) {
                        if (e = e || this.defaultState, this.stateId !== e.data) {
                            for (var t = this.stateId ^ e.data, r = 0; t;) 1 & t && this.map[r].call(this, !!(e.data & 1 << r)), t >>= 1, r++;
                            this.stateId = e.data
                        }
                        for (r = 0; r < this.checks.length; r++) this.checks[r](this, e)
                    }, e.prototype.forceState = function(e) {
                        e = e || this.defaultState;
                        for (var t = 0; t < this.map.length; t++) this.map[t].call(this, !!(e.data & 1 << t));
                        for (t = 0; t < this.checks.length; t++) this.checks[t](this, e);
                        this.stateId = e.data
                    }, e.prototype.setBlend = function(t) {
                        this.updateCheck(e.checkBlendMode, t), this.gl[t ? "enable" : "disable"](this.gl.BLEND)
                    }, e.prototype.setOffset = function(t) {
                        this.updateCheck(e.checkPolygonOffset, t), this.gl[t ? "enable" : "disable"](this.gl.POLYGON_OFFSET_FILL)
                    }, e.prototype.setDepthTest = function(e) {
                        this.gl[e ? "enable" : "disable"](this.gl.DEPTH_TEST)
                    }, e.prototype.setDepthMask = function(e) {
                        this.gl.depthMask(e)
                    }, e.prototype.setCullFace = function(e) {
                        this.gl[e ? "enable" : "disable"](this.gl.CULL_FACE)
                    }, e.prototype.setFrontFace = function(e) {
                        this.gl.frontFace(this.gl[e ? "CW" : "CCW"])
                    }, e.prototype.setBlendMode = function(e) {
                        if (e !== this.blendMode) {
                            this.blendMode = e;
                            var t = this.blendModes[e],
                                r = this.gl;
                            2 === t.length ? r.blendFunc(t[0], t[1]) : r.blendFuncSeparate(t[0], t[1], t[2], t[3]), 6 === t.length ? (this._blendEq = !0, r.blendEquationSeparate(t[4], t[5])) : this._blendEq && (this._blendEq = !1, r.blendEquationSeparate(r.FUNC_ADD, r.FUNC_ADD))
                        }
                    }, e.prototype.setPolygonOffset = function(e, t) {
                        this.gl.polygonOffset(e, t)
                    }, e.prototype.reset = function() {
                        this.gl.pixelStorei(this.gl.UNPACK_FLIP_Y_WEBGL, !1), this.forceState(this.defaultState), this._blendEq = !0, this.blendMode = -1, this.setBlendMode(0)
                    }, e.prototype.updateCheck = function(e, t) {
                        var r = this.checks.indexOf(e);
                        t && -1 === r ? this.checks.push(e) : t || -1 === r || this.checks.splice(r, 1)
                    }, e.checkBlendMode = function(e, t) {
                        e.setBlendMode(t.blendMode)
                    }, e.checkPolygonOffset = function(e, t) {
                        e.setPolygonOffset(1, t.polygonOffset)
                    }, e.prototype.destroy = function() {
                        this.gl = null
                    }, e
                }(),
                ot = function() {
                    function e(e) {
                        this.renderer = e, this.count = 0, this.checkCount = 0, this.maxIdle = i.Xd.GC_MAX_IDLE, this.checkCountMax = i.Xd.GC_MAX_CHECK_COUNT, this.mode = i.Xd.GC_MODE
                    }
                    return e.prototype.postrender = function() {
                        this.renderer.renderingToScreen && (this.count++, this.mode !== n.UN.MANUAL && (this.checkCount++, this.checkCount > this.checkCountMax && (this.checkCount = 0, this.run())))
                    }, e.prototype.run = function() {
                        for (var e = this.renderer.texture, t = e.managedTextures, r = !1, i = 0; i < t.length; i++) {
                            var n = t[i];
                            !n.framebuffer && this.count - n.touched > this.maxIdle && (e.destroyTexture(n, !0), t[i] = null, r = !0)
                        }
                        if (r) {
                            var o = 0;
                            for (i = 0; i < t.length; i++) null !== t[i] && (t[o++] = t[i]);
                            t.length = o
                        }
                    }, e.prototype.unload = function(e) {
                        var t = this.renderer.texture,
                            r = e._texture;
                        r && !r.framebuffer && t.destroyTexture(r);
                        for (var i = e.children.length - 1; i >= 0; i--) this.unload(e.children[i])
                    }, e.prototype.destroy = function() {
                        this.renderer = null
                    }, e
                }();
            var st = function(e) {
                    this.texture = e, this.width = -1, this.height = -1, this.dirtyId = -1, this.dirtyStyleId = -1, this.mipmap = !1, this.wrapMode = 33071, this.type = n.vK.UNSIGNED_BYTE, this.internalFormat = n.I2.RGBA, this.samplerType = 0
                },
                at = function() {
                    function e(e) {
                        this.renderer = e, this.boundTextures = [], this.currentLocation = -1, this.managedTextures = [], this._unknownBoundTextures = !1, this.unknownTexture = new y, this.hasIntegerTextures = !1
                    }
                    return e.prototype.contextChange = function() {
                        var e = this.gl = this.renderer.gl;
                        this.CONTEXT_UID = this.renderer.CONTEXT_UID, this.webGLVersion = this.renderer.context.webGLVersion, this.internalFormats = function(e) {
                            var t, r, i, o, s, a, u, h, l, d, f, c, p, v, m, g, y, _, b, x, T, E, R;
                            return "WebGL2RenderingContext" in globalThis && e instanceof globalThis.WebGL2RenderingContext ? ((t = {})[n.vK.UNSIGNED_BYTE] = ((r = {})[n.I2.RGBA] = e.RGBA8, r[n.I2.RGB] = e.RGB8, r[n.I2.RG] = e.RG8, r[n.I2.RED] = e.R8, r[n.I2.RGBA_INTEGER] = e.RGBA8UI, r[n.I2.RGB_INTEGER] = e.RGB8UI, r[n.I2.RG_INTEGER] = e.RG8UI, r[n.I2.RED_INTEGER] = e.R8UI, r[n.I2.ALPHA] = e.ALPHA, r[n.I2.LUMINANCE] = e.LUMINANCE, r[n.I2.LUMINANCE_ALPHA] = e.LUMINANCE_ALPHA, r), t[n.vK.BYTE] = ((i = {})[n.I2.RGBA] = e.RGBA8_SNORM, i[n.I2.RGB] = e.RGB8_SNORM, i[n.I2.RG] = e.RG8_SNORM, i[n.I2.RED] = e.R8_SNORM, i[n.I2.RGBA_INTEGER] = e.RGBA8I, i[n.I2.RGB_INTEGER] = e.RGB8I, i[n.I2.RG_INTEGER] = e.RG8I, i[n.I2.RED_INTEGER] = e.R8I, i), t[n.vK.UNSIGNED_SHORT] = ((o = {})[n.I2.RGBA_INTEGER] = e.RGBA16UI, o[n.I2.RGB_INTEGER] = e.RGB16UI, o[n.I2.RG_INTEGER] = e.RG16UI, o[n.I2.RED_INTEGER] = e.R16UI, o[n.I2.DEPTH_COMPONENT] = e.DEPTH_COMPONENT16, o), t[n.vK.SHORT] = ((s = {})[n.I2.RGBA_INTEGER] = e.RGBA16I, s[n.I2.RGB_INTEGER] = e.RGB16I, s[n.I2.RG_INTEGER] = e.RG16I, s[n.I2.RED_INTEGER] = e.R16I, s), t[n.vK.UNSIGNED_INT] = ((a = {})[n.I2.RGBA_INTEGER] = e.RGBA32UI, a[n.I2.RGB_INTEGER] = e.RGB32UI, a[n.I2.RG_INTEGER] = e.RG32UI, a[n.I2.RED_INTEGER] = e.R32UI, a[n.I2.DEPTH_COMPONENT] = e.DEPTH_COMPONENT24, a), t[n.vK.INT] = ((u = {})[n.I2.RGBA_INTEGER] = e.RGBA32I, u[n.I2.RGB_INTEGER] = e.RGB32I, u[n.I2.RG_INTEGER] = e.RG32I, u[n.I2.RED_INTEGER] = e.R32I, u), t[n.vK.FLOAT] = ((h = {})[n.I2.RGBA] = e.RGBA32F, h[n.I2.RGB] = e.RGB32F, h[n.I2.RG] = e.RG32F, h[n.I2.RED] = e.R32F, h[n.I2.DEPTH_COMPONENT] = e.DEPTH_COMPONENT32F, h), t[n.vK.HALF_FLOAT] = ((l = {})[n.I2.RGBA] = e.RGBA16F, l[n.I2.RGB] = e.RGB16F, l[n.I2.RG] = e.RG16F, l[n.I2.RED] = e.R16F, l), t[n.vK.UNSIGNED_SHORT_5_6_5] = ((d = {})[n.I2.RGB] = e.RGB565, d), t[n.vK.UNSIGNED_SHORT_4_4_4_4] = ((f = {})[n.I2.RGBA] = e.RGBA4, f), t[n.vK.UNSIGNED_SHORT_5_5_5_1] = ((c = {})[n.I2.RGBA] = e.RGB5_A1, c), t[n.vK.UNSIGNED_INT_2_10_10_10_REV] = ((p = {})[n.I2.RGBA] = e.RGB10_A2, p[n.I2.RGBA_INTEGER] = e.RGB10_A2UI, p), t[n.vK.UNSIGNED_INT_10F_11F_11F_REV] = ((v = {})[n.I2.RGB] = e.R11F_G11F_B10F, v), t[n.vK.UNSIGNED_INT_5_9_9_9_REV] = ((m = {})[n.I2.RGB] = e.RGB9_E5, m), t[n.vK.UNSIGNED_INT_24_8] = ((g = {})[n.I2.DEPTH_STENCIL] = e.DEPTH24_STENCIL8, g), t[n.vK.FLOAT_32_UNSIGNED_INT_24_8_REV] = ((y = {})[n.I2.DEPTH_STENCIL] = e.DEPTH32F_STENCIL8, y), R = t) : ((_ = {})[n.vK.UNSIGNED_BYTE] = ((b = {})[n.I2.RGBA] = e.RGBA, b[n.I2.RGB] = e.RGB, b[n.I2.ALPHA] = e.ALPHA, b[n.I2.LUMINANCE] = e.LUMINANCE, b[n.I2.LUMINANCE_ALPHA] = e.LUMINANCE_ALPHA, b), _[n.vK.UNSIGNED_SHORT_5_6_5] = ((x = {})[n.I2.RGB] = e.RGB, x), _[n.vK.UNSIGNED_SHORT_4_4_4_4] = ((T = {})[n.I2.RGBA] = e.RGBA, T), _[n.vK.UNSIGNED_SHORT_5_5_5_1] = ((E = {})[n.I2.RGBA] = e.RGBA, E), R = _), R
                        }(e);
                        var t = e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS);
                        this.boundTextures.length = t;
                        for (var r = 0; r < t; r++) this.boundTextures[r] = null;
                        this.emptyTextures = {};
                        var i = new st(e.createTexture());
                        e.bindTexture(e.TEXTURE_2D, i.texture), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, 1, 1, 0, e.RGBA, e.UNSIGNED_BYTE, new Uint8Array(4)), this.emptyTextures[e.TEXTURE_2D] = i, this.emptyTextures[e.TEXTURE_CUBE_MAP] = new st(e.createTexture()), e.bindTexture(e.TEXTURE_CUBE_MAP, this.emptyTextures[e.TEXTURE_CUBE_MAP].texture);
                        for (r = 0; r < 6; r++) e.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + r, 0, e.RGBA, 1, 1, 0, e.RGBA, e.UNSIGNED_BYTE, null);
                        e.texParameteri(e.TEXTURE_CUBE_MAP, e.TEXTURE_MAG_FILTER, e.LINEAR), e.texParameteri(e.TEXTURE_CUBE_MAP, e.TEXTURE_MIN_FILTER, e.LINEAR);
                        for (r = 0; r < this.boundTextures.length; r++) this.bind(null, r)
                    }, e.prototype.bind = function(e, t) {
                        void 0 === t && (t = 0);
                        var r = this.gl;
                        if ((e = null === e || void 0 === e ? void 0 : e.castToBaseTexture()) && e.valid && !e.parentTextureArray) {
                            e.touched = this.renderer.textureGC.count;
                            var i = e._glTextures[this.CONTEXT_UID] || this.initTexture(e);
                            this.boundTextures[t] !== e && (this.currentLocation !== t && (this.currentLocation = t, r.activeTexture(r.TEXTURE0 + t)), r.bindTexture(e.target, i.texture)), i.dirtyId !== e.dirtyId ? (this.currentLocation !== t && (this.currentLocation = t, r.activeTexture(r.TEXTURE0 + t)), this.updateTexture(e)) : i.dirtyStyleId !== e.dirtyStyleId && this.updateTextureStyle(e), this.boundTextures[t] = e
                        } else this.currentLocation !== t && (this.currentLocation = t, r.activeTexture(r.TEXTURE0 + t)), r.bindTexture(r.TEXTURE_2D, this.emptyTextures[r.TEXTURE_2D].texture), this.boundTextures[t] = null
                    }, e.prototype.reset = function() {
                        this._unknownBoundTextures = !0, this.hasIntegerTextures = !1, this.currentLocation = -1;
                        for (var e = 0; e < this.boundTextures.length; e++) this.boundTextures[e] = this.unknownTexture
                    }, e.prototype.unbind = function(e) {
                        var t = this.gl,
                            r = this.boundTextures;
                        if (this._unknownBoundTextures) {
                            this._unknownBoundTextures = !1;
                            for (var i = 0; i < r.length; i++) r[i] === this.unknownTexture && this.bind(null, i)
                        }
                        for (i = 0; i < r.length; i++) r[i] === e && (this.currentLocation !== i && (t.activeTexture(t.TEXTURE0 + i), this.currentLocation = i), t.bindTexture(e.target, this.emptyTextures[e.target].texture), r[i] = null)
                    }, e.prototype.ensureSamplerType = function(e) {
                        var t = this,
                            r = t.boundTextures,
                            i = t.hasIntegerTextures,
                            o = t.CONTEXT_UID;
                        if (i)
                            for (var s = e - 1; s >= 0; --s) {
                                var a = r[s];
                                if (a) a._glTextures[o].samplerType !== n.oT.FLOAT && this.renderer.texture.unbind(a)
                            }
                    }, e.prototype.initTexture = function(e) {
                        var t = new st(this.gl.createTexture());
                        return t.dirtyId = -1, e._glTextures[this.CONTEXT_UID] = t, this.managedTextures.push(e), e.on("dispose", this.destroyTexture, this), t
                    }, e.prototype.initTextureType = function(e, t) {
                        var r, i;
                        t.internalFormat = null !== (i = null === (r = this.internalFormats[e.type]) || void 0 === r ? void 0 : r[e.format]) && void 0 !== i ? i : e.format, 2 === this.webGLVersion && e.type === n.vK.HALF_FLOAT ? t.type = this.gl.HALF_FLOAT : t.type = e.type
                    }, e.prototype.updateTexture = function(e) {
                        var t = e._glTextures[this.CONTEXT_UID];
                        if (t) {
                            var r = this.renderer;
                            if (this.initTextureType(e, t), e.resource && e.resource.upload(r, e, t)) t.samplerType !== n.oT.FLOAT && (this.hasIntegerTextures = !0);
                            else {
                                var i = e.realWidth,
                                    o = e.realHeight,
                                    s = r.gl;
                                (t.width !== i || t.height !== o || t.dirtyId < 0) && (t.width = i, t.height = o, s.texImage2D(e.target, 0, t.internalFormat, i, o, 0, e.format, t.type, null))
                            }
                            e.dirtyStyleId !== t.dirtyStyleId && this.updateTextureStyle(e), t.dirtyId = e.dirtyId
                        }
                    }, e.prototype.destroyTexture = function(e, t) {
                        var r = this.gl;
                        if ((e = e.castToBaseTexture())._glTextures[this.CONTEXT_UID] && (this.unbind(e), r.deleteTexture(e._glTextures[this.CONTEXT_UID].texture), e.off("dispose", this.destroyTexture, this), delete e._glTextures[this.CONTEXT_UID], !t)) {
                            var i = this.managedTextures.indexOf(e); - 1 !== i && (0, o.Er)(this.managedTextures, i, 1)
                        }
                    }, e.prototype.updateTextureStyle = function(e) {
                        var t = e._glTextures[this.CONTEXT_UID];
                        t && (e.mipmap !== n.WB.POW2 && 2 === this.webGLVersion || e.isPowerOfTwo ? t.mipmap = e.mipmap >= 1 : t.mipmap = !1, 2 === this.webGLVersion || e.isPowerOfTwo ? t.wrapMode = e.wrapMode : t.wrapMode = n.Nt.CLAMP, e.resource && e.resource.style(this.renderer, e, t) || this.setStyle(e, t), t.dirtyStyleId = e.dirtyStyleId)
                    }, e.prototype.setStyle = function(e, t) {
                        var r = this.gl;
                        if (t.mipmap && e.mipmap !== n.WB.ON_MANUAL && r.generateMipmap(e.target), r.texParameteri(e.target, r.TEXTURE_WRAP_S, t.wrapMode), r.texParameteri(e.target, r.TEXTURE_WRAP_T, t.wrapMode), t.mipmap) {
                            r.texParameteri(e.target, r.TEXTURE_MIN_FILTER, e.scaleMode === n.aH.LINEAR ? r.LINEAR_MIPMAP_LINEAR : r.NEAREST_MIPMAP_NEAREST);
                            var i = this.renderer.context.extensions.anisotropicFiltering;
                            if (i && e.anisotropicLevel > 0 && e.scaleMode === n.aH.LINEAR) {
                                var o = Math.min(e.anisotropicLevel, r.getParameter(i.MAX_TEXTURE_MAX_ANISOTROPY_EXT));
                                r.texParameterf(e.target, i.TEXTURE_MAX_ANISOTROPY_EXT, o)
                            }
                        } else r.texParameteri(e.target, r.TEXTURE_MIN_FILTER, e.scaleMode === n.aH.LINEAR ? r.LINEAR : r.NEAREST);
                        r.texParameteri(e.target, r.TEXTURE_MAG_FILTER, e.scaleMode === n.aH.LINEAR ? r.LINEAR : r.NEAREST)
                    }, e.prototype.destroy = function() {
                        this.renderer = null
                    }, e
                }(),
                ut = {
                    __proto__: null,
                    FilterSystem: J,
                    BatchSystem: te,
                    ContextSystem: ie,
                    FramebufferSystem: se,
                    GeometrySystem: ue,
                    MaskSystem: Ge,
                    ScissorSystem: He,
                    StencilSystem: je,
                    ProjectionSystem: ze,
                    RenderTextureSystem: Ye,
                    ShaderSystem: it,
                    StateSystem: nt,
                    TextureGCSystem: ot,
                    TextureSystem: at
                },
                ht = new h.y3,
                lt = function(e) {
                    function t(t, r) {
                        void 0 === t && (t = n.N3.UNKNOWN);
                        var s = e.call(this) || this;
                        return r = Object.assign({}, i.Xd.RENDER_OPTIONS, r), s.options = r, s.type = t, s.screen = new h.Ae(0, 0, r.width, r.height), s.view = r.view || i.Xd.ADAPTER.createCanvas(), s.resolution = r.resolution || i.Xd.RESOLUTION, s.useContextAlpha = r.useContextAlpha, s.autoDensity = !!r.autoDensity, s.preserveDrawingBuffer = r.preserveDrawingBuffer, s.clearBeforeRender = r.clearBeforeRender, s._backgroundColor = 0, s._backgroundColorRgba = [0, 0, 0, 1], s._backgroundColorString = "#000000", s.backgroundColor = r.backgroundColor || s._backgroundColor, s.backgroundAlpha = r.backgroundAlpha, void 0 !== r.transparent && ((0, o.a1)("6.0.0", "Option transparent is deprecated, please use backgroundAlpha instead."), s.useContextAlpha = r.transparent, s.backgroundAlpha = r.transparent ? 0 : 1), s._lastObjectRendered = null, s.plugins = {}, s
                    }
                    return c(t, e), t.prototype.initPlugins = function(e) {
                        for (var t in e) this.plugins[t] = new e[t](this)
                    }, Object.defineProperty(t.prototype, "width", {
                        get: function() {
                            return this.view.width
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "height", {
                        get: function() {
                            return this.view.height
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t.prototype.resize = function(e, t) {
                        this.view.width = Math.round(e * this.resolution), this.view.height = Math.round(t * this.resolution);
                        var r = this.view.width / this.resolution,
                            i = this.view.height / this.resolution;
                        this.screen.width = r, this.screen.height = i, this.autoDensity && (this.view.style.width = r + "px", this.view.style.height = i + "px"), this.emit("resize", r, i)
                    }, t.prototype.generateTexture = function(e, t, r, i) {
                        void 0 === t && (t = {}), "number" === typeof t && ((0, o.a1)("6.1.0", "generateTexture options (scaleMode, resolution, region) are now object options."), t = {
                            scaleMode: t,
                            resolution: r,
                            region: i
                        });
                        var n = t.region,
                            s = function(e, t) {
                                var r = {};
                                for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && t.indexOf(i) < 0 && (r[i] = e[i]);
                                if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
                                    var n = 0;
                                    for (i = Object.getOwnPropertySymbols(e); n < i.length; n++) t.indexOf(i[n]) < 0 && Object.prototype.propertyIsEnumerable.call(e, i[n]) && (r[i[n]] = e[i[n]])
                                }
                                return r
                            }(t, ["region"]);
                        0 === (i = n || e.getLocalBounds(null, !0)).width && (i.width = 1), 0 === i.height && (i.height = 1);
                        var a = U.create(p({
                            width: i.width,
                            height: i.height
                        }, s));
                        return ht.tx = -i.x, ht.ty = -i.y, this.render(e, {
                            renderTexture: a,
                            clear: !1,
                            transform: ht,
                            skipUpdateTransform: !!e.parent
                        }), a
                    }, t.prototype.destroy = function(e) {
                        for (var t in this.plugins) this.plugins[t].destroy(), this.plugins[t] = null;
                        e && this.view.parentNode && this.view.parentNode.removeChild(this.view);
                        var r = this;
                        r.plugins = null, r.type = n.N3.UNKNOWN, r.view = null, r.screen = null, r._tempDisplayObjectParent = null, r.options = null, this._backgroundColorRgba = null, this._backgroundColorString = null, this._lastObjectRendered = null
                    }, Object.defineProperty(t.prototype, "backgroundColor", {
                        get: function() {
                            return this._backgroundColor
                        },
                        set: function(e) {
                            this._backgroundColor = e, this._backgroundColorString = (0, o.XN)(e), (0, o.wK)(e, this._backgroundColorRgba)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "backgroundAlpha", {
                        get: function() {
                            return this._backgroundColorRgba[3]
                        },
                        set: function(e) {
                            this._backgroundColorRgba[3] = e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t
                }(o.vp),
                dt = function(e) {
                    this.buffer = e || null, this.updateID = -1, this.byteLength = -1, this.refCount = 0
                },
                ft = function() {
                    function e(e) {
                        this.renderer = e, this.managedBuffers = {}, this.boundBufferBases = {}
                    }
                    return e.prototype.destroy = function() {
                        this.renderer = null
                    }, e.prototype.contextChange = function() {
                        this.disposeAll(!0), this.gl = this.renderer.gl, this.CONTEXT_UID = this.renderer.CONTEXT_UID
                    }, e.prototype.bind = function(e) {
                        var t = this.gl,
                            r = this.CONTEXT_UID,
                            i = e._glBuffers[r] || this.createGLBuffer(e);
                        t.bindBuffer(e.type, i.buffer)
                    }, e.prototype.bindBufferBase = function(e, t) {
                        var r = this.gl,
                            i = this.CONTEXT_UID;
                        if (this.boundBufferBases[t] !== e) {
                            var n = e._glBuffers[i] || this.createGLBuffer(e);
                            this.boundBufferBases[t] = e, r.bindBufferBase(r.UNIFORM_BUFFER, t, n.buffer)
                        }
                    }, e.prototype.bindBufferRange = function(e, t, r) {
                        var i = this.gl,
                            n = this.CONTEXT_UID;
                        r = r || 0;
                        var o = e._glBuffers[n] || this.createGLBuffer(e);
                        i.bindBufferRange(i.UNIFORM_BUFFER, t || 0, o.buffer, 256 * r, 256)
                    }, e.prototype.update = function(e) {
                        var t = this.gl,
                            r = this.CONTEXT_UID,
                            i = e._glBuffers[r];
                        if (e._updateID !== i.updateID)
                            if (i.updateID = e._updateID, t.bindBuffer(e.type, i.buffer), i.byteLength >= e.data.byteLength) t.bufferSubData(e.type, 0, e.data);
                            else {
                                var n = e.static ? t.STATIC_DRAW : t.DYNAMIC_DRAW;
                                i.byteLength = e.data.byteLength, t.bufferData(e.type, e.data, n)
                            }
                    }, e.prototype.dispose = function(e, t) {
                        if (this.managedBuffers[e.id]) {
                            delete this.managedBuffers[e.id];
                            var r = e._glBuffers[this.CONTEXT_UID],
                                i = this.gl;
                            e.disposeRunner.remove(this), r && (t || i.deleteBuffer(r.buffer), delete e._glBuffers[this.CONTEXT_UID])
                        }
                    }, e.prototype.disposeAll = function(e) {
                        for (var t = Object.keys(this.managedBuffers), r = 0; r < t.length; r++) this.dispose(this.managedBuffers[t[r]], e)
                    }, e.prototype.createGLBuffer = function(e) {
                        var t = this.CONTEXT_UID,
                            r = this.gl;
                        return e._glBuffers[t] = new dt(r.createBuffer()), this.managedBuffers[e.id] = e, e.disposeRunner.add(this), e._glBuffers[t]
                    }, e
                }(),
                ct = function(e) {
                    function t(r) {
                        var i = e.call(this, n.N3.WEBGL, r) || this;
                        return r = i.options, i.gl = null, i.CONTEXT_UID = 0, i.runners = {
                            destroy: new a.R("destroy"),
                            contextChange: new a.R("contextChange"),
                            reset: new a.R("reset"),
                            update: new a.R("update"),
                            postrender: new a.R("postrender"),
                            prerender: new a.R("prerender"),
                            resize: new a.R("resize")
                        }, i.runners.contextChange.add(i), i.globalUniforms = new $({
                            projectionMatrix: new h.y3
                        }, !0), i.addSystem(Ge, "mask").addSystem(ie, "context").addSystem(nt, "state").addSystem(it, "shader").addSystem(at, "texture").addSystem(ft, "buffer").addSystem(ue, "geometry").addSystem(se, "framebuffer").addSystem(He, "scissor").addSystem(je, "stencil").addSystem(ze, "projection").addSystem(ot, "textureGC").addSystem(J, "filter").addSystem(Ye, "renderTexture").addSystem(te, "batch"), i.initPlugins(t.__plugins), i.multisample = void 0, r.context ? i.context.initFromContext(r.context) : i.context.initFromOptions({
                            alpha: !!i.useContextAlpha,
                            antialias: r.antialias,
                            premultipliedAlpha: i.useContextAlpha && "notMultiplied" !== i.useContextAlpha,
                            stencil: !0,
                            preserveDrawingBuffer: r.preserveDrawingBuffer,
                            powerPreference: i.options.powerPreference
                        }), i.renderingToScreen = !0, (0, o.DE)(2 === i.context.webGLVersion ? "WebGL 2" : "WebGL 1"), i.resize(i.options.width, i.options.height), i
                    }
                    return c(t, e), t.create = function(e) {
                        if ((0, o.HR)()) return new t(e);
                        throw new Error('WebGL unsupported in this browser, use "pixi.js-legacy" for fallback canvas2d support.')
                    }, t.prototype.contextChange = function() {
                        var e, t = this.gl;
                        if (1 === this.context.webGLVersion) {
                            var r = t.getParameter(t.FRAMEBUFFER_BINDING);
                            t.bindFramebuffer(t.FRAMEBUFFER, null), e = t.getParameter(t.SAMPLES), t.bindFramebuffer(t.FRAMEBUFFER, r)
                        } else {
                            r = t.getParameter(t.DRAW_FRAMEBUFFER_BINDING);
                            t.bindFramebuffer(t.DRAW_FRAMEBUFFER, null), e = t.getParameter(t.SAMPLES), t.bindFramebuffer(t.DRAW_FRAMEBUFFER, r)
                        }
                        e >= n.G5.HIGH ? this.multisample = n.G5.HIGH : e >= n.G5.MEDIUM ? this.multisample = n.G5.MEDIUM : e >= n.G5.LOW ? this.multisample = n.G5.LOW : this.multisample = n.G5.NONE
                    }, t.prototype.addSystem = function(e, t) {
                        var r = new e(this);
                        if (this[t]) throw new Error('Whoops! The name "' + t + '" is already in use');
                        for (var i in this[t] = r, this.runners) this.runners[i].add(r);
                        return this
                    }, t.prototype.render = function(e, t) {
                        var r, i, n, s;
                        if (t && (t instanceof U ? ((0, o.a1)("6.0.0", "Renderer#render arguments changed, use options instead."), r = t, i = arguments[2], n = arguments[3], s = arguments[4]) : (r = t.renderTexture, i = t.clear, n = t.transform, s = t.skipUpdateTransform)), this.renderingToScreen = !r, this.runners.prerender.emit(), this.emit("prerender"), this.projection.transform = n, !this.context.isLost) {
                            if (r || (this._lastObjectRendered = e), !s) {
                                var a = e.enableTempParent();
                                e.updateTransform(), e.disableTempParent(a)
                            }
                            this.renderTexture.bind(r), this.batch.currentRenderer.start(), (void 0 !== i ? i : this.clearBeforeRender) && this.renderTexture.clear(), e.render(this), this.batch.currentRenderer.flush(), r && r.baseTexture.update(), this.runners.postrender.emit(), this.projection.transform = null, this.emit("postrender")
                        }
                    }, t.prototype.generateTexture = function(t, r, i, n) {
                        void 0 === r && (r = {});
                        var o = e.prototype.generateTexture.call(this, t, r, i, n);
                        return this.framebuffer.blit(), o
                    }, t.prototype.resize = function(t, r) {
                        e.prototype.resize.call(this, t, r), this.runners.resize.emit(this.screen.height, this.screen.width)
                    }, t.prototype.reset = function() {
                        return this.runners.reset.emit(), this
                    }, t.prototype.clear = function() {
                        this.renderTexture.bind(), this.renderTexture.clear()
                    }, t.prototype.destroy = function(t) {
                        for (var r in this.runners.destroy.emit(), this.runners) this.runners[r].destroy();
                        e.prototype.destroy.call(this, t), this.gl = null
                    }, Object.defineProperty(t.prototype, "extract", {
                        get: function() {
                            return (0, o.a1)("6.0.0", "Renderer#extract has been deprecated, please use Renderer#plugins.extract instead."), this.plugins.extract
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t.registerPlugin = function(e, t) {
                        (0, o.a1)("6.5.0", "Renderer.registerPlugin() has been deprecated, please use extensions.add() instead."), s.R.add({
                            name: e,
                            type: s.n.RendererPlugin,
                            ref: t
                        })
                    }, t.__plugins = {}, t
                }(lt);

            function pt(e) {
                return ct.create(e)
            }
            s.R.handleByMap(s.n.RendererPlugin, ct.__plugins);
            var vt = "attribute vec2 aVertexPosition;\nattribute vec2 aTextureCoord;\n\nuniform mat3 projectionMatrix;\n\nvarying vec2 vTextureCoord;\n\nvoid main(void)\n{\n    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\n    vTextureCoord = aTextureCoord;\n}",
                mt = "attribute vec2 aVertexPosition;\n\nuniform mat3 projectionMatrix;\n\nvarying vec2 vTextureCoord;\n\nuniform vec4 inputSize;\nuniform vec4 outputFrame;\n\nvec4 filterVertexPosition( void )\n{\n    vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;\n\n    return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord( void )\n{\n    return aVertexPosition * (outputFrame.zw * inputSize.zw);\n}\n\nvoid main(void)\n{\n    gl_Position = filterVertexPosition();\n    vTextureCoord = filterTextureCoord();\n}\n",
                gt = (function() {
                    function e(e) {
                        (0, o.a1)("6.1.0", "System class is deprecated, implemement ISystem interface instead."), this.renderer = e
                    }
                    e.prototype.destroy = function() {
                        this.renderer = null
                    }
                }(), function() {
                    this.texArray = null, this.blend = 0, this.type = n.lg.TRIANGLES, this.start = 0, this.size = 0, this.data = null
                }),
                yt = function() {
                    function e() {
                        this.elements = [], this.ids = [], this.count = 0
                    }
                    return e.prototype.clear = function() {
                        for (var e = 0; e < this.count; e++) this.elements[e] = null;
                        this.count = 0
                    }, e
                }(),
                _t = function() {
                    function e(e) {
                        "number" === typeof e ? this.rawBinaryData = new ArrayBuffer(e) : e instanceof Uint8Array ? this.rawBinaryData = e.buffer : this.rawBinaryData = e, this.uint32View = new Uint32Array(this.rawBinaryData), this.float32View = new Float32Array(this.rawBinaryData)
                    }
                    return Object.defineProperty(e.prototype, "int8View", {
                        get: function() {
                            return this._int8View || (this._int8View = new Int8Array(this.rawBinaryData)), this._int8View
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "uint8View", {
                        get: function() {
                            return this._uint8View || (this._uint8View = new Uint8Array(this.rawBinaryData)), this._uint8View
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "int16View", {
                        get: function() {
                            return this._int16View || (this._int16View = new Int16Array(this.rawBinaryData)), this._int16View
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "uint16View", {
                        get: function() {
                            return this._uint16View || (this._uint16View = new Uint16Array(this.rawBinaryData)), this._uint16View
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "int32View", {
                        get: function() {
                            return this._int32View || (this._int32View = new Int32Array(this.rawBinaryData)), this._int32View
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.view = function(e) {
                        return this[e + "View"]
                    }, e.prototype.destroy = function() {
                        this.rawBinaryData = null, this._int8View = null, this._uint8View = null, this._int16View = null, this._uint16View = null, this._int32View = null, this.uint32View = null, this.float32View = null
                    }, e.sizeOf = function(e) {
                        switch (e) {
                            case "int8":
                            case "uint8":
                                return 1;
                            case "int16":
                            case "uint16":
                                return 2;
                            case "int32":
                            case "uint32":
                            case "float32":
                                return 4;
                            default:
                                throw new Error(e + " isn't a valid view type")
                        }
                    }, e
                }(),
                bt = function(e) {
                    function t(t) {
                        var r = e.call(this, t) || this;
                        return r.shaderGenerator = null, r.geometryClass = null, r.vertexSize = null, r.state = Be.for2d(), r.size = 4 * i.Xd.SPRITE_BATCH_SIZE, r._vertexCount = 0, r._indexCount = 0, r._bufferedElements = [], r._bufferedTextures = [], r._bufferSize = 0, r._shader = null, r._packedGeometries = [], r._packedGeometryPoolSize = 2, r._flushId = 0, r._aBuffers = {}, r._iBuffers = {}, r.MAX_TEXTURES = 1, r.renderer.on("prerender", r.onPrerender, r), t.runners.contextChange.add(r), r._dcIndex = 0, r._aIndex = 0, r._iIndex = 0, r._attributeBuffer = null, r._indexBuffer = null, r._tempBoundTextures = [], r
                    }
                    return c(t, e), t.prototype.contextChange = function() {
                        var e = this.renderer.gl;
                        i.Xd.PREFER_ENV === n.Vi.WEBGL_LEGACY ? this.MAX_TEXTURES = 1 : (this.MAX_TEXTURES = Math.min(e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS), i.Xd.SPRITE_MAX_TEXTURES), this.MAX_TEXTURES = function(e, t) {
                            if (0 === e) throw new Error("Invalid value of `0` passed to `checkMaxIfStatementsInShader`");
                            for (var r = t.createShader(t.FRAGMENT_SHADER);;) {
                                var i = Se.replace(/%forloop%/gi, Ce(e));
                                if (t.shaderSource(r, i), t.compileShader(r), t.getShaderParameter(r, t.COMPILE_STATUS)) break;
                                e = e / 2 | 0
                            }
                            return e
                        }(this.MAX_TEXTURES, e)), this._shader = this.shaderGenerator.generateShader(this.MAX_TEXTURES);
                        for (var t = 0; t < this._packedGeometryPoolSize; t++) this._packedGeometries[t] = new this.geometryClass;
                        this.initFlushBuffers()
                    }, t.prototype.initFlushBuffers = function() {
                        for (var e = t._drawCallPool, r = t._textureArrayPool, i = this.size / 4, n = Math.floor(i / this.MAX_TEXTURES) + 1; e.length < i;) e.push(new gt);
                        for (; r.length < n;) r.push(new yt);
                        for (var o = 0; o < this.MAX_TEXTURES; o++) this._tempBoundTextures[o] = null
                    }, t.prototype.onPrerender = function() {
                        this._flushId = 0
                    }, t.prototype.render = function(e) {
                        e._texture.valid && (this._vertexCount + e.vertexData.length / 2 > this.size && this.flush(), this._vertexCount += e.vertexData.length / 2, this._indexCount += e.indices.length, this._bufferedTextures[this._bufferSize] = e._texture.baseTexture, this._bufferedElements[this._bufferSize++] = e)
                    }, t.prototype.buildTexturesAndDrawCalls = function() {
                        var e = this._bufferedTextures,
                            r = this.MAX_TEXTURES,
                            i = t._textureArrayPool,
                            n = this.renderer.batch,
                            o = this._tempBoundTextures,
                            s = this.renderer.textureGC.count,
                            a = ++y._globalBatch,
                            u = 0,
                            h = i[0],
                            l = 0;
                        n.copyBoundTextures(o, r);
                        for (var d = 0; d < this._bufferSize; ++d) {
                            var f = e[d];
                            e[d] = null, f._batchEnabled !== a && (h.count >= r && (n.boundArray(h, o, a, r), this.buildDrawCalls(h, l, d), l = d, h = i[++u], ++a), f._batchEnabled = a, f.touched = s, h.elements[h.count++] = f)
                        }
                        h.count > 0 && (n.boundArray(h, o, a, r), this.buildDrawCalls(h, l, this._bufferSize), ++u, ++a);
                        for (d = 0; d < o.length; d++) o[d] = null;
                        y._globalBatch = a
                    }, t.prototype.buildDrawCalls = function(e, r, i) {
                        var n = this,
                            s = n._bufferedElements,
                            a = n._attributeBuffer,
                            u = n._indexBuffer,
                            h = n.vertexSize,
                            l = t._drawCallPool,
                            d = this._dcIndex,
                            f = this._aIndex,
                            c = this._iIndex,
                            p = l[d];
                        p.start = this._iIndex, p.texArray = e;
                        for (var v = r; v < i; ++v) {
                            var m = s[v],
                                g = m._texture.baseTexture,
                                y = o.YA[g.alphaMode ? 1 : 0][m.blendMode];
                            s[v] = null, r < v && p.blend !== y && (p.size = c - p.start, r = v, (p = l[++d]).texArray = e, p.start = c), this.packInterleavedGeometry(m, a, u, f, c), f += m.vertexData.length / 2 * h, c += m.indices.length, p.blend = y
                        }
                        r < i && (p.size = c - p.start, ++d), this._dcIndex = d, this._aIndex = f, this._iIndex = c
                    }, t.prototype.bindAndClearTexArray = function(e) {
                        for (var t = this.renderer.texture, r = 0; r < e.count; r++) t.bind(e.elements[r], e.ids[r]), e.elements[r] = null;
                        e.count = 0
                    }, t.prototype.updateGeometry = function() {
                        var e = this,
                            t = e._packedGeometries,
                            r = e._attributeBuffer,
                            n = e._indexBuffer;
                        i.Xd.CAN_UPLOAD_SAME_BUFFER ? (t[this._flushId]._buffer.update(r.rawBinaryData), t[this._flushId]._indexBuffer.update(n), this.renderer.geometry.updateBuffers()) : (this._packedGeometryPoolSize <= this._flushId && (this._packedGeometryPoolSize++, t[this._flushId] = new this.geometryClass), t[this._flushId]._buffer.update(r.rawBinaryData), t[this._flushId]._indexBuffer.update(n), this.renderer.geometry.bind(t[this._flushId]), this.renderer.geometry.updateBuffers(), this._flushId++)
                    }, t.prototype.drawBatches = function() {
                        for (var e = this._dcIndex, r = this.renderer, i = r.gl, n = r.state, o = t._drawCallPool, s = null, a = 0; a < e; a++) {
                            var u = o[a],
                                h = u.texArray,
                                l = u.type,
                                d = u.size,
                                f = u.start,
                                c = u.blend;
                            s !== h && (s = h, this.bindAndClearTexArray(h)), this.state.blendMode = c, n.set(this.state), i.drawElements(l, d, i.UNSIGNED_SHORT, 2 * f)
                        }
                    }, t.prototype.flush = function() {
                        0 !== this._vertexCount && (this._attributeBuffer = this.getAttributeBuffer(this._vertexCount), this._indexBuffer = this.getIndexBuffer(this._indexCount), this._aIndex = 0, this._iIndex = 0, this._dcIndex = 0, this.buildTexturesAndDrawCalls(), this.updateGeometry(), this.drawBatches(), this._bufferSize = 0, this._vertexCount = 0, this._indexCount = 0)
                    }, t.prototype.start = function() {
                        this.renderer.state.set(this.state), this.renderer.texture.ensureSamplerType(this.MAX_TEXTURES), this.renderer.shader.bind(this._shader), i.Xd.CAN_UPLOAD_SAME_BUFFER && this.renderer.geometry.bind(this._packedGeometries[this._flushId])
                    }, t.prototype.stop = function() {
                        this.flush()
                    }, t.prototype.destroy = function() {
                        for (var t = 0; t < this._packedGeometryPoolSize; t++) this._packedGeometries[t] && this._packedGeometries[t].destroy();
                        this.renderer.off("prerender", this.onPrerender, this), this._aBuffers = null, this._iBuffers = null, this._packedGeometries = null, this._attributeBuffer = null, this._indexBuffer = null, this._shader && (this._shader.destroy(), this._shader = null), e.prototype.destroy.call(this)
                    }, t.prototype.getAttributeBuffer = function(e) {
                        var t = (0, o.a9)(Math.ceil(e / 8)),
                            r = (0, o.k3)(t),
                            i = 8 * t;
                        this._aBuffers.length <= r && (this._iBuffers.length = r + 1);
                        var n = this._aBuffers[i];
                        return n || (this._aBuffers[i] = n = new _t(i * this.vertexSize * 4)), n
                    }, t.prototype.getIndexBuffer = function(e) {
                        var t = (0, o.a9)(Math.ceil(e / 12)),
                            r = (0, o.k3)(t),
                            i = 12 * t;
                        this._iBuffers.length <= r && (this._iBuffers.length = r + 1);
                        var n = this._iBuffers[r];
                        return n || (this._iBuffers[r] = n = new Uint16Array(i)), n
                    }, t.prototype.packInterleavedGeometry = function(e, t, r, i, n) {
                        for (var s = t.uint32View, a = t.float32View, u = i / this.vertexSize, h = e.uvs, l = e.indices, d = e.vertexData, f = e._texture.baseTexture._batchLocation, c = Math.min(e.worldAlpha, 1), p = c < 1 && e._texture.baseTexture.alphaMode ? (0, o.rA)(e._tintRGB, c) : e._tintRGB + (255 * c << 24), v = 0; v < d.length; v += 2) a[i++] = d[v], a[i++] = d[v + 1], a[i++] = h[v], a[i++] = h[v + 1], s[i++] = p, a[i++] = f;
                        for (v = 0; v < l.length; v++) r[n++] = u + l[v]
                    }, t._drawCallPool = [], t._textureArrayPool = [], t
                }(ee),
                xt = function() {
                    function e(e, t) {
                        if (this.vertexSrc = e, this.fragTemplate = t, this.programCache = {}, this.defaultGroupCache = {}, t.indexOf("%count%") < 0) throw new Error('Fragment template must contain "%count%".');
                        if (t.indexOf("%forloop%") < 0) throw new Error('Fragment template must contain "%forloop%".')
                    }
                    return e.prototype.generateShader = function(e) {
                        if (!this.programCache[e]) {
                            for (var t = new Int32Array(e), r = 0; r < e; r++) t[r] = r;
                            this.defaultGroupCache[e] = $.from({
                                uSamplers: t
                            }, !0);
                            var i = this.fragTemplate;
                            i = (i = i.replace(/%count%/gi, "" + e)).replace(/%forloop%/gi, this.generateSampleSrc(e)), this.programCache[e] = new Oe(this.vertexSrc, i)
                        }
                        var n = {
                            tint: new Float32Array([1, 1, 1, 1]),
                            translationMatrix: new h.y3,
                            default: this.defaultGroupCache[e]
                        };
                        return new Me(this.programCache[e], n)
                    }, e.prototype.generateSampleSrc = function(e) {
                        var t = "";
                        t += "\n", t += "\n";
                        for (var r = 0; r < e; r++) r > 0 && (t += "\nelse "), r < e - 1 && (t += "if(vTextureId < " + r + ".5)"), t += "\n{", t += "\n\tcolor = texture2D(uSamplers[" + r + "], vTextureCoord);", t += "\n}";
                        return t += "\n", t += "\n"
                    }, e
                }(),
                Tt = function(e) {
                    function t(t) {
                        void 0 === t && (t = !1);
                        var r = e.call(this) || this;
                        return r._buffer = new k(null, t, !1), r._indexBuffer = new k(null, t, !0), r.addAttribute("aVertexPosition", r._buffer, 2, !1, n.vK.FLOAT).addAttribute("aTextureCoord", r._buffer, 2, !1, n.vK.FLOAT).addAttribute("aColor", r._buffer, 4, !0, n.vK.UNSIGNED_BYTE).addAttribute("aTextureId", r._buffer, 1, !0, n.vK.FLOAT).addIndex(r._indexBuffer), r
                    }
                    return c(t, e), t
                }(z),
                Et = "precision highp float;\nattribute vec2 aVertexPosition;\nattribute vec2 aTextureCoord;\nattribute vec4 aColor;\nattribute float aTextureId;\n\nuniform mat3 projectionMatrix;\nuniform mat3 translationMatrix;\nuniform vec4 tint;\n\nvarying vec2 vTextureCoord;\nvarying vec4 vColor;\nvarying float vTextureId;\n\nvoid main(void){\n    gl_Position = vec4((projectionMatrix * translationMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\n\n    vTextureCoord = aTextureCoord;\n    vTextureId = aTextureId;\n    vColor = aColor * tint;\n}\n",
                Rt = "varying vec2 vTextureCoord;\nvarying vec4 vColor;\nvarying float vTextureId;\nuniform sampler2D uSamplers[%count%];\n\nvoid main(void){\n    vec4 color;\n    %forloop%\n    gl_FragColor = color * vColor;\n}\n",
                It = function() {
                    function e() {}
                    return e.create = function(e) {
                        var t = Object.assign({
                                vertex: Et,
                                fragment: Rt,
                                geometryClass: Tt,
                                vertexSize: 6
                            }, e),
                            r = t.vertex,
                            i = t.fragment,
                            n = t.vertexSize,
                            o = t.geometryClass;
                        return function(e) {
                            function t(t) {
                                var s = e.call(this, t) || this;
                                return s.shaderGenerator = new xt(r, i), s.geometryClass = o, s.vertexSize = n, s
                            }
                            return c(t, e), t
                        }(bt)
                    }, Object.defineProperty(e, "defaultVertexSrc", {
                        get: function() {
                            return Et
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e, "defaultFragmentTemplate", {
                        get: function() {
                            return Rt
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e
                }(),
                At = It.create();
            Object.assign(At, {
                extension: {
                    name: "batch",
                    type: s.n.RendererPlugin
                }
            });
            var wt = {},
                St = function(e) {
                    Object.defineProperty(wt, e, {
                        get: function() {
                            return (0, o.a1)("6.0.0", "PIXI.systems." + e + " has moved to PIXI." + e), S[e]
                        }
                    })
                };
            for (var Ct in S) St(Ct);
            var Ft = {},
                Nt = function(e) {
                    Object.defineProperty(Ft, e, {
                        get: function() {
                            return (0, o.a1)("6.0.0", "PIXI.resources." + e + " has moved to PIXI." + e), ut[e]
                        }
                    })
                };
            for (var Ct in ut) Nt(Ct)
        }
    }
]);
//# sourceMappingURL=f6af37bc.85dc589a6475604f.js.map