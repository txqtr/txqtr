"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9686], {
        27879: function(e, n) {
            n.Z = {
                src: "/_next/static/media/diamond.724779d2.svg",
                height: 16,
                width: 17
            }
        },
        17175: function(e, n) {
            n.Z = {
                src: "/_next/static/media/down_small.1bf62862.svg",
                height: 17,
                width: 16
            }
        },
        5389: function(e, n, t) {
            t.d(n, {
                Z: function() {
                    return r
                }
            });
            var a = t(67294);

            function r(e, n, t) {
                (0, a.useEffect)((function() {
                    var a = function(a) {
                        n.some((function(e) {
                            var n;
                            return null === e || void 0 === e || null === (n = e.current) || void 0 === n ? void 0 : n.contains(a.target)
                        })) || (null === e || void 0 === e ? void 0 : e.current) && !(null === e || void 0 === e ? void 0 : e.current.contains(a.target)) && t(a)
                    };
                    return document.addEventListener("mousedown", a), document.addEventListener("touchstart", a),
                        function() {
                            document.removeEventListener("mousedown", a), document.removeEventListener("touchstart", a)
                        }
                }), [e, t])
            }
        },
        81499: function(e, n, t) {
            t.d(n, {
                y: function() {
                    return i
                }
            });
            var a = t(26042),
                r = t(85893),
                o = t(67294);

            function i(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                    t = function(t) {
                        return (0, r.jsx)(o.Suspense, {
                            fallback: n,
                            children: (0, r.jsx)(e, (0, a.Z)({}, t))
                        })
                    };
                return t
            }
        },
        57650: function(e, n, t) {
            var a = t(85893);
            n.Z = function(e) {
                var n = e.children,
                    t = e.className;
                return (0, a.jsx)("a", {
                    target: "_blank",
                    href: "https://remini-web.zendesk.com/hc/en-us",
                    rel: "noreferrer",
                    className: t,
                    children: n
                })
            }
        },
        99686: function(e, n, t) {
            t.r(n), t.d(n, {
                default: function() {
                    return S
                }
            });
            var a = t(85893),
                r = t(81499),
                o = t(92665),
                i = t(50820),
                c = t(26042),
                s = t(69396),
                l = t(2502),
                u = t(67294),
                d = u.forwardRef((function(e, n) {
                    var t = (0, l.ql)(),
                        r = t.t,
                        o = t.data;
                    return (0, a.jsx)("button", (0, s.Z)((0, c.Z)({
                        type: "button",
                        className: "btn btn--medium btn--secondary md:border-transparent"
                    }, e), {
                        ref: n,
                        children: r(o.header.myAccount)
                    }))
                })),
                f = u.forwardRef((function(e, n) {
                    var t = (0, l.ql)(),
                        r = t.t,
                        o = t.data;
                    return (0, a.jsx)("button", (0, s.Z)((0, c.Z)({
                        "data-cy": "login-btn",
                        type: "button",
                        className: "btn btn--medium md:btn--large btn--secondary"
                    }, e), {
                        ref: n,
                        children: r(o.header.logInSignUp)
                    }))
                })),
                h = t(17175),
                m = t(14332),
                p = t(20081),
                b = t(97301),
                v = t(5389);

            function g(e) {
                var n = e.props,
                    t = (0, l.ql)(),
                    r = t.locale,
                    i = t.changeLocale,
                    d = t.isLoadingTranslations,
                    f = (0, u.useState)(!1),
                    g = f[0],
                    x = f[1],
                    y = (0, u.useRef)(null),
                    w = (0, o.Q4)().track;
                (0, v.Z)(y, [], (0, u.useCallback)((function() {
                    return x(!1)
                }), []));
                var Z = b.J3.find((function(e) {
                    return e.code === r
                }));
                return Z ? (0, a.jsxs)("div", {
                    className: "relative flex flex-col items-center text-end",
                    ref: y,
                    children: [(0, a.jsxs)("button", (0, s.Z)((0, c.Z)({
                        "data-cy": "translate-btn",
                        type: "button",
                        className: "btn btn--medium md:btn--large btn--secondary w-full ".concat(g ? "bg-overlay-black-20" : "bg-overlay-white-10", " border-none gap-1")
                    }, n), {
                        onClick: function() {
                            w("language", "picker_tapped"), x(!g)
                        },
                        disabled: d,
                        children: [Z.name, (0, a.jsx)("img", (0, s.Z)((0, c.Z)({}, h.Z), {
                            alt: "",
                            className: "w-4 h-4"
                        }))]
                    })), (0, a.jsx)(m.M, {
                        children: g && (0, a.jsx)(p.E.div, {
                            className: "z-50 text-base list-none bg-overlay-black-80 rounded-lg absolute mt-16 w-40 h-[304px] overflow-y-scroll",
                            initial: {
                                opacity: 0,
                                scale: .95
                            },
                            animate: {
                                opacity: 1,
                                scale: 1
                            },
                            exit: {
                                opacity: 0,
                                scale: .95
                            },
                            transition: {
                                type: "easeInOut",
                                duration: .1
                            },
                            "aria-orientation": "vertical",
                            "aria-labelledby": "menu-button",
                            children: (0, a.jsx)("ul", {
                                className: "py-2",
                                children: b.J3.map((function(e) {
                                    return (0, a.jsx)("li", {
                                        children: (0, a.jsx)("button", {
                                            className: "py-1.5 px-6 font-medium block w-full text-white text-center hover:bg-gray-100 hover:text-black",
                                            onClick: function() {
                                                i(e.code), w("language", "selected", {
                                                    language: e.code
                                                }), x(!1)
                                            },
                                            children: e.name
                                        })
                                    }, e.code)
                                }))
                            })
                        }, "format-dropdown")
                    })]
                }) : null
            }
            var x = t(82532),
                y = {
                    src: "/_next/static/media/photoshop.f72dced6.svg",
                    height: 23,
                    width: 23
                };

            function w(e) {
                return (0, a.jsxs)("button", (0, s.Z)((0, c.Z)({
                    "data-cy": "photoshop-btn",
                    type: "button",
                    className: "btn btn--medium md:btn--large btn--secondary hover:bg-overlay-white-5"
                }, e), {
                    children: [(0, a.jsx)("img", (0, s.Z)((0, c.Z)({}, y), {
                        alt: ""
                    })), (0, a.jsx)("span", {
                        children: e.children
                    })]
                }))
            }
            var Z = t(57650),
                j = t(13807),
                k = t(8203),
                C = t(63589),
                N = t(80904),
                T = t(50777),
                _ = t(27879),
                E = u.forwardRef((function(e, n) {
                    return (0, a.jsxs)("button", (0, s.Z)((0, c.Z)({
                        "data-cy": "monetize-btn",
                        type: "button",
                        className: "btn btn--medium md:btn--large btn--secondary hover:bg-overlay-white-5"
                    }, e), {
                        ref: n,
                        children: [(0, a.jsx)("img", (0, s.Z)((0, c.Z)({}, _.Z), {
                            alt: ""
                        })), (0, a.jsx)("span", {
                            children: e.children
                        })]
                    }))
                })),
                L = t(11163),
                V = t(10238),
                z = t(2804),
                A = t(63228),
                R = t(45291);
            var S = (0, r.y)((function(e) {
                var n, t = e.className,
                    r = void 0 === t ? "" : t,
                    c = e.showHamburgerInMDSize,
                    s = (0, u.useRef)(null),
                    h = (0, u.useRef)(null),
                    m = (0, z.sJ)(T.Z),
                    p = (0, z.sJ)(k.d),
                    b = (0, j.aF)().data,
                    v = (0, z.Zl)(N.su),
                    y = (0, z.sJ)(C.yd),
                    _ = (0, R.DX)(),
                    S = _.isBaseUser,
                    I = _.isPersonalUser,
                    J = _.isBusinessUser,
                    M = (0, o.Q4)().track,
                    U = (0, l.ql)(),
                    q = U.t,
                    F = U.data,
                    B = (0, L.useRouter)(),
                    D = function(e) {
                        v({
                            id: "user:onboarding",
                            Modal: x.Z,
                            previousAction: e,
                            onClose: function() {
                                var e;
                                return null === (e = s.current) || void 0 === e ? void 0 : e.focus()
                            }
                        })
                    },
                    P = [(0, a.jsx)(Z.Z, {
                        className: "btn btn--medium btn--secondary md:border-transparent",
                        children: q(F.header.help)
                    }, "help-page")];
                if (p) {
                    var Q;
                    S(b) && !(null === b || void 0 === b || null === (Q = b.monetization) || void 0 === Q ? void 0 : Q.hasIncompleteSubscription) && ((null === b || void 0 === b ? void 0 : b.monetization.trialAvailable) && m.values.isFreeTrialEnabled ? P.push((0, a.jsx)(E, {
                        ref: s,
                        onClick: function(e) {
                            M("free_trial", "tapped", {
                                actionValue: "".concat(e.currentTarget.textContent, " (CTA)")
                            }), D(j.Vw.FreeTrial)
                        },
                        children: q(F.common.freeTrial)
                    }, "free-trial")) : P.push((0, a.jsx)(E, {
                        ref: s,
                        onClick: function(e) {
                            M("subscribe", "tapped", {
                                actionValue: "".concat(e.currentTarget.textContent, " (CTA)")
                            }), D(j.Vw.Subscription)
                        },
                        children: q(F.common.subscribe)
                    }, "subscribe")));
                    var H = 1 === P.length ? s : h;
                    P.unshift((0, a.jsx)(d, {
                        ref: H,
                        onClick: function(e) {
                            var n;
                            M("account", "tapped", {
                                actionValue: "".concat(e.currentTarget.textContent, " (CTA)")
                            }), n = s, v({
                                id: "user:account",
                                Modal: i.Z,
                                onClose: function() {
                                    n.current && n.current.focus()
                                }
                            })
                        }
                    }, "account"))
                } else y ? P.unshift((0, a.jsx)("div", {
                    className: "px-4 py-3 space-s-2",
                    children: (0, a.jsx)(V.gy, {
                        color: "white",
                        height: "25",
                        width: "25",
                        "aria-label": "loading"
                    })
                }, "logging-in")) : P.push((0, a.jsx)(f, {
                    ref: s,
                    onClick: function(e) {
                        M("login", "tapped", {
                            actionValue: "".concat(e.currentTarget.textContent, " (CTA)")
                        }), D(j.Vw.Login)
                    }
                }, "signup"));
                return m.values.psPlugin && p && !J(b) && !(null === b || void 0 === b || null === (n = b.monetization) || void 0 === n ? void 0 : n.hasIncompleteSubscription) && P.push((0, a.jsx)(w, {
                    onClick: function() {
                        M("photoshop_plugin", "tapped"), I(b) ? v({
                            id: "user:upgrade-subscription",
                            Modal: A.Z,
                            isUpgrade: !0
                        }) : D(j.Vw.Login)
                    },
                    children: q(F.common.plugin)
                }, "photoshop")), ["/", "/support"].includes(B.route) && P.push((0, a.jsx)(g, {}, "translate")), (0, a.jsx)("div", {
                    className: "flex flex-col space-y-4 ".concat(c ? "xl:flex-row xl:space-y-0" : "md:flex-row md:space-y-0 md:space-s-4", " ").concat(r),
                    children: P
                })
            }), null)
        }
    }
]);
//# sourceMappingURL=9686.e6f44664e1d5e3d0.js.map