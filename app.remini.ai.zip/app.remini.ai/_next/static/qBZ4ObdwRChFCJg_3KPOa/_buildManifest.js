self.__BUILD_MANIFEST = function(a, s) {
    return {
        __rewrites: {
            beforeFiles: [],
            afterFiles: [],
            fallback: []
        },
        "/": [a, "static/chunks/pages/index-03fb9387d2b6842a.js"],
        "/_error": ["static/chunks/pages/_error-175be6b56ae6bfef.js"],
        "/app-redirect-01": ["static/chunks/pages/app-redirect-01-ee1188d1551e01ee.js"],
        "/cancel-sub": ["static/chunks/937-b593a705e0e63a08.js", "static/chunks/pages/cancel-sub-0920ee2307025b4b.js"],
        "/invoice-data": ["static/chunks/pages/invoice-data-c2047e8886059868.js"],
        "/paypal-migration": ["static/chunks/pages/paypal-migration-715e0697dd76b3c6.js"],
        "/redeem": ["static/chunks/pages/redeem-f595e8b2ea7b8103.js"],
        "/result": ["static/chunks/9962-9ff33d9a1c662788.js", a, s, "static/chunks/pages/result-da213560eb2e80f0.js"],
        "/share": [a, s, "static/chunks/pages/share-8afaf7aadd7b6b98.js"],
        "/share-web": [a, s, "static/chunks/pages/share-web-aafcbfa5d3932daf.js"],
        "/support": ["static/chunks/pages/support-40546e33c6c6aec0.js"],
        "/web-onboarding": ["static/chunks/pages/web-onboarding-60931e757d955d5c.js"],
        "/web-onboarding-paywall": ["static/chunks/pages/web-onboarding-paywall-bc842062719c53ee.js"],
        "/[slug]": ["static/chunks/pages/[slug]-5204916ac2c92ed2.js"],
        sortedPages: ["/", "/_app", "/_error", "/app-redirect-01", "/cancel-sub", "/invoice-data", "/paypal-migration", "/redeem", "/result", "/share", "/share-web", "/support", "/web-onboarding", "/web-onboarding-paywall", "/[slug]"]
    }
}("static/chunks/4048-47c43bea6a8c2034.js", "static/chunks/7255-9a5ec2b75790c9e6.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();