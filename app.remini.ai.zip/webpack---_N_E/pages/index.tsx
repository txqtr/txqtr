import { HomeLayout } from '@/layout/homeLayout/HomeLayout';

export default HomeLayout;
