import AppWrapper from '@/layout/appWrapper/AppWrapper';
import '@pixi/math-extras';
import '../styles/index.css';

export default AppWrapper;
