import React from 'react';

const FormContext = React.createContext({ loading: false, disabled: false });

export default FormContext;
