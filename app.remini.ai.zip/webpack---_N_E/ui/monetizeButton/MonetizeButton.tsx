import React, { ButtonHTMLAttributes, LegacyRef } from 'react';

import diamondIcon from '@/public/images/icons/diamond.svg';

export const MonetizeButton = React.forwardRef(
  (
    props: ButtonHTMLAttributes<HTMLButtonElement>,
    ref?: LegacyRef<HTMLButtonElement>
  ) => (
    <button
      data-cy="monetize-btn"
      type="button"
      className="btn btn--medium md:btn--large btn--secondary hover:bg-overlay-white-5"
      {...props}
      ref={ref}
    >
      <img {...diamondIcon} alt="" />
      <span>{props.children}</span>
    </button>
  )
);
