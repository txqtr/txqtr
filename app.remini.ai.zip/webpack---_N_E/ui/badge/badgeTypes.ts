export enum BadgeVariants {
  Soon = 'soon',
  Pro = 'pro',
  New = 'new',
  NewAnimated = 'new-animated',
  Large = 'large',
  Business = 'business',
  Beta = 'beta',
}
