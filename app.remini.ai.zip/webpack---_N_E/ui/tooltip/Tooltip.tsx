import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import useEventListener from '@/core/listeners/useEventListener';
import { deviceType, DeviceIds } from '@/core/environment/deviceType';

const mapPositionToClass = {
  bottom: {
    tooltip: 'top-full start-0 pt-2 mt-2',
    arrow: '-top-1',
  },
  top: {
    tooltip: 'bottom-full start-0 pb-2 mb-2',
    arrow: '-bottom-1',
  },
};

export enum TooltipContext {
  Download = 'download',
  Slider = 'slider',
}

interface Props {
  visible?: boolean;
  position?: 'top' | 'bottom';
  content?: string;
  duration?: number;
  className?: string;
  tooltipOuterClassName?: string;
  tooltipClassName?: string;
  tooltipContentClassName?: string;
  disableForcePosition?: boolean;
  afterDisappear?: CallableFunction;
  children?: React.ReactNode;
  context?: TooltipContext;
}

export default function Tooltip({
  visible = false,
  position = 'bottom', // "top" or "bottom", for simplicity's sake
  content = '',
  duration,
  className = '',
  tooltipOuterClassName = '',
  tooltipClassName = '',
  tooltipContentClassName = '',
  disableForcePosition,
  afterDisappear,
  children,
  context = TooltipContext.Download,
}: Props) {
  const [forcePosition, setForcePosition] = useState<false | 'top' | 'bottom'>(
    false
  );
  const [disappear, setDisappear] = useState(false);
  const [isMouseOver, setIsMouseOver] = useState(false);
  const tooltipRef = useRef<HTMLDivElement>(null);

  const updatePos = useCallback(() => {
    if (!tooltipRef.current) return;
    if (disableForcePosition) {
      setForcePosition(false);
      return;
    }

    const clientRect = tooltipRef.current.getBoundingClientRect();
    const offsetTop = clientRect.top + window.scrollX;
    const { height } = clientRect;
    const offsetBottom = window.innerHeight - offsetTop - height;
    const newForcePosition =
      offsetBottom < height + 100
        ? 'top'
        : offsetTop < height + 100
        ? 'bottom'
        : false;
    setForcePosition(newForcePosition);
  }, [disableForcePosition]);

  useEffect(() => {
    updatePos();
  }, [updatePos]);

  useEffect(() => {
    let timeout;
    if (duration) {
      timeout = setTimeout(() => {
        setDisappear(true);
        if (typeof afterDisappear === 'function') afterDisappear();
      }, duration);
    }
    return () => clearTimeout(timeout);
  }, [duration, afterDisappear]);

  useEventListener(null, 'resize', updatePos);
  // useEventListener(null, 'scroll', updatePos);

  const isDesktop = useMemo(() => deviceType() === DeviceIds.Desktop, []);

  const pos = forcePosition || position;

  return (
    <div
      className={`relative flex flex-col items-center ${className}`}
      // Only in desktop, keep Tooltip until mouse leaves
      {...(isDesktop && {
        onMouseEnter: () => setIsMouseOver(!disappear),
        onMouseLeave: () => setIsMouseOver(false),
      })}
    >
      {children}
      <AnimatePresence>
        {!!visible && (!disappear || isMouseOver) && (
          <motion.div
            ref={tooltipRef}
            className={`${
              context === TooltipContext.Slider
                ? 'relative bottom-16 w-40'
                : 'absolute w-full'
            }  z-50 flex flex-col items-center ${
              mapPositionToClass[pos].tooltip
            } ${tooltipOuterClassName}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <div
              className={`relative text-center flex flex-col items-center bg-white M13 text-black rounded-full py-2 px-6 ${tooltipClassName}`}
            >
              <div
                className={`absolute w-4 h-4 min-w-4 min-h-4 z-0 bg-white rounded-sm rotate-45 ${mapPositionToClass[pos].arrow}`}
              />
              <div className={`z-10 ${tooltipContentClassName}`}>{content}</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
