import { MutableRefObject, useEffect } from 'react';

export default function useOnClickOutside(
  ref: MutableRefObject<any> | null,
  refsToExclude: MutableRefObject<any>[],
  handler: CallableFunction
) {
  useEffect(
    () => {
      const listener = (event: Event) => {
        // Do nothing if clicking one of the elements to exclude
        if (
          refsToExclude.some((reference) =>
            reference?.current?.contains(event.target)
          )
        ) {
          return;
        }

        // Do nothing if clicking ref's element or descendent elements
        if (!ref?.current || ref?.current.contains(event.target)) {
          return;
        }
        handler(event);
      };
      document.addEventListener('mousedown', listener);
      document.addEventListener('touchstart', listener);
      return () => {
        document.removeEventListener('mousedown', listener);
        document.removeEventListener('touchstart', listener);
      };
    },
    // Add ref and handler to effect dependencies
    // To optimize you can wrap handler in useCallback before passing it.
    [ref, handler]
  );
}
