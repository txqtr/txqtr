export default function bytesToMB(bytes: number): number {
  return Math.round((bytes / 1024 ** 2) * 10) / 10;
}
