import { useEffect } from 'react';
import { applyTrackingMonitoring } from './applyTrackingMonitoring';

export const useMonitoringInfo = () => {
  useEffect(() => {
    applyTrackingMonitoring();
  }, []);
};
