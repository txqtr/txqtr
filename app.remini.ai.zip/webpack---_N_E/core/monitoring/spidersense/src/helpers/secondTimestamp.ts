export const secondTimestamp = (): number => {
  const timestamp = new Date().getTime();
  return timestamp / 1000;
};
