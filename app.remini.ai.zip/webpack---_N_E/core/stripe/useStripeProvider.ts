import { loadStripe } from '@stripe/stripe-js';
import { useState } from 'react';

export const useStripeProvider = () => {
  const [stripePromise] = useState(() =>
    loadStripe(process.env.NEXT_PUBLIC_STRIPE_KEY as string)
  );
  return { stripePromise };
};
