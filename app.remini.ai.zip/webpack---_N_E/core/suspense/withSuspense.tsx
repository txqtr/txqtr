import React from 'react';

export function withSuspense<P>(
  ChildComponent: React.ComponentType<P>,
  fallback = null
) {
  function WrappedChildComponent(props: P & JSX.IntrinsicAttributes) {
    return (
      <React.Suspense fallback={fallback}>
        <ChildComponent {...props} />
      </React.Suspense>
    );
  }
  return WrappedChildComponent;
}
