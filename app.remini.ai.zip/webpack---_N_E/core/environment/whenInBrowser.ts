export default function whenInBrowser<T>(cb: (...args: any) => T) {
  return (...args) => {
    if (typeof window !== 'undefined') {
      return cb(...args);
    }
  };
}
