export const FBTrackingReady = (): boolean =>
  window && window.fbq && typeof window.fbq === 'function';
