export const logAppVersion = () =>
  console.log(`App Version: ${process.env.appVersion}`);
