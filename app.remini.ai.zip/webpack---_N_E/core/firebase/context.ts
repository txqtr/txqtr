import React from 'react';
import { FirebaseApp } from 'firebase/app';

const defaultValue: { app: FirebaseApp | null } = { app: null };
const Context = React.createContext(defaultValue);

export default Context;
