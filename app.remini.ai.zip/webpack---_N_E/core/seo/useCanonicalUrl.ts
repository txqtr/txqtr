import { useRouter } from 'next/router';

export const useCanonicalUrl = (): string => {
  const router = useRouter();
  const url = router.asPath.split('?')[0];
  return url;
};
