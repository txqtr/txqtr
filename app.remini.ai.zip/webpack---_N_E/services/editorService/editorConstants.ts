import { EnhanceAdditionalParams } from '@/services/editorService/editorTypes';

export const DEFAULT_ADDITIONAL_PARAMS: EnhanceAdditionalParams = {
  removeCap: false,
  faceDetectorMaxInputRes: 800,
  jpegQuality: 80,
} as const;
