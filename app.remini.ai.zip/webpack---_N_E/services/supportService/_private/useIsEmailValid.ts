import { contactFormEmail } from '@/stores/contactFormStore';
import { useRecoilValue } from 'recoil';

export default function useIsEmailValid() {
  const email = useRecoilValue(contactFormEmail);
  const regex = /^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/g;
  return regex.test(email.toLowerCase());
}
