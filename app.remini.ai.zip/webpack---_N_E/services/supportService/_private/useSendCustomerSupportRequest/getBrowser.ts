export default function getBrowser() {
  if (
    (navigator.userAgent.indexOf('Opera') ||
      navigator.userAgent.indexOf('OPR')) !== -1
  ) {
    return 'opera';
  }
  if (navigator.userAgent.indexOf('Chrome') !== -1) {
    return 'chrome';
  }
  if (navigator.userAgent.indexOf('Safari') !== -1) {
    return 'safari';
  }
  if (navigator.userAgent.indexOf('Firefox') !== -1) {
    return 'firefox';
  }
  if (
    navigator.userAgent.indexOf('MSIE') !== -1 ||
    !!document['documentMode'] === true // eslint-disable-line @typescript-eslint/dot-notation
  ) {
    return 'ie';
  }
  return 'unknown';
}
