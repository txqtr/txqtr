import { generateTracker } from '@/core/monitoring/trackEvents';

export const customerSupportRequestTracker = generateTracker([
  'support',
  'request',
]);
