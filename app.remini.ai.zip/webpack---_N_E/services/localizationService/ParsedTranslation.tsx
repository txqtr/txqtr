import React, { Fragment, memo, ReactNode, useCallback, useMemo } from 'react';
import { v4 as uuidv4 } from 'uuid';

// Default tags, no need to manually write them.
const defaultNodes = {
  b: (node: ReactNode) => <b>{node}</b>,
  i: (node: ReactNode) => <i>{node}</i>,
  u: (node: ReactNode) => <u>{node}</u>,
};

type Props = {
  string: string;
  object?: Record<string, ReactNode | ((str: ReactNode) => ReactNode)> | null;
  className?: string;
};

/**
 * _Note: This component must execute only in the browser (e.g. `next/dynamic`), since it uses DOM's `document`._
 *
 * Please check the README to see how this logic works!
 *
 * @example
 *  // Translation string: we put "tos" as a custom tag.
 * "By continuing, you accept our <tos>Terms of Service</tos>"
 *
 * // Then, we can replace "tos" tag with a React component of our choice.
 * // Its inner text ("Terms of Service") will be passed as param.
 * tos: (text) => <a href="https://...">{text}</a>
 */
function ParsedTranslation({ string, object: obj, className }: Props) {
  // Prevent overriding default b/i/u tags, so that we don't have to manually parse them.
  const object = useMemo(
    () => ({ ...obj, ...defaultNodes } as typeof obj & typeof defaultNodes),
    [obj]
  );

  /** This function recursively gets all children of the given HTML node. */
  const getNodeRecursive = useCallback(
    (el: NodeList[number]) => {
      // Get current tag
      const tag = el.nodeName.toLowerCase();

      // Get the key (from object input) corresponding to a function returning a React component.
      const objectValue = object[tag];
      const fn = typeof objectValue === 'function' && objectValue;

      const key = uuidv4(); // Unique key, needed for the Fragment

      // Check if we arrived to the "text node" (final leaf of the tree),
      // OR if there's no function related to this custom tag (in this case, text won't be printed).
      if (tag === '#text' || !fn) {
        /**
         * Split text to parse {{x}} occurrencies.
         * @example "Welcome {{username}}!" => ['Welcome ', 'username', '!']
         */
        const splits = el.nodeValue?.split(/\{\{([^{}]+)\}\}/g) || [];

        /** Convert splits into Fragments.
         * @example { username: "John Doe" } => [<Fragment>Welcome</Fragment>, <Fragment>John Doe</Fragment>, <Fragment>!</Fragment>]
         * */
        const finalString = splits.map((split, i) => {
          const val = object[split];
          return (
            // eslint-disable-next-line react/no-array-index-key
            <Fragment key={i}>
              {
                // Even indexes always correspond to raw texts (outside {{username}})
                i % 2 === 0
                  ? split
                  : // Odd indexes always correspond to the inner wildcard word ("username")
                  typeof val === 'function'
                  ? val(split)
                  : val
              }
            </Fragment>
          );
        });

        // Return this array of Fragments from the current `getNodeRecursive()` call.
        return <Fragment key={key}>{finalString}</Fragment>;
      }

      // Otherwise, loop to children until you find texts
      const values = Array.from(el.childNodes).map((c) => getNodeRecursive(c));

      // Execute function to get the React components to inject
      const finV = <Fragment key={key}>{fn(values)}</Fragment>;
      return finV;
    },
    [object]
  );

  return useMemo(() => {
    // Create a pure HTML element from the translation string.
    const element = document.createElement('span');
    element.innerHTML = string;

    // Convert all HTML child/nested elements into React nodes, and get them.
    const nodes = Array.from(element.childNodes).map((c) =>
      getNodeRecursive(c)
    );

    return <span className={className}>{nodes}</span>;
  }, [className, getNodeRecursive, string]);
}

export default memo(ParsedTranslation);
