import OnboardingModal from '@/features/onboarding/OnboardingModal';
import dynamic from 'next/dynamic';

const MenuActions = dynamic(() => import('./MenuActions'), {
  ssr: false,
});

export { MenuActions, OnboardingModal };
