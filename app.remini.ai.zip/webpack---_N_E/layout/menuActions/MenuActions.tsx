import { withSuspense } from '@/core/suspense';
import { useTracker } from '@/core/tracking';
import AccountModal from '@/features/account/accountModal/AccountModal';
import { MyAccountButton } from '@/features/account/MyAccountButton';
import { SignupButton } from '@/features/account/signup/SignupButton';
import TranslateDropdown from '@/features/localization/TranslateDropdown';
import OnboardingModal from '@/features/onboarding/OnboardingModal';
import { PhotoshopButton } from '@/features/photoshopPlugin';
import HelpPageLink from '@/features/support/HelpPageLink';
import { useLocalization } from '@/services/localizationService';
import { UserAction, useUser } from '@/services/userService';
import { isLoggedInSelector } from '@/stores/authStore';
import { isPerformingLoginSelector } from '@/stores/loginStore';
import { pushModalSelector } from '@/stores/modalStore';
import settingsState from '@/stores/settingsStore';
import { MonetizeButton } from '@/ui/monetizeButton/MonetizeButton';
import { useRouter } from 'next/router';
import { MouseEvent, useRef } from 'react';
import { TailSpin } from 'react-loader-spinner';
import { useRecoilValue, useSetRecoilState } from 'recoil';
import PaymentStrategiesModal from '@/features/payment/paymentStrategies/PaymentStrategiesModal';
import { usePaymentService } from '../appWrapper/ServiceProvider';

function MenuActions({
  className = '',
  showHamburgerInMDSize,
}: {
  className?: string;
  showHamburgerInMDSize?: boolean;
}) {
  const mainActionRef = useRef<HTMLButtonElement>(null);
  const secondaryActionRef = useRef<HTMLButtonElement>(null);
  const settings = useRecoilValue(settingsState);

  const isLoggedIn = useRecoilValue(isLoggedInSelector);
  const { data: user } = useUser();
  const pushModal = useSetRecoilState(pushModalSelector);
  const isPerformingLogin = useRecoilValue(isPerformingLoginSelector);
  const { isBaseUser, isPersonalUser, isBusinessUser } = usePaymentService();
  const { track } = useTracker();
  const { t, data } = useLocalization();
  const router = useRouter();

  const openOnboardingModal = (previousAction: UserAction) => {
    pushModal({
      id: 'user:onboarding',
      Modal: OnboardingModal,
      previousAction,
      onClose: () => mainActionRef.current?.focus(),
    });
  };

  const openAccountModal = (returnFocusRef) => {
    pushModal({
      id: 'user:account',
      Modal: AccountModal,
      onClose: () => {
        if (returnFocusRef.current) {
          returnFocusRef.current.focus();
        }
      },
    });
  };

  const actions = [
    <HelpPageLink
      key="help-page"
      className="btn btn--medium btn--secondary md:border-transparent"
    >
      {t(data.header.help)}
    </HelpPageLink>,
  ];

  if (isLoggedIn) {
    if (isBaseUser(user) && !user?.monetization?.hasIncompleteSubscription) {
      if (
        user?.monetization.trialAvailable &&
        settings.values.isFreeTrialEnabled
      ) {
        actions.push(
          <MonetizeButton
            key="free-trial"
            ref={mainActionRef}
            onClick={(e: MouseEvent<HTMLButtonElement>) => {
              track('free_trial', 'tapped', {
                actionValue: `${e.currentTarget.textContent} (CTA)`,
              });
              openOnboardingModal(UserAction.FreeTrial);
            }}
          >
            {t(data.common.freeTrial)}
          </MonetizeButton>
        );
      } else {
        actions.push(
          <MonetizeButton
            key="subscribe"
            ref={mainActionRef}
            onClick={(e: MouseEvent<HTMLButtonElement>) => {
              track('subscribe', 'tapped', {
                actionValue: `${e.currentTarget.textContent} (CTA)`,
              });
              openOnboardingModal(UserAction.Subscription);
            }}
          >
            {t(data.common.subscribe)}
          </MonetizeButton>
        );
      }
    }

    const accountActionRef =
      actions.length === 1 ? mainActionRef : secondaryActionRef;
    actions.unshift(
      <MyAccountButton
        key="account"
        ref={accountActionRef}
        onClick={(e: MouseEvent<HTMLButtonElement>) => {
          track('account', 'tapped', {
            actionValue: `${e.currentTarget.textContent} (CTA)`,
          });
          openAccountModal(mainActionRef);
        }}
      />
    );
  } else if (isPerformingLogin) {
    actions.unshift(
      <div key="logging-in" className="px-4 py-3 space-s-2">
        <TailSpin color="white" height="25" width="25" aria-label="loading" />
      </div>
    );
  } else {
    actions.push(
      <SignupButton
        key="signup"
        ref={mainActionRef}
        onClick={(e: MouseEvent<HTMLButtonElement>) => {
          track('login', 'tapped', {
            actionValue: `${e.currentTarget.textContent} (CTA)`,
          });
          openOnboardingModal(UserAction.Login);
        }}
      />
    );
  }

  if (
    settings.values.psPlugin &&
    isLoggedIn &&
    !isBusinessUser(user) &&
    !user?.monetization?.hasIncompleteSubscription
  ) {
    actions.push(
      <PhotoshopButton
        key="photoshop"
        onClick={() => {
          track('photoshop_plugin', 'tapped');
          if (isPersonalUser(user)) {
            pushModal({
              id: 'user:upgrade-subscription',
              Modal: PaymentStrategiesModal,
              isUpgrade: true,
            });
          } else {
            openOnboardingModal(UserAction.Login);
          }
        }}
      >
        {t(data.common.plugin)}
      </PhotoshopButton>
    );
  }

  if (['/', '/support'].includes(router.route)) {
    actions.push(<TranslateDropdown key="translate" />);
  }

  return (
    <div
      className={`flex flex-col space-y-4 ${
        showHamburgerInMDSize
          ? 'xl:flex-row xl:space-y-0'
          : 'md:flex-row md:space-y-0 md:space-s-4'
      } ${className}`}
    >
      {actions}
    </div>
  );
}

export default withSuspense(MenuActions, null);
