import { atom } from 'recoil';

export default atom({
  key: 'layout/navigation/isOpen',
  default: false,
});
