import { ReactElement } from 'react';

type HelpPageLinkProps = {
  children: ReactElement;
  className: string;
};

function HelpPageLink({ children, className }: HelpPageLinkProps) {
  return (
    <a
      target="_blank"
      href="https://remini-web.zendesk.com/hc/en-us"
      rel="noreferrer"
      className={className}
    >
      {children}
    </a>
  );
}

export default HelpPageLink;
