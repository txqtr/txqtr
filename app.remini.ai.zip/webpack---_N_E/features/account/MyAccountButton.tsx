import { useLocalization } from '@/services/localizationService';
import React, { ButtonHTMLAttributes, LegacyRef } from 'react';

export const MyAccountButton = React.forwardRef(
  (
    props: ButtonHTMLAttributes<HTMLButtonElement>,
    ref?: LegacyRef<HTMLButtonElement>
  ) => {
    const { t, data } = useLocalization();

    return (
      <button
        type="button"
        className="btn btn--medium btn--secondary md:border-transparent"
        {...props}
        ref={ref}
      >
        {t(data.header.myAccount)}
      </button>
    );
  }
);
