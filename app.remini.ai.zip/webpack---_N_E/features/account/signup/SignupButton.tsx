import React, { ButtonHTMLAttributes, LegacyRef } from 'react';
import { useLocalization } from '@/services/localizationService';

export const SignupButton = React.forwardRef(
  (
    props?: ButtonHTMLAttributes<HTMLButtonElement>,
    ref?: LegacyRef<HTMLButtonElement>
  ) => {
    const { t, data } = useLocalization();

    return (
      <button
        data-cy="login-btn"
        type="button"
        className="btn btn--medium md:btn--large btn--secondary"
        {...props}
        ref={ref}
      >
        {t(data.header.logInSignUp)}
      </button>
    );
  }
);
