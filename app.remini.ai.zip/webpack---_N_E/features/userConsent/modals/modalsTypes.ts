export enum ConsentEvent {
  Marketing = 'popup_marketing_consent',
  ImageTraining = 'popup_image_training_consent',
}
