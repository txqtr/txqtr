import dropdownIcon from '@/public/images/icons/down_small.svg';
import React, { useState, useCallback, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useLocalization } from '@/services/localizationService';
import { supportedLanguages } from '@/services/localizationService/localizationTypes';
import { useTracker } from '@/core/tracking';
import useOnClickOutside from '@/core/listeners/useOnClickOutside';

export default function TranslateDropdown({ props }: { props?: any }) {
  const { locale, changeLocale, isLoadingTranslations } = useLocalization();

  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);
  const { track } = useTracker();

  useOnClickOutside(
    dropdownRef,
    [],
    useCallback(() => setIsOpen(false), [])
  );

  const currLanguage = supportedLanguages.find((el) => el.code === locale);
  if (!currLanguage) return null;

  return (
    <div
      className="relative flex flex-col items-center text-end"
      ref={dropdownRef}
    >
      <button
        data-cy="translate-btn"
        type="button"
        className={`btn btn--medium md:btn--large btn--secondary w-full ${
          isOpen ? 'bg-overlay-black-20' : 'bg-overlay-white-10'
        } border-none gap-1`}
        {...props}
        onClick={() => {
          track('language', 'picker_tapped');
          setIsOpen(!isOpen);
        }}
        disabled={isLoadingTranslations}
      >
        {currLanguage.name}
        <img {...dropdownIcon} alt="" className="w-4 h-4" />
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            key="format-dropdown"
            className="z-50 text-base list-none bg-overlay-black-80 rounded-lg absolute mt-16 w-40 h-[304px] overflow-y-scroll"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ type: 'easeInOut', duration: 0.1 }}
            aria-orientation="vertical"
            aria-labelledby="menu-button"
          >
            <ul className="py-2">
              {supportedLanguages.map((language) => (
                <li key={language.code}>
                  <button
                    className="py-1.5 px-6 font-medium block w-full text-white text-center hover:bg-gray-100 hover:text-black"
                    onClick={() => {
                      changeLocale(language.code);
                      track('language', 'selected', {
                        language: language.code,
                      });
                      setIsOpen(false);
                    }}
                  >
                    {language.name}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
