import { ButtonHTMLAttributes } from 'react';

import photoshopIcon from '@/public/images/icons/photoshop.svg';

export default function PhotoshopButton(
  props: ButtonHTMLAttributes<HTMLButtonElement>
) {
  return (
    <button
      data-cy="photoshop-btn"
      type="button"
      className="btn btn--medium md:btn--large btn--secondary hover:bg-overlay-white-5"
      {...props}
    >
      <img {...photoshopIcon} alt="" />
      <span>{props.children}</span>
    </button>
  );
}
