import { useLegalCopy } from './useLegalCopy';

export function LegalCopy({ className = '' }: { className?: string }) {
  const { acceptTermsText } = useLegalCopy();
  return <p className={`R12 contrast-low ${className}`}>{acceptTermsText}</p>;
}
