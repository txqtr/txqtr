import { atomFamily } from 'recoil';

const fitStateFamily = atomFamily({
  key: 'comparer:fit',
  default: 'none',
});

export default fitStateFamily;
