export const MIN_ZOOM = 0.1;
export const MAX_ZOOM = 2.5;
