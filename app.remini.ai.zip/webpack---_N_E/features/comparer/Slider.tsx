import { useCallback, useEffect, useRef, useState } from 'react';
import Hammer from 'hammerjs';

import { TooltipContext } from '@/ui/tooltip/Tooltip';
import { useLocalization } from '@/services/localizationService';
import horizontalChevronIcon from '../../public/images/icons/chevron--horizontal.svg';
import { Tooltip } from '../../ui/tooltip';

type Props = {
  badgesAlignment?: string;
  borderWidth: number;
  offset: number;
  onChange: (e) => void;
  style?: any;
  className?: string;
  sliderBehavior: string;
  showTooltip: boolean;
};

export default function Slider({
  badgesAlignment,
  borderWidth = 1,
  offset,
  onChange,
  style = {},
  sliderBehavior,
  showTooltip = false,
  className = '',
  ...rest
}: Props) {
  const sliderRef = useRef<any>();
  const [initialOffset, setInitialOffset] = useState(0);
  const [hammer, setHammer] = useState<Hammer>();
  const [tooltipVisible, setTooltipVisible] = useState(showTooltip);
  const { t, data } = useLocalization();

  useEffect(() => {
    const hammer = new Hammer(sliderRef.current);
    hammer.get('pan').set({ direction: Hammer.DIRECTION_ALL });
    setHammer(hammer);
    return () => hammer.destroy();
  }, []);

  const updateInitialOffset = () => {
    const { offsetLeft } = sliderRef.current;
    setInitialOffset(offsetLeft);
  };

  const onPanMove = useCallback(
    (e) => {
      onChange(initialOffset + e.deltaX);
      setTooltipVisible(false);
    },
    [onChange, initialOffset]
  );

  const onMouseMove = useCallback(
    (e) => {
      onChange(initialOffset + e.pageX);
    },
    [onChange, initialOffset]
  );

  const onHover = useCallback(
    (e) => {
      onMouseMove(e);
    },
    [onMouseMove]
  );

  useEffect(() => {
    if (sliderBehavior === 'hover') {
      const slider = sliderRef.current.parentNode;
      slider.addEventListener(
        'ontouchstart' in document.documentElement ? 'touchmove' : 'mousemove',
        onHover
      );
      return () => {
        slider.removeEventListener(
          'ontouchstart' in document.documentElement
            ? 'touchmove'
            : 'mousemove',
          onHover
        );
      };
    }
  }, [onMouseMove, onHover, sliderBehavior]);

  useEffect(() => {
    if (sliderBehavior !== 'hover') {
      if (!hammer) return;
      hammer.on('panstart', updateInitialOffset);
      hammer.on('panmove', onPanMove);
      hammer.on('panend', updateInitialOffset);
      return () => {
        hammer.off('panstart', updateInitialOffset);
        hammer.off('panmove', onPanMove);
        hammer.off('panend', updateInitialOffset);
      };
    }
  }, [hammer, onPanMove, sliderBehavior]);

  return (
    <div
      className={`${className} absolute inset-y-0 w-0 border-overlay-white-70 cursor-resize-horizontal`}
      style={{
        left: `${offset - borderWidth}px`,
        borderLeftWidth: borderWidth,
        borderRightWidth: borderWidth,
        ...style,
      }}
      ref={sliderRef}
      {...rest}
    >
      <div
        className="absolute center-x w-8 h-8 p-12"
        style={{ bottom: badgesAlignment === 'top' ? '56px' : '110px' }}
        tabIndex={0}
        role="slider"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={50}
        aria-orientation="horizontal"
      >
        <Tooltip
          disableForcePosition
          visible={!!tooltipVisible}
          tooltipContentClassName="font-semibold"
          content={data.result.moveSlider}
          position="top"
          context={TooltipContext.Slider}
        />

        <img
          {...horizontalChevronIcon}
          className="absolute center pointer-events-none"
          alt=""
        />
      </div>
      <p
        className={`${
          badgesAlignment !== 'top' ? 'hidden' : ''
        } md:block absolute end-6 px-4 py-2 bg-overlay-black-60 text-white rounded-3xl pointer-events-none`}
        style={{
          bottom: 'auto',
          top: badgesAlignment === 'top' ? '16px' : '100px',
        }}
      >
        {t(data.common.before)}
      </p>
      <p
        className={`${
          badgesAlignment !== 'top' ? 'hidden' : ''
        } md:block absolute start-6 px-4 py-2 bg-overlay-black-60 text-white rounded-3xl pointer-events-none`}
        style={{
          bottom: 'auto',
          top: badgesAlignment === 'top' ? '16px' : '100px',
        }}
      >
        {t(data.common.after)}
      </p>
    </div>
  );
}
