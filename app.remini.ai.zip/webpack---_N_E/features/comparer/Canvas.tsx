import { useRef, useState, useEffect, useCallback, useMemo } from 'react';
import * as PIXI from 'pixi.js';
import Hammer from 'hammerjs';
import { useRecoilState } from 'recoil';
import { useIsRTL } from '@/services/localizationService/useIsRTL';
import useSprite from './useSprite';
import useTexture from './useTexture';
import fitStateFamily from './fitState';
import scaleSelectorFamily from './scaleSelector';
import { Vector } from './vector';

type Props = {
  className?: string;
  beforeSrc: string;
  afterSrc: string;
  canvasSize?: any;
  initialFit: string;
  disablePan?: boolean;
  disablePinch?: boolean;
  backgroundColor?: number;
  trim?: any;
  onPan?: () => void;
  onZoom?: () => void;
  onLoadComplete?: () => void;
  onLoadStart?: () => void;
  onLoadFail?: (e: unknown) => void;
};

export default function Canvas({
  className = '',
  beforeSrc,
  afterSrc,
  canvasSize,
  initialFit,
  disablePan,
  disablePinch,
  backgroundColor,
  trim,
  onPan,
  onZoom,
  onLoadComplete,
  onLoadStart,
  onLoadFail,
  ...rest
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);

  const [app, setApp] = useState<PIXI.Application>();

  const [hammer, setHammer] = useState<Hammer>(null);

  const [relCenterPos, setRelCenterPos] = useState(new Vector(0.5));
  const isRTL = useIsRTL();

  const absCenterPos = useMemo(
    () => canvasSize.multiply(relCenterPos),
    [relCenterPos, canvasSize]
  );

  const [scale, setScale] = useRecoilState(
    scaleSelectorFamily(`${beforeSrc}:${afterSrc}`)
  );

  const { texture: beforeTexture, status: beforeTextureStatus } = useTexture(
    isRTL ? afterSrc : beforeSrc
  );

  const { texture: afterTexture, status: afterTextureStatus } = useTexture(
    isRTL ? beforeSrc : afterSrc
  );

  useEffect(() => {
    if (onLoadStart) onLoadStart();
  }, [onLoadStart, beforeSrc, afterSrc]);

  useEffect(() => {
    if (
      onLoadComplete &&
      beforeTextureStatus.status === 'completed' &&
      afterTextureStatus.status === 'completed'
    ) {
      onLoadComplete();
    } else if (
      onLoadFail &&
      (beforeTextureStatus.status === 'failed' ||
        afterTextureStatus.status === 'failed')
    ) {
      onLoadFail(beforeTextureStatus.error || afterTextureStatus.error);
    }
  }, [onLoadComplete, onLoadFail, beforeTextureStatus, afterTextureStatus]);

  const [fit, setFit] = useRecoilState(
    fitStateFamily(`${beforeSrc}:${afterSrc}`)
  );

  useEffect(() => {
    setFit(initialFit);
  }, [setFit, initialFit]);

  useEffect(() => {
    // Using 'afterTexture' because it is ought to be the biggest
    if (!afterTexture || !afterTexture.valid) return;
    const textureSize = new Vector().copyFrom(afterTexture);
    const ratios = canvasSize.divide(textureSize);
    let ratio = 1;
    switch (fit) {
      case 'cover':
        ratio = ratios.max();
        break;
      case 'contain':
        ratio = ratios.min();
        break;
      case 'none':
        // Stop execution
        return;
    }
    setRelCenterPos(new Vector(0.5));
    setScale(ratio);
  }, [fit, canvasSize, afterTexture, beforeTexture, setScale]);

  let beforeSpriteScale = scale;
  if (afterTexture?.valid && beforeTexture?.valid) {
    // Assume the after texture is larger
    beforeSpriteScale *= afterTexture.width / beforeTexture.width;
  }

  const beforeSpriteAnchor = useMemo(() => new Vector(-1), []);

  const beforeSprite = useSprite(beforeTexture!, {
    center: absCenterPos,
    scale: beforeSpriteScale,
    anchor: beforeSpriteAnchor,
  });

  const afterSpriteAnchor = useMemo(() => new Vector(1), []);
  const afterSpriteTrim = useMemo(() => new Vector(trim, 0), [trim]);

  const afterSprite = useSprite(afterTexture!, {
    center: absCenterPos,
    scale,
    anchor: afterSpriteAnchor,
    trim: afterSpriteTrim,
  });

  useEffect(() => {
    if (!app) return;
    if (beforeSprite && afterSprite) {
      app.stage.addChild(beforeSprite);
      app.stage.addChild(afterSprite);
      return () => {
        app.stage.removeChild(beforeSprite);
        app.stage.removeChild(afterSprite);
      };
    }
  }, [app, beforeSprite, afterSprite]);

  const getRelCenterPosBounds = useCallback(
    (scale) => {
      if (afterTexture?.valid) {
        const imageCenterWhenInTopLeftCorner = new Vector()
          .copyFrom(afterTexture)
          .multiplyScalar(scale)
          .divide(canvasSize)
          .multiplyScalar(1 / 2);
        const imageCenterWhenInBottomRightCorner = new Vector(0.5).add(
          new Vector(0.5).subtract(imageCenterWhenInTopLeftCorner)
        );

        const minPos = new Vector(
          Math.min(
            imageCenterWhenInTopLeftCorner.x,
            imageCenterWhenInBottomRightCorner.x
          ),
          Math.min(
            imageCenterWhenInTopLeftCorner.y,
            imageCenterWhenInBottomRightCorner.y
          )
        );
        const maxPos = new Vector(
          Math.max(
            imageCenterWhenInTopLeftCorner.x,
            imageCenterWhenInBottomRightCorner.x
          ),
          Math.max(
            imageCenterWhenInTopLeftCorner.y,
            imageCenterWhenInBottomRightCorner.y
          )
        );
        return [minPos, maxPos];
      }
      return [0.5, 0.5];
    },
    [afterTexture, canvasSize]
  );

  const onWheel = useCallback(
    (e: WheelEvent) => {
      e.preventDefault();
      setFit('none');
      setScale((scale: number) => scale + -e.deltaY * 0.01);
      // TODO: update position based on pointer position
      if (typeof onZoom === 'function') {
        onZoom();
      }
    },
    [setFit, setScale, onZoom]
  );

  const [prevPinchScale, setPrevPinchScale] = useState(0);

  const onPinchStart = useCallback(() => {
    setPrevPinchScale(-1);
  }, []);

  const onPinchMove = useCallback(
    (e) => {
      setFit('none');
      setPrevPinchScale(e.scale);
      if (prevPinchScale !== -1) {
        setScale((scale) => scale + e.scale - prevPinchScale);
        // TODO: update position based on gesture center
      }
      if (typeof onZoom === 'function') {
        onZoom();
      }
    },
    [setFit, setScale, onZoom, prevPinchScale]
  );

  useEffect(() => {
    setRelCenterPos((pos) =>
      pos.clamp(
        getRelCenterPosBounds(scale)[0],
        getRelCenterPosBounds(scale)[1]
      )
    );
  }, [scale, getRelCenterPosBounds]);

  const [prevDelta, setPrevDelta] = useState(new Vector());

  const onPanMove = useCallback(
    (e) => {
      const currentDelta = new Vector(e.deltaX, e.deltaY);
      const deltaDiff = currentDelta.subtract(prevDelta);
      const relDeltaDiff = deltaDiff.divide(canvasSize);
      setPrevDelta(currentDelta);
      setFit('none');

      setRelCenterPos((relCenterPos) =>
        relCenterPos
          .add(relDeltaDiff)
          .clamp(
            getRelCenterPosBounds(scale)[0],
            getRelCenterPosBounds(scale)[1]
          )
      );
      if (typeof onPan === 'function') {
        onPan();
      }
    },
    [setFit, prevDelta, onPan, scale, canvasSize, getRelCenterPosBounds]
  );

  const onPanEnd = () => {
    setPrevDelta(new Vector());
  };

  const onContextMenu = useCallback((e) => {
    e.preventDefault();
  }, []);

  useEffect(() => {
    if (!app) return;
    if (!hammer || hammer.destroyed) return;

    app.view.addEventListener('contextmenu', onContextMenu);
    if (!disablePan) {
      hammer.on('panmove', onPanMove);
      hammer.on('panend', onPanEnd);
    }
    if (!disablePinch) {
      app.view.addEventListener('wheel', onWheel);
      hammer.on('pinchstart', onPinchStart);
      hammer.on('pinchmove', onPinchMove);
    }
    return () => {
      app.view.removeEventListener('contextmenu', onContextMenu);
      if (!disablePan) {
        hammer.off('panmove', onPanMove);
        hammer.off('panend', onPanEnd);
      }
      if (!disablePinch) {
        app.view.removeEventListener('wheel', onWheel);
        hammer.on('pinchstart', onPinchStart);
        hammer.off('pinchmove', onPinchMove);
      }
    };
  }, [
    app,
    hammer,
    disablePan,
    disablePinch,
    onPanMove,
    onPinchStart,
    onPinchMove,
    onWheel,
    onContextMenu,
  ]);

  useEffect(() => {
    if (!app) return;
    const { width, height } = canvasSize;
    // using css to fit the high res canvas in the viewport
    app.view.style.width = `${width}px`;
    app.view.style.height = `${height}px`;
    app.renderer.resize(width, height);
    app.render();
  }, [app, canvasSize]);

  useEffect(() => {
    const app = new PIXI.Application({ backgroundColor });
    containerRef.current?.appendChild(app.view);
    setApp(app);

    const hammer = new Hammer(app.view);
    hammer.get('pinch').set({ enable: true });
    hammer.get('pan').set({ direction: Hammer.DIRECTION_ALL });
    setHammer(hammer);

    return () => {
      app.destroy(true, true);
      hammer.destroy();
      hammer._destroyed = true;
    };
  }, [backgroundColor]);

  return (
    <div
      ref={containerRef}
      className={`${
        afterTexture?.valid ? 'opacity-100' : 'opacity-0'
      } transition-opacity duration-1000 ${className}`}
      {...rest}
    />
  );
}
