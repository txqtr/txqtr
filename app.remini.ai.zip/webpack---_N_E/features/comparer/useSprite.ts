import { useState, useEffect, useMemo } from 'react';
import * as PIXI from 'pixi.js';
import { Sprite } from 'pixi.js';
import { Vector } from './vector';

/**
 * @typedef {import('../../helpers/vector').default} Vector
 */

/**
 * @param {PIXI.Texture} texture
 * @param {Object} options
 * @param {Vector} options.center
 * @param {number} options.scale
 * @param {Vector?} options.trim
 * @param {Vector?} options.anchor
 */
export default function useSprite(
  texture: PIXI.Texture,
  {
    center,
    scale,
    trim,
    anchor = new Vector(-1),
  }: { center: Vector; scale: number; trim?: Vector; anchor?: Vector }
) {
  const [sprite, setSprite] = useState<Sprite>();

  useEffect(() => {
    if (!texture || !texture.valid) return;

    const sprite = new PIXI.Sprite(texture.clone());

    setSprite(sprite);

    return () => sprite.destroy(true);
  }, [texture, texture?.valid]);

  useEffect(() => {
    if (sprite && !sprite.destroyed && texture.valid) {
      // Turn the [-1, 1] range into [0, 1]
      const normalizedAnchor = anchor.add(new Vector(1)).multiplyScalar(0.5);
      sprite.anchor.copyFrom(normalizedAnchor);

      // Stays constant because the texture has been duplicated
      const textureSize = new Vector().copyFrom(texture);

      // Let PIXI figure out the final size
      sprite.scale.set(scale, scale);

      // sprite.width and sprite.height are influenced by the frame. This is the only reliable measurement
      const spriteSize = textureSize.multiplyScalar(scale);

      // Position
      const spritePosition = center.add(
        spriteSize.multiply(anchor).multiplyScalar(0.5)
      );
      sprite.position.copyFrom(spritePosition);

      if (trim) {
        const topLeftCorner = center.subtract(spriteSize.multiplyScalar(0.5));

        const relTrim = trim.subtract(topLeftCorner);
        const normalizedRelTrim = relTrim
          .multiplyScalar(1 / scale)
          .clamp(Vector.ZERO, textureSize);

        const trimRect = new PIXI.Rectangle(
          anchor.x < 0 ? 0 : normalizedRelTrim.x,
          anchor.y < 0 ? 0 : normalizedRelTrim.y,
          anchor.x > 0
            ? textureSize.width - normalizedRelTrim.x
            : normalizedRelTrim.x,
          anchor.y > 0
            ? textureSize.height - normalizedRelTrim.y
            : normalizedRelTrim.y
        );

        sprite.texture.frame = trimRect;
        sprite.texture.updateUvs();
      }
    }
  }, [anchor, center, scale, sprite, texture, trim]);

  return useMemo(
    () => (sprite && !sprite.destroyed ? sprite : null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [sprite, sprite?.destroyed]
  );
}
