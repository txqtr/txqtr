import { useState, useEffect } from 'react';
import * as PIXI from 'pixi.js';

export default function useTexture(src: string) {
  const [status, setLoadingState] = useState<{
    status: 'pending' | 'failed' | 'completed';
    error?: any;
  }>({ status: 'pending' });
  const [texture, setTexture] = useState<PIXI.Texture | null>(null);

  useEffect(() => {
    let resultTexture: PIXI.Texture;
    let shouldBeDestroyed = false;
    setLoadingState({ status: 'pending' });
    PIXI.Texture.fromURL(src, {})
      .then((result) => {
        if (shouldBeDestroyed) {
          result.destroy(true);
          return;
        }

        result.baseTexture.mipmap = PIXI.MIPMAP_MODES.ON;
        PIXI.settings.RESOLUTION = window.devicePixelRatio;
        setTexture(result);

        setLoadingState({ status: 'completed' });
        resultTexture = result;
      })
      .catch(() => {
        setLoadingState({
          status: 'failed',
          // Unfortunately, the thrown "error" is an instance of Event, which doesn't have any useful information to propagate
          error: new Error('The texture failed loading.'),
        });
      })
      .finally(() => {
        shouldBeDestroyed = false;
      });

    return () => {
      if (resultTexture) {
        resultTexture.destroy(true);
      } else {
        shouldBeDestroyed = true;
      }
    };
  }, [src]);

  return {
    texture,
    status,
  };
}
