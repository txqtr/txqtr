import { atom } from 'recoil';

export const isReprocessingMediaState = atom({
  key: 'media:isReprocessing',
  default: false,
});
