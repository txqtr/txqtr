import { atom } from 'recoil';
import { TaskToFormat } from '@/services/formatService/formatTypes';

const taskToFormatAssociationState = atom<TaskToFormat>({
  key: 'download:taskToFormat',
  default: {},
});

export default taskToFormatAssociationState;
