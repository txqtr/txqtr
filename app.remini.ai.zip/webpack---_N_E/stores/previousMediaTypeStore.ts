import { TaskType } from '@/services/uploaderService';
import { atom } from 'recoil';

export const previousMediaTypeState = atom<TaskType | undefined>({
  key: 'media:previousMediaType',
  default: undefined,
});
